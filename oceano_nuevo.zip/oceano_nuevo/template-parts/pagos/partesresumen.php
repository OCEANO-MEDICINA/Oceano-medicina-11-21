<?php
$totalventa = get_cart_total_installments(1);
$totalventason = get_cart_total_installments(1);
$plan = $_SESSION['plan_de_estudio'];

$coupons = WC()->cart->get_coupons();

if ($plan != '') {

    $plan0 = null;

    switch ($_SESSION['plan_de_estudio']) {
        case '12':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_12', $plan0->ID)[0];
            break;
        case '18':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_18', $plan0->ID)[0];
            break;
        case '24':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_24', $plan0->ID)[0];
            break;
    }

    $totalventa = array_reduce($plan0['precios'], 'filterPais');
    foreach ($coupons as $key => $coupon) {
        $discount_type = $coupon->get_discount_type(); // Get coupon discount type
        $coupon_amount = $coupon->get_amount();

        if ($discount_type == 'percent') {
            $totalventa = $totalventa - (($totalventa * $coupon_amount) / 100);
        }
    }
}


function get_cart_total_installments_nuevo($i = 1, $totalventa)
{

    if ($_SESSION['plan_de_estudio'] != '') {
        return ($totalventa / $i);
    }


    return get_cart_total_installments($i);
}

?>
<div>
    <div class="leftsidecheck">
        <h5 class="titulocheckresumen">RESUMEN DE MI COMPRA</h5>

        <?php
        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
            $nacCert = $intCert = null;
            $item_id = (!empty($cart_item['variation_id'])) ? $cart_item['variation_id'] : '';
            $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
            $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
            $father_post_id = get_field('father_post_id', $product_id);
            $product_name = get_the_title($father_post_id);

            $category = (get_field("main_category", $father_post_id)) ? get_field("main_category", $father_post_id) : null;
            $category_name = ($category) ? $category->name : "Desconocido";
            $category_slug = ($category) ? $category->slug : "";

            if ($item_id) {
                $nacCert = get_cart_item_local_cert($item_id);
                $nacCertSlug = get_cart_item_local_cert_slug($item_id);
                $intCert = get_cart_item_int_cert($item_id);
                $intCertSlug = get_cart_item_int_cert_slug($item_id);
                $int_school = get_field('int_schools', $product_id);
            }

        ?>





            <div class="cartcontent row align-items-center">

                <div class="cartimage col-3 col-md-3 col-lg-2">
                    <img src="<?= get_cart_product_image_url($_product); ?>">
                </div>
                <div class="cartproduct row col-9 col-md-8 col-lg-10">
                    <div class="col-12 col-lg-9 carddes">
                        <h4 class="productclass"><?= get_primary_category_string($father_post_id); ?></h4>
                        <h3 class="producttitle"><?= $product_name ?></h3>
                        <?php

                        $codigo_curso = get_field('codigo_unico', $father_post_id);
                        if ($codigo_curso) {
                        ?><span class="propietario-intelectual alinearcodigo">Código de curso: <strong><?= $codigo_curso ?></strong></span><?php
                                                                                                                                                                    } ?>
                    </div>

                    <?php
                    if ($plan == '') {
                    ?>
                        <div class="col-12 col-lg-3 productvalue">
                            <div class="precioproductoindividual">
                                <h4 class="productcuotas d-none d-lg-block">Costo</h4>
                                <span class="productprice">
                                    <?= format_number($cart_item['line_subtotal']); ?>
                                </span>
                                <span class="arsindicepais">
                                    <?php
                                    $currency_code = get_field('currency_3_digits_code', 'options');
                                    echo $currency_code;
                                    ?>
                                </span>
                            </div>
                        </div>
                    <?php
                    }
                    ?>


                </div>


            </div>
            <?php
            $ignore_int = get_field('ignore_int_cert', $father_post_id);
            if ((is_course($father_post_id)) && (has_certification($product_id, 'int'))) {
                //Check if there's an international certification available for this course
                if (isset($int_school) && !$ignore_int) {
                    //Check if the currently selected int cert is the "no int cert" option
                    if (substr($intCertSlug, 0, strlen('sin-universidad')) === 'sin-universidad') {
                        if (empty($intCert)) {
                            $base_price = get_combo_course_price($product_id, false, false, get_installments());
                            $int_and_base_price = get_combo_course_price($product_id, false, true, get_installments());
                            $currency_code = get_field('currency_3_digits_code', 'options');
            ?>
                            <div class="cartcontent addtocart row align-items-center">
                                <div class="cartimage col-5 col-md-4 col-lg-3">
                                    <img src="<?= get_cart_product_image_url($_product); ?>">
                                </div>
                                <div class="cartproduct col-7 col-md-8 col-lg-5">
                                    <h4 class="productclass"><?= get_the_title($product_id); ?></h4>
                                    <h3 class="producttitle">Certificación Internacional</h3>
                                    <h6><a id="cart-int-add-to-cart" data-product-id="<?= $product_id ?>" data-nacslug="<?= $nacCertSlug ?>" data-intslug="<?= $int_school->slug ?>" href="#">Agregar</a></h6>
                                </div>
                                <div class="productvalue col-12 col-lg-3">
                                    <h4 class="productcuotas"><?= get_installments() ?> cuotas<br />sin intereses de</h4>
                                    <h2 class="productprice"><?= format_number($int_and_base_price - $base_price); ?></h2>
                                </div>
                            </div>
        <?php
                        }
                    }
                }
            }
            echo "<hr class='asd' style:border-top: 1px solid rgba(172, 172, 172, 0.25);'>";
        }
        ?>


        <?php do_action('woocommerce_before_cart_table'); ?>



        <?php do_action('woocommerce_cart_actions'); ?>

        <?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>

        <?php //do_action( 'woocommerce_after_cart_table' ); 
        ?>
        <div style="" class="row">
            <div style="text-align: center;" class="col-2 d-none d-lg-inline">
                <div style="width: 95px;">
                    <img style="" src="/wp-content/themes/oceano/images/credit-card 1.png">
                </div>
            </div>

            <?php
            $coupons = WC()->cart->get_coupons();
            if ($coupons) {
            ?>
                <div style="text-align: center;" class="col-lg-2 col-3 iconocupondis">
                    <img class="" src="/wp-content/themes/oceano/images/cupon 1cupon.png">
                </div>
            <?php
            } else {
            ?>
                <div style="text-align: center;" class="col-lg-2 col-3 iconocupondis">
                    <!-- <img style="" src="/wp-content/themes/oceano/images/cupon 1cupon.png"> -->
                </div>
            <?php
            }
            ?>

            <div class="col-lg-10 col-9 row seleccionarcuotasdivresumen">
                <div class="col-lg-9 seleccionarcuotasresumen">
                    <div class="cart-installments-picker">
                        <label>
                            <!-- <div class="listaarticulos row"> -->
                            <?php
                            if ($plan != '') {
                            ?>
                                <h5 class="price col-4" id="" data-amount="<?php echo $totalventa; ?>" data-symbol=""><?= get_currency_symbol(); ?><?= format_number(get_cart_total_installments_nuevo($plan, $totalventa)); ?></h5>
                                <span class="arsindicepaisdif">
                                    <?php
                                    $currency_code = get_field('currency_3_digits_code', 'options');
                                    echo $currency_code;
                                    ?>
                                </span>

                                <h5>/mes durante</h5>
                                <h5 class="title col-8"><span class=""><?= $plan ?></span>&nbsp;meses </h5>
                                <!-- <h5 class="title col-8"><span><?= $plan ?></span>&nbsp;sin intereses de </h5> -->

                            <?php
                            } else {
                            ?>

                                <h5 class="title col-8">
                                    <div class="label_quotes">12 cuotas</div> sin intereses de
                                </h5>
                                <h5 class="price col-4" id="" data-amount="<?php echo $totalventa; ?>" data-symbol=""><?= get_currency_symbol(); ?><?= format_number(get_cart_total_installments(get_installments(), $totalventa)); ?></h5>
                                <h5 class="price col-4" id="" data-amount="<?php echo $totalventa; ?>" data-symbol=""></h5><span class="arsindicepaisdif">
                                    <?php
                                    $currency_code = get_field('currency_3_digits_code', 'options');
                                    echo $currency_code;
                                    ?>
                                </span>
                            <?php
                            }
                            ?>
                        </label>

                    </div>
                </div>
                <?php
                if ($plan != '') {
                ?>

                <?php
                } else {
                ?>

                    <div class="col-lg-3 productvalue ordertotal">

                        <?php
                        $coupons = WC()->cart->get_coupons();
                        if ($coupons) {
                            foreach ($coupons as $coupon) {
                        ?>
                                <div class="precioproductoindividual">
                                    <h6 class="producttotaldes producttotal">Total</h6>
                                    <span class="productpricetotaldes">
                                        <?= format_number($totalventason); ?>
                                    </span>
                                    <span class="arsindicepaisdes">
                                        <?php
                                        $currency_code = get_field('currency_3_digits_code', 'options');
                                        echo $currency_code;
                                        ?>
                                    </span>
                                    <h6 class="totalsincuotasresumen cartpage"><span>CON DESCUENTO</span></h6>
                                </div>
                            <?php
                            }
                        } else {
                            ?>
                            <div class="precioproductoindividual">
                                <h6 class="producttotal">Total</h6>
                                <span class="productpricetotal">
                                    <?= format_number($totalventa); ?>
                                </span>
                                <span class="arsindicepais">
                                    <?php
                                    $currency_code = get_field('currency_3_digits_code', 'options');
                                    echo $currency_code;
                                    ?>
                                </span>
                            </div>
                        <?php
                        }
                        ?>
                    </div>

                <?php
                }
                ?>

            </div>
        </div>
    </div>
</div>