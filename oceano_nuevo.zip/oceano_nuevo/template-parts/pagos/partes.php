<?php
//aca voy a meter todas las partes del form de pagos...
?>

<div class="cl_part_form" id="part_datosadicionales">
    <div class="row paddingmobile">
        <div class="col-12">
            <h1>DATOS DE FACTURACIÓN</h1>
            <p style="color:#979797;margin-bottom: 0px;">*Datos obligatorios</p>
        </div>
    </div>
    <div class="row datosadicionales">
        <form class="row form-pago" id="form_datosadicionales">
            <div class="col-lg-6 col-12">
                <label class="form-check-label" for="nombre">Nombre*</label>
                <input class="form-check-input input-texto" type="text" placeholder="Ingresar nombre" name="nombrealumno" id="nombre" value="">
            </div>
            <div class="col-lg-6 col-12">
                <label class="form-check-label" for="nombre">Apellido*</label>
                <input class="form-check-input input-texto" type="text" placeholder="Ingresar apellido" name="apellidoalumno" id="apellido" value="">
            </div>

            <input class="form-check-input input-texto" style='display:none' type="text" value='Argentina' placeholder="Ingresar apellido" name="pais" id="paisalumno" value="">

            <div class="col-lg-6 col-12">
                <label class="form-check-label" for="dni">Número de documento <span style="font-size: 14px;color: rgba(151, 151, 151, 1);">*</span></label>
                <input class="form-check-input input-texto" type="text" placeholder="Ingresar número" name="dnialumno" id="dni" value="">
            </div>
            <div class="col-lg-6 col-12 clear">
                <label class="form-check-label" for="email">Email*</label>
                <input class="form-check-input input-texto" type="text" placeholder="Ingresar mail" name="email" id="email" value="">
            </div>
            <div class="col-4">
                <label class="form-check-label" for="telefonocodigo">Código país</label>
                <select class="form-check-input input-texto" name="telefonocodigo" id='telefonocodigo'>
                    <option flag='ar' pais='Argentina' value="+ 54">AR + 54</option>
                    <option flag='bo' pais='Bolivia' value="+ 591">BO + 591</option>
                    <option flag='cl' pais='Chile' value="+ 56">CL + 56</option>
                    <option flag='co' pais='Colombia' value="+ 57">CO + 57</option>
                    <option flag='cr' pais='Costa Rica' value="+ 506">CR + 506</option>
                    <option flag='ec' pais='Ecuador' value="+ 593">EC + 593</option>
                    <option flag='esl' pais='San Salvador' value="+ 503">SV + 503</option>
                    <option flag='gt' pais='Guatemala' value="+ 502">GT + 502</option>
                    <option flag='ho' pais='Honduras' value="+ 504">HN + 504</option>
                    <option flag='mx' pais='Mexico' value="+ 52">MX + 52</option>
                    <option flag='ni' pais='Nicaragua' value="+ 505">NI + 505</option>
                    <option flag='pa' pais='Panama' value="+ 507">PA + 507</option>
                    <option flag='py' pais='Paraguay' value="+ 595">PY + 595</option>
                    <option flag='pe' pais='Peru' value="+ 51">PE + 51</option>
                    <option flag='es' pais='España' value="+ 34">ES + 34</option>
                    <option flag='uy' pais='Uruguay' value="+ 598">UY + 598</option>
                </select>
            </div>
            <div class="col-8 telefono">
                <label class="form-check-label" for="telefono">Teléfono*</label>
                <input class="form-check-input input-texto" type="text" placeholder="Ingresar número" name="telefonoalumno" id="telefono" value="">
            </div>
            <div class="col-12 col-lg-4 addpro">
                <?= print_state_field("add_provincia"); ?>
            </div>

            <div class="col-12 col-lg-5">
                <label class="form-check-label" for="direccion">Dirección*</label>
                <input class="form-check-input input-texto" type="text" placeholder="Ingresar dirección" name="direccionalumno" id="direccion" value="">
            </div>
            <div class="col-12 col-lg-3">
                <label class="form-check-label" for="direccion">Código Postal*</label>
                <input class="form-check-input input-texto" type="text" placeholder="Ingresar Código postal" name="zipalumno" id="id_zip" value="">
            </div>

        </form>
    </div>
    <div class="separador" style="border-bottom: 1px solid #ACACAC;margin: 50px -33%;"></div>


    <form class="row form-pago" id="form_formadepago">
        <div class="row seleforma ">
            <div class="titulobloquetarjetas">
                <h1 style="display: inline-block;">SELECCIONA EL MÉTODO DE PAGO</h1><img class="logomp" src="/wp-content/themes/oceano/images/logo__large2xnew.png">
            </div>
            <span class="infopagomp">
                La transacción se realiza a través de mercadopago para ofrecer un tratamiento seguro de los pagos y la facturación.
            </span>
        </div>
        <div class="row seleforma" style="display: none">
            <div class="form-check col-12">
                <input class="form-check-input radio radio-danger" checked="checked" disabled type="radio" name="procesadorpago" value="mercadopago">
                <label class="form-check-label" for="procesadorpago">Mercado Pago</label>
                <!--<input class="form-check-input radio radio-danger" checked="checked" disabled type="radio" name="procesadorpago" value="mercadopago">
                <label class="form-check-label" for="procesadorpago">Mercado Pago-->
            </div>
        </div>
        <div class="row seleforma divcredito">
            <div class="form-check col-12">
                <input class=" radio radio-danger" type="radio" name="formadepago" id="credito" value="credito" checked>
                <label class="form-check-label" for="credito">
                    <strong>Tarjeta de crédito</strong>
                </label>
                <div id="id_thumbs_cre"></div>
            </div>
        </div>
        <div class="row seleforma divdebito">
            <div class="form-check col-12">
                <input class=" radio radio-danger" type="radio" name="formadepago" id="debito" value="debito">
                <label class="form-check-label" for="debito">
                    <strong>Tarjeta de débito</strong>
                </label>
                <div id="id_thumbs_de"></div>
            </div>
        </div>
        <div class="row seleforma divcupon" style="display: none">
            <div class="form-check col-12">
                <input class="form-check-input radio radio-danger" type="radio" name="formadepago" id="cupon" value="cupon">
                <label class="form-check-label" for="cupon">
                    Cupón de pago
                </label>
                <div id="id_thumbs_cup"></div>
            </div>
        </div>
        <div class="row seleforma divdeposito" style="display: none">
            <div class="form-check col-12">
                <input class="form-check-input radio radio-danger" type="radio" name="formadepago" id="deposito" value="deposito">
                <label class="form-check-label" for="deposito">
                    Depósito
                </label>
                <div id="id_thumbs_dpst"></div>
            </div>
        </div>
        <div class="row seleforma divtransferencia" style="display: none">
            <div class="form-check col-12">
                <input class="form-check-input radio radio-danger" type="radio" name="formadepago" id="transferencia" value="transferencia">
                <label class="form-check-label" for="transferencia">
                    Transferencia
                </label>
                <div id="id_thumbs_traf"></div>
            </div>
        </div>
    </form>

    <br>
    <div class="separador" style="border-bottom: 1px solid #ACACAC;margin: 50px -33%;"></div>

    <div class="row paddingmobile">
        <div class="col-12">
            <h1 class="datospago">DATOS DE PAGO</h1>
        </div>
    </div>


    <div class="row agregartarjeta">
        <form class="row form-pago" id="form_datostarjeta">
            <div class="col-12">
                <label class="form-check-label" for="nrotarjeta">Número de tarjeta</label>
                <input class="form-check-input input-texto" type="text" id="cardNumber" value="" data-checkout="cardNumber" placeholder="XXXX XXXX XXXX XXXX" value="4111111111111111">
            </div>


            <div class="col-6 col-lg-6 fechavenci">
                <label class="form-check-label fechavenci" for="mes">Fecha de vencimiento</label>
                <input class="form-check-input input-texto" type="text" value="" id="cardExpirationMonth2" data-checkout="cardExpirationMonth2" placeholder="MM/AAAA" value="10">
            </div>
            <div class="col-6 col-lg-6">
                <label class="form-check-label" for="codigo-seguridad">Código de seguridad</label>
                <input class="form-check-input input-texto" type="text" value="" id="securityCode" data-checkout="securityCode" placeholder="***" value="111" />
            </div>


            <div style="display: none;" class="col-4">
                <label class="form-check-label" for="mes">Mes de expiración</label>
                <input class="form-check-input input-texto" type="text" value="" id="cardExpirationMonth" data-checkout="cardExpirationMonth" placeholder="MM" value="10">
            </div>
            <div style="display: none;" class="col-4">
                <label class="form-check-label" for="año">Año de expiración</label>
                <input class="form-check-input input-texto" value="" id="cardExpirationYear" data-checkout="cardExpirationYear" placeholder="AAAA" value="2022">
            </div>
            <div class="col-12">
                <label class="form-check-label" for="nombre">Nombre y Apellido como figura en la tarjeta</label>
                <input class="form-check-input input-texto" type="text" value="" data-checkout="cardholderName" id="cardholderName" placeholder="Ingresar nombre y apellido" value="John Doe">
            </div>

            <div class="col-6" style="width: 25%;max-width: 25%;">
                <label class="form-check-label fortipodni" for="dni">Documento</label>
                <select name="docType" class="form-check-input input-texto minimal" id="docType" data-checkout="docType"></select>
            </div>
            <div class="col-12" style="width: 75%;max-width: 75%;">
                <label class="form-check-label fornumdni" for="dni">Número de documento</label>
                <input class="form-check-input input-texto" type="text" value="" name="docNumber" id="docNumber" data-checkout="docNumber" placeholder="Ingresar número" />
            </div>

            <div class="col-6" style='display:none'>
                <label class="form-check-label" id="issuer_label" for="banco">Banco</label>
                <select class="form-check-input input-texto" id="issuer" name="issuer"></select>
            </div>

            <!-- Esto sirve como "placeholder secreto" para tomar data... y luego la replico adelante -->
            <select style="display:none;" id="installments" name="installments" value="<?php echo get_installments(); ?>"></select>
            <input style="display:none;" id="amount" name="amount" value="<?php echo getTotalPrice(); ?>" type="text">
            <input style="display:none;" id="tipo_tarjeta" name="tipo_tarjeta" value="" type="text" placeholder="<Tipo de tarjeta>">
            <input style="display:none;" id="paymentMethodId" name="paymentMethodId" value="" type="hidden" placeholder="<Tipo de tarjeta>" />
            <input style="display:none;" class="form-check-input radio radio-danger" type="radio" name="estilodepago" id="tradicional" value="suscripcion" checked>

        </form>
    </div>









    <div class="cl_part_form" style="display:none;" id="part_delivery">
        <div class="return"><span class="class_back" href="">Volver</span></div>
        <div class="row">
            <div class="col-12">
                <h1>DÓNDE QUERÉS RECIBIR EL PRODUCTO2</h1>
            </div>
        </div>
        <div class="row agregartarjeta">
            <form class="row form-pago" id="form_delivery">
                <div class="col-6">
                    <label class="form-check-label" for="codigopostal">Código Postal</label>
                    <input class="form-check-input input-texto" type="text" name="del_codigopostal" id="del_codigopostal">
                </div>
                <div class="col-6">
                    <label class="form-check-label" for="calle">Calle</label>
                    <input class="form-check-input input-texto" type="text" name="del_calle" id="del_calle">
                </div>
                <div class="col-6">
                    <label class="form-check-label" for="numero">Número</label>
                    <input class="form-check-input input-texto" type="text" name="del_numero" id="del_numero" value='1111'>
                </div>
                <!-- <div class="col-6">
                <label class="form-check-label" for="piso">Piso/Dpto *</label>
            </div> -->
                <input class="form-check-input input-texto" style='display:none' value='-' type="text" name="del_piso" id="del_piso">
                <div class="col-6">
                    <label class="form-check-label" for="calles">Entre calles</label>
                    <input class="form-check-input input-texto" type="text" value="-" name="del_entre" id="del_entre">
                </div>
                <div class="col-6" style='display:none'>
                    <label class="form-check-label" for="referencias">Referencias*</label>
                    <input class="form-check-input input-texto" type="text" name="del_ref" id="del_ref">
                </div>
                <div class="col-6">
                    <label class="form-check-label" for="localidad">Localidad/Barrio</label>
                    <input class="form-check-input input-texto" type="text" value="-" name="del_barrio" id="del_barrio">
                </div>
                <?= print_state_field("del_provincia"); ?>
            </form>
        </div>
    </div>


    <div class="cl_part_form" style="display:none;" id="part_first">
        <div class="return"><span class="class_back" href="">Volver</span></div>
        <div class="row">
            <div class="col-12">
                <h1>¿CÓMO DESEAS REALIZAR EL PAGO?</h1>
                <p class="descripcion-abono">Océano Medicina ofrece dos formas de pago para todas las modalidades de formaciones.</p>
            </div>
        </div>
        <form class="row form-pago" id="form_first">
            <!--         <div class="row seleforma formasucri">
            <div class="form-check col-12">
                <input class="form-check-input radio radio-danger" type="radio" name="estilodepago" id="suscripcion" value="suscripcion">
                <label class="form-check-label" for="suscripcion">
                    En suscripción
                </label>
                <p for="suscripcion">El pago por suscripción o pagos recurrentes son cobros automatizados que se realizan mensualmente en su cuenta.</p>
            </div>
        </div> -->
            <div class="row seleforma formatrad" style="display: none">
                <div class="form-check col-12">
                    <input class="form-check-input radio radio-danger" type="radio" name="estilodepago" id="tradicional" value="tradicional" checked>
                    <label class="form-check-label" for="tradicional">
                        Tradicional
                    </label>
                    <p for="tradicional">Se realizará el cobro en su tarjeta de crédito o débito.</p>
                    <!--<div class="descuento">-15%</div>-->
                </div>
            </div>
        </form>
    </div>


    <div class="cl_part_form" style="display:none;" id="part_cuotas">
        <div class="return"><span class="class_back" href="">Volver</span></div>
        <div class="row">
            <div class="col-12">
                <h1>¿EN CUÁNTAS CUOTAS QUIERES REALIZAR EL PAGO?</h1>
            </div>
        </div>
        <div class="row elegircupon">
            <form class="row form-pago" id="form_cuotas">
                Asegurate de colocar bien los valores en tus datos de tarjeta (sin espacios adicionales)
            </form>
        </div>
    </div>

    <div class="cl_part_form" style="display:none;" id="part_meses">
        <div class="return"><span class="class_back" href="">Volver</span></div>
        <div class="row">
            <div class="col-12">
                <h1>¿QUE PLAN DE SUSCRIPCIÓN PREFIERES?</h1>
            </div>
        </div>
        <div class="row elegircupon">
            <form class="row form-pago" id="form_meses">
                <?php
                $installments = [3, 6, 9, 12];
                $cookieInstallments = get_installments();
                foreach ($installments as $installment) {
                    $installmentString = ($installment == 1) ? 'cuota' : 'cuotas';
                ?>
                    <div class="col-12 cupones-de-pago plancuotas">
                        <input class="form-check-input input-texto installments-checkbox" type="radio" <?= ($installment == $cookieInstallments) ? 'checked' : ''; ?> name="meses_cre" value="<?= $installment ?>" id="label_meses<?= $installment ?>">
                        <label class="form-check-label" for="label_meses<?= $installment ?>"><?= $installment ?> <?= $installmentString ?></label>
                    </div>
                <?php
                }
                ?>
            </form>
        </div>
    </div>

</div>



<div style="display:none;" id="id_separate">

    <?php echo echoOptions(); ?>

    <input type="hidden" id="id_country" value="<?php echo echoLang(); ?>">
    <input type="hidden" id="id_processor" value="<?php echo echoProcessor(); ?>">
    <input type="hidden" id="id_cookie_inst" value="<?php echo get_installments(); ?>">
    <input type="hidden" id="id_currency" value="<?php echo get_currency_code_by_wpml(); ?>">

</div>