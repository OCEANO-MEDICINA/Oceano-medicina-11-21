<!-- CARRITO -->
<section id="pagospage" class="container-fluid grey">
    <div class="row">
        <div class="col-12">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="leftside">
                            <?php include('partes.php'); ?>
                        </div>
                    </div>
                </div>

            </div>
            <div class="leftside partesresumen">
                <?php include('partesresumen.php'); ?>
            </div>


            <div class="col-12 terminos">
                <label><input type="checkbox" id="cbox1" value="first_checkbox"> Acepto las <a href="">condiciones de privacidad</a></label><br>
            </div>
            <div id="id_msg_error" style="color:red;padding: 0% 12%;"> </div>
            <div id="id_msg_error_2" style="color:red;padding: 0% 12%;"> </div>
            <div class="row botonpagar">
                <div class="botoncom col-12 col-lg-6">
                    <span id="id_proceed" data-status="on" class="btn btn-pink btnfin2">Pagar</span>
                </div>
                <div class="row nonedisplay col-lg-6">
                    <div class="col-2">
                        <img src="<?= get_template_directory_uri() . '/assets/media/candado.png' ?>">

                    </div>
                    <div class="col-10">
                        <span><strong>Tu información está a salvo</strong><br>
                            Tus datos están encriptados <br> y protegidos.</span>
                    </div>

                </div>
            </div>


        </div>
    </div>
</section>
<div id="id_domain" data-domain="<?php echo return_domain(); ?>"> </div>
<div id="id_mp_key" data-key="<?php echo paste_mp_key(); ?>"> </div>
