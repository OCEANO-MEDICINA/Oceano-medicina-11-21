<header>
    <div class="contenedor">
        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar-overlay" class="navbar-overlay"></div>
            <div class="navbar-brand">
                <a id="logo" class="navbar-item logo absolute-center" href="<?= get_home_url(); ?>">
                    <img src="<?= get_template_directory_uri().'/assets/media/logo-oceano-medicina.png'; ?>" alt="Logo de la pagina de OceanoMedicina">
                </a>

                <a id="navbar-burger" role="button" class="navbar-burger" aria-label="menu" aria-expanded="false"
                    data-target="navbar-oceano">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
                <div id="icons" class="navbar-item icons">
                    <input id="dgwt-wcas-search-input-1" type="search" class="dgwt-wcas-search-input invisible"
                        placeholder="Escribí tu especialidad de interés" autocomplete="on">
                    <button id="toggleBuscador" onclick="btnSearch()" class="icons">

                        <span id="lupa" class="mdi mdi-magnify" alt=""></span>
                        <span id="search-close" alt="" class="mdi mdi-close invisible">
                    </button>
                    <?php display_woocommerce_cart() ?>
                </div>


            </div>
            <div id="navbar-oceano" class="navbar-menu">
                <div class="navbar-start">
                    <div id="nav-medicina" class="navbar-item has-dropdown is-hoverable nav-medicina">
                        <a class="navbar-link accordion-trigger">
                            Medicina
                        </a>

                        <ul class="navbar-dropdown accordion-panel">
                            <div class="overlay"></div>
                            <li><a class="navbar-item ver_todos" href="/tienda/#filter=.medicos">VER
                                    TODOS</a></li>
                            <?php foreach (get_list_specialties_with_products('medicos') as $profession): ?>
                                <li><a class="navbar-item" href="/tienda/#filter=.<?= $profession->slug ?>.medicos"><?= $profession->name ?></a></li>
                            <?php endforeach;?>                    
                        </ul>
                    </div>

                    <div id="nav-enfermeria" class="navbar-item has-dropdown is-hoverable nav-enfermeria">
                        <a class="navbar-link accordion-trigger">
                            Enfermería
                        </a>

                        <ul class="navbar-dropdown accordion-panel">
                            <div class="overlay"></div>
                            <li><a class="navbar-item ver_todos" href="/tienda/#filter=.enfermeros-auxiliares">VER
                                    TODOS</a></li>
                            <?php foreach (get_list_specialties_with_products('enfermeros-auxiliares') as $profession): ?>
                                <li><a class="navbar-item" href="/tienda/#filter=.<?= $profession->slug ?>.enfermeros-auxiliares"><?= $profession->name ?></a></li>
                            <?php endforeach;?> 
                        </ul>
                    </div>

                    <div id="nav-comunidad" class="navbar-item has-dropdown is-hoverable nav-comunidad">
                        <a class="navbar-link accordion-trigger">
                            Comunidad
                        </a>

                        <div class="navbar-dropdown navbar-dropdown-comunidad accordion-panel">
                            <div class="overlay"></div>
                                
                            <?php
                            wp_nav_menu( array( 
                                'theme_location' => 'header-comunidad', 
                                'menu_class' => 'navbar-dropdown-comunidad-menu',
                                'menu_id' => '',
                                'container' => 'ul',
                                'walker' => new Custom_Walker_Nav_Menu_Comunidad,
                            )); ?>

                        
                            <div class="navbar-item navbar-dropdown-comunidad-news">
                                
                                <?php $lastEbook = getLastEbook(); ?>

                                <div class="navbar-dropdown-comunidad-news-img" style="background: url(<?= $lastEbook->img ?>), rgba(63, 108, 187, 1); background-size: cover;"></div>

                                <!-- Este estilo permite que la descripcion del ebook se limite a 5 lineas de caracteres, esto para que no se expanda de mas el dropdown -->
                                <style>
                                    .navbar-dropdown-comunidad-news-info > p {
                                        display: -webkit-box;
                                        -webkit-line-clamp: 5;
                                        -webkit-box-orient: vertical;  
                                        overflow: hidden;
                                    }
                                </style>
                                <div class="navbar-dropdown-comunidad-news-info">
                                    <h3><?= $lastEbook->title ?></h3>
                                
                                    <?= $lastEbook->description ?>
                                    <a href="<?= $lastEbook->link ?>"> Leer más</a>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div id="search-desktop" class="navbar-item search-desktop">
                        
                        
                            <input id="dgwt-wcas-search-input-1-desktop" type="search"
                            class="dgwt-wcas-search-input invisible" placeholder="Escribí tu especialidad de interés"
                            autocomplete="on">
                            <!-- </div>  
	                    </form> -->
                        <button id="toggleBuscador-desktop" onclick="btnSearchDesktop()" class="icons">

                            <span id="lupa-desktop" class="mdi mdi-magnify" alt=""></span>
                            <span id="search-close-desktop" alt="" class="mdi mdi-close invisible">
                        </button>
                    </div>

                    <style>
                        .badge-cart{
                            background-color: #dc3545;
                            border-radius: 800px;
                            color: #ffffff;
                            font-size: 9px !important;
                            font-weight: 700;
                            line-height: 9px;
                            padding: 3.15px 5.85px;
                            text-align: center;
                            position: absolute;
                            right: 0;
                        }
                    </style>
                   
                    <?php display_woocommerce_cart() ?>

                    <a id="login-campus" class="button navbar-item login-campus"
                        href="https://suite.oceano.com/#/public/login?not_logged=true" target="_blank">
                        Acceder al campus
                    </a>

                </div>
            </div>
        </nav>
    </div>
</header>
<body>