<?php
/**
 * El header del tema
 *
 * Muestra todo desde <head> seccion hasta el <header>
 *
 * @package WordPress
 * @subpackage oceano_nuevo
 * @since Oceano Medicina 1.0
 */
?><!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>

 	<!-- Google Tag Manager -->
 	<script>
 	  (function(w, d, s, l, i) {
 	    w[l] = w[l] || [];
 	    w[l].push({
 	      'gtm.start': new Date().getTime(),
 	      event: 'gtm.js'
 	    });
 	    var f = d.getElementsByTagName(s)[0],
 	      j = d.createElement(s),
 	      dl = l != 'dataLayer' ? '&l=' + l : '';
 	    j.async = true;
 	    j.src =
 	      'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
 	    f.parentNode.insertBefore(j, f);
 	  })(window, document, 'script', 'dataLayer', 'GTM-K49GF93');
 	</script>
 	<!-- End Google Tag Manager -->

	<meta charset="<?php bloginfo('charset'); ?>">
  	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="<?php bloginfo('description'); ?>">

	<link rel="profile" href="https://gmpg.org/xfn/11" />

	<link rel="icon" href="<?= get_template_directory_uri().'/assets/media/favicon.ico'; ?>" sizes="32x32"  type="image/x-icon"/>
 	<link rel="icon" href="<?= get_template_directory_uri().'/assets/media/favicon.ico'; ?>" sizes="192x192"  type="image/x-icon"/>
 	<link rel="apple-touch-icon-precomposed" href="<?= get_template_directory_uri().'/assets/media/favicon.ico'; ?>" />
 	<meta name="msapplication-TileImage" content="<?= get_template_directory_uri().'/assets/media/favicon.ico'; ?>" />

	 <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@6.4.95/css/materialdesignicons.min.css">



 	<?php
    	$title =  wp_title('|', false, 'right');
    	$title = (!empty($title)) ? $title : "Oceano Medicina";
	?>
	
	<?php wp_head() ?>

</head>

<body id="body"  >

	
	<?php  extract($args);  show_header($type_header); ?>