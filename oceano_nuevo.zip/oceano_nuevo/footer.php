<?php
/**
 * El footer del tema
 *
 * Muestra todo desde <footer> hasta el cierre de <html>
 *
 * @package WordPresss
 * @subpackage oceano_nuevo
 * @since Oceano Medicina 1.0
 */
?>


<?php extract($args);   show_footer($type_footer); ?>

<script id="accordion" src="<?= get_template_directory_uri() . '/assets/js/accordion.js' ?>"></script>
<script id="navbar" src="<?= get_template_directory_uri() . '/assets/js/navbar.js' ?>"></script>
<script id="input-mask" src="<?= get_template_directory_uri() . '/assets/js/pagos/inputmask.min.js' ?>"></script>


<script type="text/javascript" id="jquery-dgwt-wcas-js-extra">
/* <![CDATA[ */
var dgwt_wcas = {"labels":{"post":"Post","page":"Page","vendor":"Vendor","product_plu":"Products","post_plu":"Posts","page_plu":"Pages","vendor_plu":"Vendors","sku_label":"SKU:","sale_badge":"Sale","vendor_sold_by":"Sold by:","featured_badge":"Featured","in":"in","read_more":"continue reading","no_results":"Sin resultados","show_more":"Ver todos los resultados","show_more_details":"Ver todos los resultados","search_placeholder":"Escrib\u00ed tu especialidad de inter\u00e9s","submit":"Buscar","tax_product_cat_plu":"Categories","tax_product_cat":"Category","tax_product_tag_plu":"Tags","tax_product_tag":"Tag"},"ajax_search_endpoint":"\/?wc-ajax=dgwt_wcas_ajax_search","ajax_details_endpoint":"\/?wc-ajax=dgwt_wcas_result_details","ajax_prices_endpoint":"","action_search":"dgwt_wcas_ajax_search","action_result_details":"dgwt_wcas_result_details","action_get_prices":"dgwt_wcas_get_prices","min_chars":"3","width":"auto","show_details_box":"","show_images":"","show_price":"","show_desc":"","show_sale_badge":"","show_featured_badge":"","dynamic_prices":"","is_rtl":"","show_preloader":"","show_headings":"","preloader_url":"","taxonomy_brands":"","img_url":"https:\/\/oceanomedicina.tech\/wp-content\/plugins\/ajax-search-for-woocommerce\/assets\/img\/","is_premium":"","mobile_breakpoint":"992","mobile_overlay_wrapper":"body","mobile_overlay_delay":"0","debounce_wait_ms":"400","send_ga_events":"1","enable_ga_site_search_module":"","magnifier_icon":"\t\t\t\t<svg version=\"1.1\" class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"\n\t\t\t\t\t xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\"\n\t\t\t\t\t viewBox=\"0 0 51.539 51.361\" enable-background=\"new 0 0 51.539 51.361\" xml:space=\"preserve\">\n\t\t             <path fill=\"#444\" d=\"M51.539,49.356L37.247,35.065c3.273-3.74,5.272-8.623,5.272-13.983c0-11.742-9.518-21.26-21.26-21.26 S0,9.339,0,21.082s9.518,21.26,21.26,21.26c5.361,0,10.244-1.999,13.983-5.272l14.292,14.292L51.539,49.356z M2.835,21.082 c0-10.176,8.249-18.425,18.425-18.425s18.425,8.249,18.425,18.425S31.436,39.507,21.26,39.507S2.835,31.258,2.835,21.082z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","close_icon":"\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\">\n\t\t\t\t\t<path fill=\"#ccc\" d=\"M18.3 5.71c-.39-.39-1.02-.39-1.41 0L12 10.59 7.11 5.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","back_icon":"\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" viewBox=\"0 0 16 16\">\n\t\t\t\t\t<path fill=\"#fff\" d=\"M14 6.125H3.351l4.891-4.891L7 0 0 7l7 7 1.234-1.234L3.35 7.875H14z\" fill-rule=\"evenodd\" \/>\n\t\t\t\t<\/svg>\n\t\t\t\t","preloader_icon":"\t\t\t\t<svg class=\"dgwt-wcas-loader-circular \"  viewBox=\"25 25 50 50\">\n\t\t\t\t\t<circle class=\"dgwt-wcas-loader-circular-path\" cx=\"50\" cy=\"50\" r=\"20\" fill=\"none\" stroke=\"#ddd\" stroke-miterlimit=\"10\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","custom_params":{},"convert_html":"1","suggestions_wrapper":"body","show_product_vendor":"","disable_hits":"","disable_submit":"","current_lang":"int"};
/* ]]> */
</script>


<?php wp_footer(); ?>

</body>

</html>