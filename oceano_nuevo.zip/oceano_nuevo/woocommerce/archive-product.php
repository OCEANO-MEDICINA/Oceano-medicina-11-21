<?php

/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined('ABSPATH') || exit;

get_header(null, [ 'type_header' => 'translucent' ]);

$sliderTienda = get_postType('slider-tienda', 1);
$camposTienda = get_field('slider_tienda', $sliderTienda->ID);

$valueQuickSearch = !isset($_GET['q']) ? '' : $_GET['q'];



?>
<style>
.wpdberror{ display:none; }
    #error{ display:none; }
</style>

<section id="hero" class="hero">

    <!----1.HERO---->

        <div class="swiper-hero">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <?php
                    foreach ($camposTienda as $sliderTienda) {
                        $imagenSliderTienda = $sliderTienda['imagen']['url'];
                        $imagenSliderTiendaMobile = $sliderTienda['imagen-mobile']['url'];
                    ?>
                        <div class="swiper-slide">
                            <a href="<?= $sliderTienda['link']['url']; ?>" >
                                <picture>
                                    <source media="(max-width: 768px)" srcset="<?= $imagenSliderTiendaMobile ?>">
                                    <source media="(max-width: 1920px)" srcset="<?= $imagenSliderTienda ?>">
                                    <img class="absolute-center" src="<?= $imagenSliderTienda ?>" alt="Imagen promocional de tienda">
                                </picture>
                            </a>
                        </div>
                <?php }; ?>
            </div>
        </div>

        <div class="searchbar-especialidad">
            <div class="field">
                <p class="control has-icons-left has-icons-right">
                    <input id="quicksearch2" class="input searchbar-especialidad-campo" type="search"
                        placeholder="Escribí tu especialidad de interés"  value="<?= $valueQuickSearch ?>">
                    <span class="icon is-small is-left">
                        <i class="mdi mdi-magnify"></i>
                    </span>
                    <span class="icon is-small is-right">
                        <i class="mdi mdi-chevron-right"></i>
                    </span>
                </p>
            </div>
            <input class="searchbar-especialidad-button" type="button" value="Buscar">
        </div>

    </section>

    <!----1.END-HERO---->
    <!----X.---->
    <!----X.---->
    <!----2.TIENDA---->

    <section id="tienda" class="tienda grid-w-side">
        <div class="solapa-sup"></div>
        <article class="grid-w-side-cont contenedor mx-auto">
            <div class="grid-w-side-cont-filtros">

                <div class="searchbar-filter">
                    <input class="input" id="quicksearch" type="text" placeholder="BUSCAR" value="<?= $valueQuickSearch ?>">
                </div>
                <div class="filtros-aplicados" data-filter-group="filtrosaplicados">
                    <h6>FILTROS APLICADOS</h6>
                    <ul id="output-filtros" class="output-filtros">
                    
                    </ul>
                </div>

                <div class="grid-w-side-cont-filtros-group">
                    <div class="button-group especialidad" data-filter-group="especialidad">
                        <h6>FILTRAR POR</h6>
                        <a class="filtrar-cont-button accordion-trigger" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            ESPECIALIDAD <i class="mdi mdi-chevron-down"></i>
                        </a>
                        <ul class="accordion-panel" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item filter_button screen_btn" data-filter="*">Mostrar todo</a></li>
                            <?php
                            $categories = get_regular_categories();
                            foreach ($categories as $cat) {
                            ?>

                                <li>
                                    <a class="dropdown-item filter_button screen_btn" data-filter=".<?= $cat->slug ?>"><?= $cat->name ?></a>
                                </li>
                            <?php
                            }
                            ?>
                            
                        </ul>
                    </div>
                    <div class="button-group filter-recurso" data-filter-group="tipos">

                        <a class="filtrar-cont-button accordion-trigger">TIPO DE RECURSO<i
                                class="mdi mdi-chevron-down"></i></a>
                        <ul class="accordion-panel">
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".downloadable">Ebooks</a>
                            </li>
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".bibliography">Bibliografías</a>
                            </li>
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".course">Cursos</a>
                            </li>
                        </ul>

                    </div>
                    <div class="button-group filter-profesiones" data-filter-group="profesiones" >

                        <a class="filtrar-cont-button accordion-trigger">PROFESIONES<i
                                class="mdi mdi-chevron-down"></i></a>
                        <ul class="accordion-panel">
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".medicos">Personal médico</a>
                            </li>
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".enfermeros-auxiliares">Personal de
                                    enfermería
                                    y auxiliares</a>
                            </li>
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".otra-profesion">Otra profesión</a>
                            </li>
                        </ul>

                    </div>
                    <div class="button-group filter-duracion" data-filter-group="duracion">

                        <a class="filtrar-cont-button accordion-trigger">DURACIÓN <i
                                class="mdi mdi-chevron-down"></i></a>
                        <ul class="accordion-panel">
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".hasta100">Hasta 100 hs</a>
                            </li>
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".de100">De 100 a 300 hs</a>
                            </li>
                            <li>
                                <a class="dropdown-item filter_button screen_btn" data-filter=".mas300">Más de 300 hs</a>
                            </li>
                        </ul>

                    </div>
                </div>



            </div>
            <div class="grid-w-side-cont-products">
                <div class="grid-w-side-cont-products-filters">
                    <p class="filter-count">--- ITEMS DISPONIBLES</p>
                    <div class="filtrar" ontouchstart="">
                        <a id="btnFiltrarPor" class="btn-filtro"><i class="mdi mdi-tune-variant"></i> Filtrar</a>
                        <div class="filtrar-cont menu-desplegable">

                            <div class="especialidad" data-filter-group="especialidad">
                                <a class="filtrar-cont-button accordion-trigger" type="button" id="dropdownMenuButton1"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    ESPECIALIDAD <i class="mdi mdi-chevron-down"></i>
                                </a>
                                <ul class="accordion-panel" aria-labelledby="dropdownMenuButton1">
                                    <li><a class="dropdown-item filter_button" data-filter="*">Mostrar todo</a></li>
                                    <?php foreach ($categories as $cat) { ?>
                                        <li>
                                            <a class="dropdown-item filter_button" data-filter=".<?= $cat->slug ?>"><?= $cat->name ?></a>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </div>
                            <div class="filter-recurso" data-filter-group="tipos">

                                <a class="filtrar-cont-button accordion-trigger">TIPO DE RECURSO<i
                                        class="mdi mdi-chevron-down"></i></a>
                                <ul class="accordion-panel">
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".downloadable">Ebooks</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".bibliography">Bibliografías</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".course">Cursos</a>
                                    </li>
                                </ul>

                            </div>
                            <div class="filter-profesiones" data-filter-group="profesiones">

                                <a class="filtrar-cont-button accordion-trigger">PROFESIONES<i
                                        class="mdi mdi-chevron-down"></i></a>
                                <ul class="accordion-panel">
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".medicos">Personal médico</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".enfermeros-auxiliares">Personal de
                                            enfermería
                                            y auxiliares</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".otra-profesion">Otra profesión</a>
                                    </li>
                                </ul>

                            </div>
                            <div class="filter-duracion" data-filter-group="duracion">

                                <a class="filtrar-cont-button accordion-trigger">DURACIÓN <i
                                        class="mdi mdi-chevron-down"></i></a>
                                <ul class="accordion-panel">
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".hasta100">Hasta 100 hs</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".de100">De 100 a 300 hs</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item filter_button" data-filter=".mas300">Más de 300 hs</a>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="sorting">
                        <a id="btnOrdenarPor" class="btn-filtro"><i class="mdi mdi-sort"></i> Ordenar</a>
                        <div class="sorting-cont menu-desplegable">
                            <a class="sorting-cont-button accordion-trigger" type="button" id="dropdownduracion"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                DURACION <i class="mdi mdi-chevron-down"></i>
                            </a>
                            <ul class="accordion-panel" aria-labelledby="dropdownMenuButton1">
                                <li><a class="dropdown-item order_button" data-sortby="duracionAsc">Mayor a menor <i
                                            class="mdi mdi-radiobox-blank"></i></a>
                                </li>
                                <li><a class="dropdown-item order_button" data-sortby="duracionDes">Menor a mayor <i
                                            class="mdi mdi-radiobox-blank"></i></a>
                                </li>
                            </ul>
                            <a class="sorting-cont-button accordion-trigger" type="button" id="dropdownnovedad"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                NOVEDAD <i class="mdi mdi-chevron-down"></i>
                            </a>
                            <ul class="accordion-panel" aria-labelledby="dropdownMenuButton1">
                                <li><a class="dropdown-item order_button" data-sortby="novedadAsc">Novedades Primero <i
                                            class="mdi mdi-radiobox-blank"></i></a>
                                </li>
                                <li><a class="dropdown-item order_button" data-sortby="novedadDes">Novedades Ultimo <i
                                            class="mdi mdi-radiobox-blank"></i></a>
                                </li>
                            </ul>
                            <a class="sorting-cont-button accordion-trigger" type="button" id="dropdowncosto"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                COSTO <i class="mdi mdi-chevron-down"></i>
                            </a>
                            <ul class="accordion-panel" aria-labelledby="dropdownMenuButton1">
                                <li><a class="dropdown-item order_button" data-sortby="costoAsc">Mayor a menor <i
                                            class="mdi mdi-radiobox-blank"></i></a></li>
                                <li><a class="dropdown-item order_button" data-sortby="costoDes">Menor a mayor <i
                                            class="mdi mdi-radiobox-blank"></i></a></li>
                            </ul>
                        </div>
                    </div>

                </div>

                <style>
                    .carrito-empty-cont {
                        display: -webkit-box;
                        display: -ms-flexbox;
                        display: flex;
                        -webkit-box-orient: vertical;
                        -webkit-box-direction: normal;
                        -ms-flex-direction: column;
                        flex-direction: column;
                        -webkit-box-pack: center;
                        -ms-flex-pack: center;
                        justify-content: center;
                        -webkit-box-align: center;
                        -ms-flex-align: center;
                        align-items: center;
                        padding: 3.5rem 0;
                        width: max-content;
                    }   
                    .carrito-empty-cont h1 {
                        font-size: clamp(1.5rem, 2vw, 2.25rem);
                        font-weight: 700;
                        color: #02204d;
                    }
                    .carrito-empty-cont h2 {
                        font-size: clamp(1rem, 2vw, 1.125rem);
                    }
                    .carrito-empty-cont a {
                        margin-top: 1.5rem;
                    }

                 

                </style>
                <section id="cursos-empty" class="carrito-empty" >
                    <article class="carrito-empty-cont mx-auto ">
                        <h1>La tienda esta vacia</h1>
                        <h2>¡Mira todos los cursos que tenemos para vos!</h2>
                        <a href="/tienda/#filter=.*" class="button btn btn-big">VER CURSOS</a>
                    </article>
                </section>
                <div class="grid-w-side-cont-products-grid" >

                 

                <?php 

                    $args_productos = array(
                        'post_type'      => 'product',
                        'posts_per_page' => -1,
                        'meta_query' => array(
                            array(
                                'key'     => '_stock_status',
                                'value'   => 'outofstock',
                                'compare' => '!=',
                            ),
                        ),
                    );
                    $array_productos = get_productos($args_productos);
                
                    $iteradorOrder = 0;
                    foreach ($array_productos as $product) : 
                        
                        if ($iteradorOrder === 4 && $show_plan_estudio) {
                            $iteradorOrder = $iteradorOrder + 1;
                            display_banner_plan_estudio($iteradorOrder);
                            
                        }
                        $iteradorOrder++;
                    ?>

                    <div 
                        style="order: <?= $iteradorOrder; ?>"
                        class="card product-card * <?= $product->horasFiltro; ?> <?= $product->post_type; ?>  <?= $product->product_categories_filter;  ?> <?= $product->product_profession; ?>" data-costo="<?=$product->precio; ?>" data-horas="<?= $product->duracion; ?>" data-novedad="<?= $product->novedad; ?>" disabled=''
                    >
                        <div class="card-img"
                            style="background: url(<?= $product->img ?>), linear-gradient(transparent 75%, #00000035 100%);">
                            <?php
                                if($product->is_course):
                                    foreach ($product->product_profession_array as $profesion) {  
                                        if ($profesion->name == 'medicos'): ?>
                                            <a href="/tienda" class="tags tags-medicina">Medicina</a>
                                        <?php elseif ($profesion->name == 'enfermeros-auxiliares'): ?>
                                            <a href="/tienda" class="tags tags-enfermeria">Enfermería</a>
                                        <?php endif; } ?>
                                    
                                <?php elseif($product->is_downloadable): ?>
                                    <a href="/tienda" class="tags tags-bibliografia">Ebook</a>
                                <?php else: ?>
                                    <a href="/tienda" class="tags tags-bibliografia">bibliografía</a>
                            <?php endif; ?>

                        </div>

                        <div class="card-info">
                            <div class="card-info-sup">
                            <?php if ($product->is_course): ?>
                                    <p class="area"><?= $product->product_categories ?></p>
                                    <span class="horas"><i class="mdi mdi-clock-outline"></i><?= $product->duracion ?> horas</span>
                                <?php elseif($product->is_bibliography): ?>
                                    <span class="horas"><i class="mdi mdi-truck-fast-outline"></i>Envios a todo el país</span>
                            <?php endif; ?>
                            </div>

                            <div class="card-info-title"><?= $product->title ?></div>

                            <?php if (!$product->is_downloadable): ?>
                            <div class="card-info-footer">
                                <div class="card-info-footer-precio">
                                    <?php if ($product->ribbon || !$product->base_old_price  ) : ?>
                                    <p class="cuotas"><?= get_max_installments(); ?> <?= get_installments_string(); ?></p>
                                    <p class="price">Sin interés</p>
                                     <?php else : ?>
                                         <p class="cuotas"><?= get_max_installments(); ?> <?= get_installments_string() ?> de</p>
                                         <p class="price" ><?= get_currency_symbol(); ?><?= $product->precio ?></p>
                                    <?php endif; ?>
                                 
                                </div>
                                <a href="<?= $product->link ?>" class="card-info-footer-boton btn btn-mid">Descubrir</a>
                            </div>
                            <?php else: ?>
                            <div class="card-info-footer" style=" justify-content: space-around;">

                                <a href="<?= $product->link ?>" class="card-info-footer-boton btn btn-mid">Descargar</a>
                            </div>

                            <?php endif; ?>

                        </div>
                    </div>
                    

                    <?php endforeach; ?>
                </div>
            </div>
        </article>
    </section>



    <?php get_footer(null, [ 'type_footer' => 'full' ]); ?>
    

