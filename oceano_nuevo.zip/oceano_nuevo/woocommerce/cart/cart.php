<?php

/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.5.0
 */


 
defined('ABSPATH') || exit;
$notices = wc_get_notices();
wc_clear_notices();
do_action('woocommerce_before_cart');

if (isset($_SESSION['plan_de_estudio'])) {
    $plan = $_SESSION['plan_de_estudio'];
}
else {
    $plan = '';
}

$coupons = WC()->cart->get_coupons();
// print_r($coupons);
$totalventa = get_cart_total_installments(1);
// $precioAntesDescuento = WC()->cart->cart_contents_total;


if ($plan != '') {

    $plan0 = null;

    switch ($_SESSION['plan_de_estudio']) {
        case '12':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_12', $plan0->ID)[0];
            break;
        case '18':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_18', $plan0->ID)[0];
            break;
        case '24':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_24', $plan0->ID)[0];
            break;
    }
    
    $totalventa = array_reduce($plan0['precios'], 'filterPais');
   
    foreach ($coupons as $key => $coupon) {
        $discount_type = $coupon->get_discount_type(); // Get coupon discount type
        $coupon_amount = $coupon->get_amount();

        if ($discount_type == 'percent') {
            $totalventa = $totalventa - (($totalventa * $coupon_amount) / 100);
        }
    }
}


function get_cart_total_installments_nuevo($i = 1, $totalventa)
{
    if ($_SESSION['plan_de_estudio'] != '') {
        return ($totalventa / $i);
    }
    return get_cart_total_installments($i);
}

// print_r(WC()->cart->cart_contents);  

get_header(null, [ 'type_header' => 'translucent' ]); ?>

<style>
    @media screen and (min-width: 767px){.hero { background: 25% top url(<?= $imagensHero;?>); }}
    .wpdberror{ display:none; }
    #error{ display:none; }
 </style>


<!-- Notificacion de error -->

<?php if ($notices['error']): ?>

        <section id="notification-error" class="notification error">
         <article class="notification-cont">
             <div class="info">
                 <i class="mdi mdi-close-circle is-size-1 has-text-danger"></i>
                 <div class="info-text">
                     <h5>Cupon no valido</h5>
                     <h6>El cupon "<?= explode('"', $notices['error'][0]['notice'])[1] ?>" no es valido en este momento</h6>
                 </div>
             </div>
             <button id="close-notif"><i class="mdi mdi-close is-size-5"></i></button>
         </article>
        </section>

<?php endif;?>

 <!-- Notificacion de Confirmacion -->

 <section id="notification-success" class="notification success" style="display: none;">
    <article class="notification-cont">
        <div class="info">
            <i class="mdi mdi-check-circle is-size-1 has-text-success"></i>
            <div class="info-text">
                <h5>Tipo de confirmación</h5>
                <h6>Descripción de la confirmación</h6>
            </div>
        </div>
        <button><i class="mdi mdi-close is-size-5"></i></button>
    </article>
</section>

 <!-- INICIO DE CARRITO -->

<section id="breadcrumbs">
    <article class="breadcrumbs-cont contenedor">
        <nav class="breadcrumb" aria-label="breadcrumbs">
            <ul>
                <li><a href="#">Carrito</a></li>
                <li class="is-active"><a href="#" aria-current="page">Mis productos</a></li>
            </ul>
        </nav>
    </article>
</section>



<!-- MOSTRAR CARRITO VACIO -->

<?php if (sizeof(WC()->cart->cart_contents) == 0) { ?>
    <section id="carrito-empty" class="carrito-empty">
        <article class="carrito-empty-cont contenedor">
            <h1>Tu carrito esta vacio</h1>
            <h2>¡Mira todos los cursos que tenemos para vos!</h2>
            <a href="/tienda" class="button btn btn-big">VER CURSOS</a>
        </article>
    </section>
<?php  } else { ?>



<section id="carrito" class="carrito carrito-planes">
     <form class="woocommerce-cart-form" action="<?php echo esc_url(wc_get_cart_url()); ?>" method="post">
     <article class="carrito-cont contenedor">
<?php
 if ($plan != '') {
 ?>

       
            <div class="carrito-plan-grid">
                <div class="carrito-plan-grid-side-left">
                    <img src="<?= get_template_directory_uri().'/assets/media/enfermero-'. $plan .'.png'; ?>" alt="Imagen del plan">
                </div>
                <div class="carrito-plan-grid-desktop">
                    <div class="carrito-plan-card">
                        <span>Enfermería</span>
                        <h1>PLAN DE <?= $plan ?> MESES</h1>
                        <div class="carrito-plan-card-details">
                            <a class="accordion-trigger mr-3">VER PLANES DE ESTUDIO <i
                                    class="mdi mdi-chevron-down"></i></a>
                            <a id='eliminar-plan'><i class="mdi mdi-trash-can-outline"></i>ELIMINAR</a>
                            <div class="accordion-panel">
                            <?php
                                foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                                    $nacCert = $intCert = null;
                                    $item_id = (!empty($cart_item['variation_id'])) ? $cart_item['variation_id'] : '';
                                    $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                                    $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                                    $father_post_id = get_field('father_post_id', $product_id);
                                    $product_name = get_the_title($father_post_id);
                                    $category = (get_field("main_category", $father_post_id)) ? get_field("main_category", $father_post_id) : null;
                                    $category_name = ($category) ? $category->name : "Desconocido";
                                    $category_slug = ($category) ? $category->slug : "";
                                    if ($item_id) {
                                        $nacCert = get_cart_item_local_cert($item_id);
                                        $nacCertSlug = get_cart_item_local_cert_slug($item_id);
                                        $intCert = get_cart_item_int_cert($item_id);
                                        $intCertSlug = get_cart_item_int_cert_slug($item_id);
                                        $int_school = get_field('int_schools', $product_id);
                                    } ?>
                                 <?php
                                    if ($plan != '') {
                                    ?>
                                       <div class="carrito-card">
                                           <div class="carrito-card-img">
                                               <img src="<?= get_cart_product_image_url($_product); ?>" alt="Imagen del curso de <?= $product_name ?>">
                                           </div>
                                           <div class="carrito-card-info">
                                               <span><?= get_primary_category_string($father_post_id); ?></span>
                                               <h2><?= $product_name ?></h2>
                                               <div class="codigo"> 
                                                   <?php
                                                   $codigo_curso = get_field('codigo_unico', $father_post_id);
                                                   if ($codigo_curso) { ?>
                                                       <h4>Código de curso: <?= $codigo_curso ?></h4>
                                                   <?php } ?>
                                                
                                                 
                                               </div>
                                           </div>
                                       </div>
                                    <?php } 
                                } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carrito-plan-grid-mobile">
                <?php
                    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                        $nacCert = $intCert = null;
                        $item_id = (!empty($cart_item['variation_id'])) ? $cart_item['variation_id'] : '';
                        $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                        $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                        $father_post_id = get_field('father_post_id', $product_id);
                        $product_name = get_the_title($father_post_id);
                        $category = (get_field("main_category", $father_post_id)) ? get_field("main_category", $father_post_id) : null;
                        $category_name = ($category) ? $category->name : "Desconocido";
                        $category_slug = ($category) ? $category->slug : "";
                        if ($item_id) {
                            $nacCert = get_cart_item_local_cert($item_id);
                            $nacCertSlug = get_cart_item_local_cert_slug($item_id);
                            $intCert = get_cart_item_int_cert($item_id);
                            $intCertSlug = get_cart_item_int_cert_slug($item_id);
                            $int_school = get_field('int_schools', $product_id);
                        } ?>
                     <?php
                        if ($plan != '') {
                        ?>
                           <div class="carrito-card">
                               <div class="carrito-card-img">
                                   <img src="<?= get_cart_product_image_url($_product); ?>" alt="Imagen del curso de <?= $product_name ?>">
                               </div>
                               <div class="carrito-card-info">
                                   <span><?= get_primary_category_string($father_post_id); ?></span>
                                   <h2><?= $product_name ?></h2>
                                   <div class="codigo"> 
                                       <?php
                                       $codigo_curso = get_field('codigo_unico', $father_post_id);
                                       if ($codigo_curso) { ?>
                                           <h4>Código de curso: <?= $codigo_curso ?></h4>
                                       <?php } ?>
                                       
                                   </div>
                               </div>
                           </div>
                        <?php } 
                    } ?>
                </div>
            </div>
     <?php
     } else {?>
        <div class="carrito-grid">
            <div class="carrito-grid-cursos">

            <?php foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                $nacCert = $intCert = null;
                $item_id = (!empty($cart_item['variation_id'])) ? $cart_item['variation_id'] : '';
                $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item,$cart_item_key);
                $father_post_id = get_field('father_post_id', $product_id);
                $product_name = get_the_title($father_post_id);
                $category = (get_field("main_category", $father_post_id)) ? get_field("main_category", $father_post_id) :null;
                $category_name = ($category) ? $category->name : "Desconocido";
                $category_slug = ($category) ? $category->slug : "";
                if ($item_id) {
                    $nacCert = get_cart_item_local_cert($item_id);
                    $nacCertSlug = get_cart_item_local_cert_slug($item_id);
                    $intCert = get_cart_item_int_cert($item_id);
                    $intCertSlug = get_cart_item_int_cert_slug($item_id);
                    $int_school = get_field('int_schools', $product_id);
                } ?>

                <div class="carrito-card">
                    <div class="carrito-card-img">
                        <img src="<?= get_cart_product_image_url($_product); ?>" alt="Imagen del curso de <?= $product_name ?>">
                    </div>
                    <div class="carrito-card-info">
                        <span><?= get_primary_category_string($father_post_id); ?></span>
                        <h2><?= $product_name ?></h2>
                        <div class="codigo"> 
                            <?php
                            $codigo_curso = get_field('codigo_unico', $father_post_id);
                            if ($codigo_curso) { ?>
                                <h4>Código de curso: <?= $codigo_curso ?></h4>
                            <?php } ?>
                        <a href="<?= esc_url(wc_get_cart_remove_url($cart_item_key)); ?>"><i class="mdi mdi-trash-can-outline"></i>ELIMINAR</a>
                        </div>
                    </div>
                    <?php $precioAntesDescuento = $precioAntesDescuento + $cart_item['line_subtotal'];?>
                    <h5 class="carrito-card-price"><?= get_currency_symbol(); ?><?= format_number($cart_item['line_subtotal']); ?><span><?php
                                                            $currency_code = get_field('currency_3_digits_code', 'options');
                                                            echo $currency_code;
                                                            ?></span></h5>
                </div>

                <?php } ?>

            </div>
        </div>
    <?php } ?>
</article>
<article class="carrito-footer">
            <div class="carrito-footer-cont contenedor">
                <!-- Precio total-->
                <?php if ($plan == '') { ?>
                    <div class="total-price">
                        <div>
                            <h5>TOTAL</h5>
                            <h6 ><?php if($precioAntesDescuento > $totalventa && $coupons):?>
                                <span class="before-discount" ><?= get_currency_symbol(); ?><?= format_number($precioAntesDescuento); ?></span>
                                <?php endif;?>
                                <?= get_currency_symbol(); ?><?= format_number($totalventa); ?>
                
                                <span> 
                                    <?php $currency_code = get_field('currency_3_digits_code', 'options'); echo $currency_code; ?>
                                </span>
                            </h6>
                            <h6 id="precio-total">

                            </h6>
                        </div>
                    </div>
                <?php } ?>

                <!-- Seleccionar cuotas o plan seleccioando -->

                <?php if ($plan != '') { ?>
                    <div class="plan-select">
                        <div class="plan-select-img">
                            <i class="mdi mdi-credit-card-multiple-outline"></i>
                        </div>
                        <div class="plan-select-info">
                            <h4>PLAN SELECCIONADO</h4>
                                <h5 data-amount="<?php echo $totalventa; ?>" id="id_label_total_price" class="carrito-card-price">
                                <?= get_currency_symbol(); ?><?= format_number(get_cart_total_installments_nuevo($plan, $totalventa)); ?>
                             <span>
                                <?php
                                    $currency_code = get_field('currency_3_digits_code', 'options');
                                    echo $currency_code;
                                ?>/mes durante <?= $plan ?> meses</span>
                            </h5>
                        </div>
                    </div>

                <?php } else { ?>

                    <div class="cuotas-select">
                        <div class="plan-select-img">
                            <i class="mdi mdi-credit-card-multiple-outline"></i>
                        </div>
                        <div class="plan-select-info">
                            <h4>SELECCIONAR CUOTAS</h4>
                            <select id="installmentsSelect" name="installmentsSelect" class="selectpicker">

                                <?php foreach (get_available_installments(WC()->cart->get_cart()) as $installment) { ?>
                                    <option value="<?= $installment; ?>" <?php if (get_installments() == $installment) { echo 'selected';} ?> >
                                        <?= $installment; ?> <?= get_installments_string($installment); ?> sin interes de <?= get_currency_symbol(); ?><?= format_number(get_cart_total_installments($installment, $totalventa)); ?> 
                                            <?php
                                                $currency_code = get_field('currency_3_digits_code', 'options');
                                                echo $currency_code;
                                            ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                 <?php } ?>

                <?php if ($coupons) { 
                    foreach ($coupons as $coupon): ?>
                    <div class="discount aplicado">
                        <div class="discount-img">
                            <i class="mdi mdi-ticket-percent-outline"></i>
                        </div>
                        <div class="discount-info">
                            <h4>CUPÓN DE DESCUENTO</h4>
                            <div class="discount-info-campos">
                                <input type="text" value="<?= strtoupper($coupon->get_code()) ?>" name="coupon_code" placeholder="<?= strtoupper($coupon->get_code()) ?>"        id="codigodescuento">
                                <!-- <i id="borrar-coupon-descuento-error" class="mdi mdi-close-circle" ></i> -->
                                <i class="mdi mdi-check-circle"></i>
                                <input id='vaciar_cupones' class="btn btn-mid" name="apply_coupon" type="submit" value="QUITAR"></input>
                               
                            </div>
                        </div>
                    </div>
                <?php 
                    endforeach;
                } elseif ($notices['error']) { ?>

                    <div class="discount error">
                        <div class="discount-img">
                            <i class="mdi mdi-ticket-percent-outline"></i>
                        </div>
                        <div class="discount-info">
                            <h4>CUPÓN DE DESCUENTO</h4>
                            <div class="discount-info-campos">
                                <input type="text" value="" name="coupon_code" id="codigodescuento" placeholder='' >
                                <!-- <i id="borrar-coupon-descuento-error" class="mdi mdi-close-circle" ></i> -->
                                <button class="btn btn-mid" type="submit" name="apply_coupon" value="Aplicar" > APLICAR </button>
                            </div>
                        </div>
                    </div>
                    
                <?php } else { ?>

                    <div class="discount">
                        <div class="discount-img">
                            <i class="mdi mdi-ticket-percent-outline"></i>
                        </div>
                        <div class="discount-info">
                            <h4>CUPÓN DE DESCUENTO</h4>
                            <div class="discount-info-campos">
                                <input type="text" value="" name="coupon_code"placeholder="DESCUENTO"  id="codigodescuento"  >
                                
                                <button class="btn btn-mid" type="submit" name="apply_coupon" value="Aplicar" > APLICAR </button>
                            </div>
                        </div>
                    </div>
                    
                <?php } ?>

            </div>
        </article>

        <?php
         // print_r(check_duplicados_cart(1));
         if (check_duplicados_cart() == 0) {
         ?>

         <?php
         } else {
         ?>

            <section id="notification" class="notification error duplicados">
                 <article class="notification-cont">
                     <div class="info">
                         <i class="mdi mdi-close-circle is-size-1 has-text-danger"></i>
                         <div class="info-text">
                             <h5>¡Atención!</h5>
                             <h6> Tenés productos repetidos en tu carrito.</h6>
                         </div>
                     </div>
                     <button type="button"  class="botonduplicado btn btn-mid">Eliminar duplicados</button>
                 </article>
            </section>

             <!-- <div class="duplicados">
                  style="display: none;"
                 <img class="closeduplicados" src="/wp-content/themes/oceano/_img-newTheme/close 1.png">
                 <h4 class="textduplicado">¡Atención! Tenés productos repetidos en tu carrito.</h4>
                 <button type="button" class="button botonduplicado">Eliminar duplicados</button>
             </div> -->
         <?php
         }
         ?>


        <div class="control-buttons">
            <a class="c-hover prev" onclick="history.back(-1)" >VOLVER ATRÁS</a>
            <a class="c-hover next" onclick="location.href='/pagos/'" >FINALIZAR COMPRA</a>
        </div>
        
    </form>
</section>


<?php } ?>
 
<?php do_action('woocommerce_before_cart_table'); ?>

<?php do_action('woocommerce_cart_actions'); ?>

<?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>

<?php do_action('woocommerce_after_cart'); ?>



<?php get_footer(null, [ 'type_footer' => 'full' ]); ?>




