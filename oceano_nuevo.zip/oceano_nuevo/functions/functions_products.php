<?php 
/* 
    Esta funcion viene a remplazar todas las consultas que se hacen a travez de la pagina para
    obtener los productos, ya sean cursos, descargables, bibliografias, etc.
    Recibe diversos parametros y luego devuelve un array de objetos para poder ser reccorrido
*/
function get_productos($args_query){
  
    $products = new WP_Query($args_query);

    if($products):
        foreach ($products->posts as $product):
          
            $father_id = get_field('father_post_id', $product->ID);
            $product_id = $product->ID;
            $product_title = get_field('short_name', $father_id);
            $product_title = ($product_title) ? $product_title : get_the_title($father_id);

            $thumbnail_img_url = get_field('thumbnail', $father_id);
            $thumbnail_img_url = ($thumbnail_img_url) ? $thumbnail_img_url : '/wp-content/uploads/2018/11/287x192.png';

            $base_old_price = get_base_price($product->ID, get_installments());
            $base_price = get_base_sale_price($product->ID, get_installments());
            $precio = format_number(get_product_price_installments($product->ID, get_max_installments()));

            $nac_schools = get_field('nac_schools', $product->ID);
            $int_school = get_field('int_schools', $product->ID);
            $ignore_int = get_field('ignore_int_cert', $father_id);
            $certs_classes = ($nac_schools) ? ' nacional ' : '';
            if (!$ignore_int) {
                $certs_classes .= ($int_school) ? 'internacional' : '';
            };
                    
          
            $hotsale = get_field("hotsale", $product->ID);
            $nuevo = get_field("novedad", $father_id);
            $horas = get_field("duration", $father_id);

            $horasFiltro = get_product_duration_class($horas);
            

            $purchase_option = (get_field('purchase_option', $product_id)) ? get_field('purchase_option', $product_id) : get_field('purchase_option', $father_id);
            $ribbon = ($purchase_option == 'catalogo') ? true : false;
            $isbn = get_field('isbn', $father_id);
          

            $product_categories_array = wc_get_product_category_list($product->ID, '_', '', '');
            $product_categories = strip_tags(removeAccents(strtolower(str_replace('_', ' ', str_replace(' ', '-', $product_categories_array)))));
            $product_categories_clean = strip_tags(str_replace('_', ' ',$product_categories_array));
            
            $product_link = get_the_permalink($product->ID);
            
            $post_type = get_post_type($father_id);
            $is_course = ($post_type == 'course') ? true : false;
            $is_downloadable = ($post_type == 'downloadable') ? true : false;
            $is_bibliography = ($post_type == 'bibliography') ? true : false;

            $product_profession_array = get_professions_list($father_id);
            $concat_professiones = '';
                foreach ($product_profession_array as $profesion) {  
                    $concat_professiones .= $profesion->name . ' ';
                }
            
            
            

            $product_array[] = (object) array(
                'id' => $product_id,
                'title' => $product_title,
                'img' => $thumbnail_img_url,
                'base_old_price' => $base_old_price,
                'precio' => $precio,
                'link' => $product_link,
                'post_type' => $post_type,
                'ribbon'=> $ribbon,
                'isbn' => $isbn,
                'novedad' =>$nuevo,
                'duracion' => $horas,
                'horasFiltro' => $horasFiltro,
                'product_categories' => $product_categories_clean,
                'product_categories_filter' => $product_categories,
                'product_profession' => $concat_professiones,
                'product_profession_array' => $product_profession_array,
                'is_course' => $is_course,
                'is_downloadable' => $is_downloadable,
                'is_bibliography' => $is_bibliography
                

            );
        endforeach;
        // reset custom query
        wp_reset_query();

        return $product_array;
    endif;
}

function get_product_data($product){
  

    if($product):
            $father_id = get_field('father_post_id', $product->ID);
            $product_id = $product->ID;

            $product_title = get_field('short_name', $father_id);
            $product_title = ($product_title) ? $product_title : get_the_title($father_id);

            $thumbnail_img_url = get_field('thumbnail', $father_id);
            $thumbnail_img_url = ($thumbnail_img_url) ? $thumbnail_img_url : '/wp-content/uploads/2018/11/287x192.png';

            $base_old_price = get_base_price($product->ID, get_installments());
            $base_price = get_base_sale_price($product->ID, get_installments());
            $precio = format_number(get_product_price_installments($product->ID, get_max_installments()));

            $nac_schools = get_field('nac_schools', $product->ID);
            $int_school = get_field('int_schools', $product->ID);
            $ignore_int = get_field('ignore_int_cert', $father_id);
            $certs_classes = ($nac_schools) ? ' nacional ' : '';
            if (!$ignore_int) {
                $certs_classes .= ($int_school) ? 'internacional' : '';
            };
                    
          
            $hotsale = get_field("hotsale", $product->ID);
            $nuevo = get_field("novedad", $father_id);
            $horas = get_field("duration", $father_id);

            $horasFiltro = get_product_duration_class($horas);
            

            $purchase_option = (get_field('purchase_option', $product_id)) ? get_field('purchase_option', $product_id) : get_field('purchase_option', $father_id);
            $ribbon = ($purchase_option == 'catalogo') ? true : false;
            $isbn = get_field('isbn', $father_id);
          

            $product_categories_array = wc_get_product_category_list($product->ID, '_', '', '');
            $product_categories = strip_tags(removeAccents(strtolower(str_replace('_', ' ', str_replace(' ', '-', $product_categories_array)))));
            $product_categories_clean = strip_tags(str_replace('_', ' ',$product_categories_array));
            
            $product_link = get_the_permalink($product->ID);
            
            $post_type = get_post_type($father_id);
            $is_course = ($post_type == 'course') ? true : false;
            $is_downloadable = ($post_type == 'downloadable') ? true : false;
            $is_bibliography = ($post_type == 'bibliography') ? true : false;

            $product_profession_array = get_professions_list($father_id);
            $concat_professiones = '';
                foreach ($product_profession_array as $profesion) {  
                    $concat_professiones .= $profesion->name . ' ';
                }
            

            $product_array[] = (object) array(
                'id' => $product_id,
                'title' => $product_title,
                'img' => $thumbnail_img_url,
                'base_old_price' => $base_old_price,
                'precio' => $precio,
                'link' => $product_link,
                'post_type' => $post_type,
                'ribbon'=> $ribbon,
                'isbn' => $isbn,
                'novedad' =>$nuevo,
                'duracion' => $horas,
                'horasFiltro' => $horasFiltro,
                'product_categories' => $product_categories_clean,
                'product_categories_filter' => $product_categories,
                'product_profession' => $concat_professiones,
                'product_profession_array' => $product_profession_array,
                'is_course' => $is_course,
                'is_downloadable' => $is_downloadable,
                'is_bibliography' => $is_bibliography
                

            );

        return $product_array;
    endif;
}



//Se utiliza para asignar el tag de duración, y poder filtar los productos por su duración en la página de shop.
function get_product_duration_class($duration)
{
    $duration = (int)$duration;
    switch (true) {
        case $duration <= 100:
            $duration_class = 'hasta100';
            break;
        case $duration <= 300:
            $duration_class = 'de100';
            break;
        case $duration > 300:
            $duration_class = 'mas300';
            break;
    }
    return $duration_class;
}


function get_related_ebook($category_slug)
{
    $related_ebooks = [];

    global $post;
    $posts = new WP_Query(array(
        'post_type' => 'downloadable',
        'posts_per_page' => -1,
        'post__not_in' => [$post->ID],
        'post_status' => 'publish',
    ));
    if ($posts->have_posts()) :
        while ($posts->have_posts()) : $posts->the_post();

            $father_id = get_field("father_post_id", $post->ID);
            if ($father_id) {
                $category = get_field('main_category', $father_id);
                if ($category_slug == $category->slug) {
                    if ($post) {
                        $father_id = get_field("father_post_id", $post->ID);
                        if (is_downloadable($father_id)) {
                            $related_ebooks[]['product'] = $post;
                        }
                    }
                }
            }
        endwhile;
    endif;
    // reset custom query
    wp_reset_query();
    if ($related_ebooks) {
        return $related_ebooks;
    } else {
        //return the latest one
        $posts = new WP_Query(array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post__not_in' => [$post->ID],
            'post_status' => 'publish',
        ));
        if ($posts->have_posts()) :
            while ($posts->have_posts()) : $posts->the_post();
                if ($post) {
                    $father_id = get_field("father_post_id", $post->ID);
                    if (is_downloadable($father_id)) {
                        $related_ebooks[]['product'] = $post;
                        break;
                    }
                }
            endwhile;
        endif;
    }
    return $related_ebooks;
}

function get_similar_ebook($category, $is_enfermeria, $ebook_id)
{
    $is_enfermeria = $is_enfermeria ? '34028' : '34009';
    $recomended_ebook_array = [];
    $others_ebooks_array = [];
    $ebook_array = [];

    //trae SOLO el ebook que recomienda el curso
    $query_recomended_ebook = new WP_Query(array(
        'post_type' => 'product',
        'posts_per_page' => 1,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => 'father_post_id',
                'value' => [$ebook_id],
            ),
    )));

    $query_all_filtered_ebooks = new WP_Query(array(
        'post_type' => 'downloadable',
        'posts_per_page' => -1,
        'post__not_in' => [$ebook_id],
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => 'main_category',
                'value' => $category->term_id,
                
            ),
        )));

    if (!$query_all_filtered_ebooks || count($query_all_filtered_ebooks->posts) <= 2) {
        $query_all_limited_ebooks = new WP_Query(array(
            'post_type' => 'downloadable',
            'posts_per_page' => 4 ,
            'post__not_in' => array($ebook_id),
            'post_status' => 'publish',
            ));
        $query_all_ebooks = new WP_Query();
        $query_all_ebooks->posts = array_merge( $query_all_filtered_ebooks->posts, $query_all_limited_ebooks->posts );
        $query_all_ebooks->post_count = $query_all_filtered_ebooks->post_count + $query_all_limited_ebooks->post_count;
    }
    else {
        $query_all_ebooks = $query_all_filtered_ebooks;
    }

    if ( $query_recomended_ebook->have_posts() ) :
        while ( $query_recomended_ebook->have_posts() ) : $query_recomended_ebook->the_post();
            $product_id = get_the_ID();
            $father_id = get_field('father_post_id', $product_id);
            $product_title = get_field('short_name', $father_id);
            $product_title = ($product_title) ? $product_title : get_the_title($father_id);
            $thumbnail_img_url = get_field('thumbnail', $father_id);
            $thumbnail_img_url = ($thumbnail_img_url) ? $thumbnail_img_url : '/wp-content/uploads/2018/11/287x192.png';
            $category_ebook = (get_field("main_category", $father_id)) ??  null;
            $category_name = ($category_ebook) ? $category_ebook->name : "Desconocido";
            $product_profession = get_field("professions", $father_id);
          
            $product_link = get_the_permalink($product_id);
            $recomended_ebook_array[] = (object) array(
                'id' => $product_id,
                'father_id' => $father_id,
                'title' => $product_title,
                'img' => $thumbnail_img_url,
                'link' => $product_link,
                'product_category' => $category_name,
                'product_profession' => $product_profession,
            );

        endwhile; 
        $Contador = 0;
        while ( $query_all_ebooks->have_posts() && $Contador < 1) : $query_all_ebooks->the_post();
            
            $Contador++;
            $product_id = get_the_ID();
            
            $product_title = get_field('short_name');
            $product_title = ($product_title) ? $product_title : get_the_title();
            $thumbnail_img_url = get_field('thumbnail');
            $thumbnail_img_url = ($thumbnail_img_url) ? $thumbnail_img_url : '/wp-content/uploads/2018/11/287x192.png';
            $category_ebook = (get_field("main_category")) ??  null;
            $category_name = ($category_ebook) ? $category_ebook->name : "Desconocido";
            $product_profession = get_field("professions");
            $query_producto_related = new WP_Query(array(
                'post_type'      => 'product',
                'posts_per_page' => 1,
                'post_status' => 'publish',
                'meta_query' => array(
                  array('key' => 'father_post_id', 'value' => $product_id)
                )
              ));
              if($query_producto_related):
                foreach ($query_producto_related->posts as $ebook_related):

                    $product_link = get_the_permalink($ebook_related->ID);
                endforeach; 
             endif; 
            
            $others_ebooks_array[] = (object) array(
                'id' => $product_id,
                'father_id' => $father_id,
                'title' => $product_title,
                'img' => $thumbnail_img_url,
                'link' => $product_link,
                'product_category' => $category_name,
                'product_profession' => $product_profession,
            );
        endwhile; 
        
        
        $ebook_array = array_merge($recomended_ebook_array, $others_ebooks_array);
        
    elseif(!$query_recomended_ebook->have_posts()): 
        $Contador = 0;
        while ( $query_all_ebooks->have_posts() && $Contador < 2) : $query_all_ebooks->the_post();
            
            $Contador++;
            $product_id = get_the_ID();
            
            $product_title = get_field('short_name');
            $product_title = ($product_title) ? $product_title : get_the_title();
            $thumbnail_img_url = get_field('thumbnail');
            $thumbnail_img_url = ($thumbnail_img_url) ? $thumbnail_img_url : '/wp-content/uploads/2018/11/287x192.png';
            $category_ebook = (get_field("main_category")) ??  null;
            $category_name = ($category_ebook) ? $category_ebook->name : "Desconocido";
            $product_profession = get_field("professions");
            $query_producto_related = new WP_Query(array(
                'post_type'      => 'product',
                'posts_per_page' => 1,
                'post_status' => 'publish',
                'meta_query' => array(
                  array('key' => 'father_post_id', 'value' => $product_id)
                )
              ));
              if($query_producto_related):
                foreach ($query_producto_related->posts as $ebook_related):
                    $product_link = get_the_permalink($ebook_related->ID);
                endforeach; 
             endif; 
            
            $others_ebooks_array[] = (object) array(
                'id' => $product_id,
                'father_id' => $father_id,
                'title' => $product_title,
                'img' => $thumbnail_img_url,
                'link' => $product_link,
                'product_category' => $category_name,
                'product_profession' => $product_profession,
            );
        endwhile; 
        $ebook_array = $others_ebooks_array;

     endif; 
     wp_reset_postdata(); 
     

     return $ebook_array;

}


function getLastEbook()
{
    $query_ebook = new WP_Query(array(
        'post_type' => 'downloadable',
        'posts_per_page' => 1,
        'post_status' => 'publish',
      ));

    while ($query_ebook->have_posts()) : $query_ebook->the_post();
        $ebook_id =  get_the_ID();
        $ebook_title = get_the_title();
        $ebook_img = get_the_post_thumbnail_url();
        $description_ebook = get_field('why_course')['description_box']['description'];

        $query_producto_related = new WP_Query(array(
            'post_type'      => 'product',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'meta_query' => array(
              array('key' => 'father_post_id', 'value' => $ebook_id)
            )
          ));
          if($query_producto_related):
            foreach ($query_producto_related->posts as $ebook_related):
                $ebook_link = get_the_permalink($ebook_related->ID);
            endforeach; 
         endif; 

    
        $ebook_array = (object) array(
            'title' => $ebook_title,
            'img' => $ebook_img,
            'description' => $description_ebook,
            'link' => $ebook_link,
        );
    endwhile;
    // reset custom query
    wp_reset_query();
    return $ebook_array;
}

function get_professions_list($post_id)
{
    $professions = get_field('professions', $post_id);
    $list = [];
    if (is_array($professions)) {
        foreach ($professions as $profession) {
            $profession   = get_post($profession);
            $list[] =(object) array(
                'title'=> $profession->post_title, 
                'name'=> $profession->post_name
            );
        }
    }
    return $list;
}

function find_product_by_parent($father_id)
{
    $products = get_posts(array(
        'numberposts'        => 1,
        'post_type'            => 'product',
        'suppress_filters'     => 0, //for the current language
        'meta_key'            => 'father_post_id',
        'meta_value'        => $father_id
    ));
    if ($products) {
        foreach ($products as $product) {
            return $product;
        }
    }
    
    return false;
}


//Obtiene las categorías de los productos por país evitando la categoría "uncategorized"
function get_regular_categories()
{
    $taxonomy     = 'product_cat';
    $orderby      = 'name';
    $show_count   = 0;      // 1 for yes, 0 for no
    $pad_counts   = 0;      // 1 for yes, 0 for no
    $hierarchical = 1;      // 1 for yes, 0 for no
    $title        = '';
    $empty        = 1;

    $args = array(
        'taxonomy'     => $taxonomy,
        'orderby'      => $orderby,
        'show_count'   => $show_count,
        'pad_counts'   => $pad_counts,
        'hierarchical' => $hierarchical,
        'title_li'     => $title,
        'hide_empty'   => $empty
    );
    $all_categories = get_categories($args);
    $regular_categories = array_fill(0, 100, false);
    $avoid_categories = ["uncategorized", "bibliografia"];
    foreach ($all_categories as $cat) {
        $order = get_term_meta($cat->term_id, 'order', true);
        if (!in_array(strtolower($cat->name), $avoid_categories)) {
            $regular_categories[$order] = $cat;
        }
        //echo '<br /><a href="'. get_term_link($cat->slug, 'product_cat') .'">'. $cat->name .'</a>';
    }
    return array_filter($regular_categories);
}



/*Returns the post type of the product's father*/
function get_product_type($product_id)
{
    $father_id = get_field('father_post_id', $product_id);
    $post_type = get_post_type($father_id);
    return $post_type;
};




function get_cart_product_image_url($_product, $size = 'woocommerce_thumbnail')
{
    $image = '';
    if (has_post_thumbnail($_product->get_id())) {
        //echo "has post thumbnail<br>";
        $image = get_the_post_thumbnail_url($_product->get_id(), $size);
    } elseif (($parent_id = wp_get_post_parent_id($_product->get_id())) && has_post_thumbnail($parent_id)) { // @phpcs:ignore Squiz.PHP.DisallowMultipleAssignments.Found
        $image = get_the_post_thumbnail_url($parent_id, $size);
        //echo "has post thumbnail2<br>";
    } else {
        //Para cuando el producto es una variación
        @$father_id = get_field('father_post_id', $_product->get_parent_id());
        @$image = get_the_post_thumbnail_url($father_id, $size);
        //echo "has post thumbnail4<br>";
    }
    if (empty($image)) {
        //Get the father post image
        @$father_id = get_field('father_post_id', $_product->get_id());
        @$image = get_the_post_thumbnail_url($father_id, $size);
    }
    return $image;
}

function get_primary_category_string($post_id)
{
    switch (true):
        case is_combo($post_id):
            return "Curso + tratado";
            break;
        case is_producto($post_id):
            return "Bibliografía";
            break;
        case is_course($post_id):
            return "Curso Online";
            break;
        default:
            return "Desconocido";
    endswitch;
}

function is_course($father_post_id)
{
    $post_type = get_post_type($father_post_id);
    return ($post_type == 'course') ? true : false;
}

function is_producto($father_post_id)
{
    $post_type = get_post_type($father_post_id);
    return ($post_type == 'bibliography') ? true : false;
}

function is_combo($father_post_id)
{
    $post_type = get_post_type($father_post_id);
    return ($post_type == 'combo') ? true : false;
}

function is_downloadable($father_post_id)
{
    $post_type = get_post_type($father_post_id);
    return ($post_type == 'downloadable') ? true : false;
}

function has_certification($product_id, $type)
{
    $product = wc_get_product($product_id);
    if (!$product->is_type('variable')) {
        return false;
    }
    $available_variations = $product->get_available_variations();
    $has_cert = false;
    if ($available_variations) {
        foreach ($available_variations as $key => $variation) {
            $attributes = $variation['attributes'];
            $nac_cert = isset($attributes['attribute_pa_certificacion-local']) ? $attributes['attribute_pa_certificacion-local'] : false;
            $int_cert = isset($attributes['attribute_pa_certificacion-internacional']) ? $attributes['attribute_pa_certificacion-internacional'] : false;
            if ($type == 'local') {
                if ($nac_cert) {
                    if (substr($nac_cert, 0, strlen('sin-colegio')) !== 'sin-colegio') {
                        $has_cert = true;
                    }
                }
            }
            if ($type == 'int') {
                if ($int_cert) {
                    if (substr($int_cert, 0, strlen('sin-universidad')) !== 'sin-universidad') {
                        $has_cert = true;
                    }
                }
            }
        }
    }
    return $has_cert;
}



?>	