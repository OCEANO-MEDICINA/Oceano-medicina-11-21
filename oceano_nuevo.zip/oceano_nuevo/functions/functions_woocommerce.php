<?php 

function remove_coupon_for_non_valid_countries()
{
    global $woocommerce;
    $coupons_products = get_field('free_products_coupons', 'options');

    foreach (WC()->cart->get_coupons() as $code => $coupon) {  //Get all the coupons the client tries to apply
        $found = false;
        foreach ($coupons_products as $coupon_product) { //Iterate through allowed coupons
            foreach ($coupon_product['coupon'] as $key => $coupon_object) {
                //echo $coupon_object->post_title;
                if (strtolower($coupon_object->post_title) == strtolower($code)) {    //The coupon the client wants to apply is in the list of allowed coupons
                    $found = true;
                }
            }
        }
        if (!$found) { //We couldn't find the coupon they tried to apply in the list of coupons on the options page.
            WC()->cart->remove_coupon($code);
            wc_clear_notices();
            wc_add_notice('Este cupón no es válido para su país', 'error');
        }
    }
}
add_action('template_redirect', 'remove_coupon_for_non_valid_countries', 10, 3);


function woocommerce_maybe_add_multiple_products_to_cart()
{
    // Make sure WC is installed, and add-to-cart query arg exists, and contains at least one comma.
    if (!class_exists('WC_Form_Handler') || empty($_REQUEST['add-to-cart']) || false === strpos($_REQUEST['add-to-cart'], ',')) {
        return;
    }

    // Remove WooCommerce's hook, as it's useless (doesn't handle multiple products).
    remove_action('wp_loaded', array('WC_Form_Handler', 'add_to_cart_action'), 20);

    $product_ids = explode(',', $_REQUEST['add-to-cart']);
    $count       = count($product_ids);
    $number      = 0;

    foreach ($product_ids as $product_id) {
        if (++$number === $count) {
            // Ok, final item, let's send it back to woocommerce's add_to_cart_action method for handling.
            $_REQUEST['add-to-cart'] = $product_id;

            return WC_Form_Handler::add_to_cart_action();
        }

        $product_id        = apply_filters('woocommerce_add_to_cart_product_id', absint($product_id));
        $was_added_to_cart = false;
        $adding_to_cart    = wc_get_product($product_id);

        if (!$adding_to_cart) {
            continue;
        }

        $add_to_cart_handler = apply_filters('woocommerce_add_to_cart_handler', $adding_to_cart->get_type(), $adding_to_cart);

        /*
		 * Sorry.. if you want non-simple products, you're on your own.
		 *
		 * Related: WooCommerce has set the following methods as private:
		 * WC_Form_Handler::add_to_cart_handler_variable(),
		 * WC_Form_Handler::add_to_cart_handler_grouped(),
		 * WC_Form_Handler::add_to_cart_handler_simple()
		 *
		 * Why you gotta be like that WooCommerce?
		 */
        if ('simple' !== $add_to_cart_handler) {
            continue;
        }

        // For now, quantity applies to all products.. This could be changed easily enough, but I didn't need this feature.
        $quantity          = empty($_REQUEST['quantity']) ? 1 : wc_stock_amount($_REQUEST['quantity']);
        $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);

        if ($passed_validation && false !== WC()->cart->add_to_cart($product_id, $quantity)) {
            wc_add_to_cart_message(array($product_id => $quantity), true);
        }
    }
}


function ajax_vaciar_carrito()
{
	$reduce_stock = $_POST['reduce_stock'];
	$_SESSION['plan_de_estudio'];
	if ($reduce_stock) {
		reduce_stock();
	}
	empty_cart();
	echo 1;
	wp_die();
}

function reduce_stock()
{
	global $woocommerce;
	$items = $woocommerce->cart->get_cart();

	foreach ($items as $item => $values) {
		$product_id = $values['data']->get_id();
		$product =  wc_get_product($product_id);
		$item_quantity = $values['quantity'];
		$product_stock = $product->get_stock_quantity();

		if ($product_stock) {
			update_post_meta($product_id, '_stock', $product_stock - $item_quantity);
		}
	}
}

//vacía el carrito
function empty_cart()
{
	$_SESSION['plan_de_estudio'] = '';
	$user_id = apply_filters('determine_current_user', false);
	wp_set_current_user($user_id);
	$user = get_userdata($user_id);
	WC()->cart->empty_cart();
}


/**
 * Add Cart icon and count to header if WC is active
 */
function display_woocommerce_cart($refresh_cart = true)
{
    if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {

        if ($refresh_cart) {

            //    wc()->frontend_includes();
            // 	WC()->frontend_includes();

            // 	WC()->session = new WC_Session_Handler();
            // 	WC()->session->init();
            // 	WC()->customer = new WC_Customer( get_current_user_id(), true );
            // 	WC()->cart = new WC_Cart();
        }

        $count = WC()->cart->cart_contents_count;
        if ($count) { ?>
            <button id="cart" class="cart-desktop" onclick="window.location.href='/carrito'"  title="Carrito" role="button">
                <span src="<?= get_template_directory_uri().'/assets/media/icon/cart.svg'; ?>"  alt="Icono de carrito" class="mdi mdi-cart-outline"><span class='badge-cart'><?=$count ?></span></span>
            </button>
        <?php
        } else {
        ?>
        <button id="cart" class="cart-desktop" onclick="window.location.href='/carrito'"  title="Carrito" role="button">
            <span src="<?= get_template_directory_uri().'/assets/media/icon/cart.svg'; ?>"  alt="Icono de carrito" class="mdi mdi-cart-outline"></span>
        </button>
    <?php
        }
    }
}

add_action('template_redirect', 'remove_coupon_for_non_valid_countries', 10, 3);

//AJAX que va hacia cakephp para la transacción, este intermediario
//sirve para obtener valores del carrito de forma segura, alejado del usuario
add_action('wp_ajax_nopriv_hookcarrito','ajax_carrito');
add_action('wp_ajax_hookcarrito','ajax_carrito');


function ajax_carrito($data = null){
    //recopilar data carrito

    $items = WC()->cart->get_cart();
    $product_names = array();

    $index = 0;
    $agreement = 'OCEANO MEDICINA'; //el acuerdo, no importa si tiene varios cursos, tomamos uno, sea cual sea...
    //es de cert nacional nomás!

    if (isset($_POST['allForms']['meses'])) {
        if (isset($_POST['allForms']['meses']['meses_cre'])) {
            $installments = intval($_POST['allForms']['meses']['meses_cre']);
        }
    }

    $total_local_currency = 0;
    $total_usd = 0;
    foreach($items as $item => $values)
	{

        $isVariation = false;
        $hasCerts = false;

        //id del producto comprado, si es licencia será la variación id
        $item_id = $values['product_id'];

        // Retrieve WC_Product object from the product-id:
        if($values['variation_id'] != 0){
            $_woo_product = wc_get_product( $values['variation_id'] );
            $item_id = $values['variation_id'];
            $isVariation = true;
        }
        else
            $_woo_product = wc_get_product( $values['product_id'] );

        $name = $_woo_product->get_name();
        $certs = '';

        //al ser variacion (curso) puede llegar a tener cerst... o no
        //el tema es asi: todos los cursos son variaciones -> la primera variación es sin curso y sin colegio (sin certs!)
        if($isVariation){
            //obtener el nombre del padre
            $father = wc_get_product($_woo_product->get_parent_id());
            $father_name = $father->get_name();
            $name = $father_name;
        }

        // Get SKU from the WC_Product object:
        $parent_post_id = get_field('father_post_id', $values['product_id']); //obtiene el id del post padre (ahí están los sku)

        if($hasCerts)
            $sku = get_field('codigo_unico_cert', $parent_post_id);
        else
            $sku = get_field('codigo_unico', $parent_post_id);

        $product_names[$index]['sku'] = $sku;
        $product_names[$index]['quantity'] = $values['quantity'];
        $product_names[$index]['name'] = $name;
        $product_names[$index]['course'] = 'no';
        $product_names[$index]['hasCerts'] = $hasCerts;
        $product_names[$index]['certs'] = $certs;
        $product_names[$index]['discount'] = 0;
        $product_names[$index]['item_id'] = $item_id;

        //es curso?
        $prod_type = get_product_type($values['product_id']);

        //precio y tipo curso
        if($prod_type == 'course'){
            $product_names[$index]['course'] = 'yes';
        }
        $price_usd = get_usd_price($values['product_id']);
		
		//tipo
		$product_names[$index]['type'] = $prod_type;

        $aux_price = $values['line_subtotal'];
        if ($installments){
            //Remove decimals from the single installment price
            $aux_price = intval($aux_price / $installments);
            $aux_price = $aux_price * $installments;
        }

        $product_names[$index]['price'] = $aux_price;

        $total_local_currency += $aux_price;
        $product_names[$index]['price_usd'] = $price_usd;
        $total_usd += $price_usd;
        $index++;
    }

    //anexa a los productos, los cupones que correspondan (o sea descuentos)
    $product_names = util_append_discounts($product_names);

    $cartInfo = array();

    $cartInfo['products'] = $product_names;
    $cartInfo['total'] = $total_local_currency;
    $cartInfo['total_usd'] = $total_usd;
    $cartInfo['subtotal'] = WC()->cart->get_subtotal();
    $cartInfo['coupons'] = consider_coupons();
    $cartInfo['agreement'] = $agreement;
    $allData = array();

    $allData['cart'] = $cartInfo;
    $allData['forms'] = $_POST['allForms'];

    $suscripcion_url = return_domain();
    $procesadorPagos = $allData['forms']['formadepago']['procesadorpago'];

    if ($allData['forms']['formadepago']['procesadorpago'] == 'stripe'){
        $allData['forms']['ult']['stripe_plan_id'] = get_stripe_plan_id($allData['forms']['ult']['pais']);
    }


    //NUEVA FUNCION PLAN DE ESTUDIO

    if($_SESSION['plan_de_estudio']!='')
	{
        $allData['forms']['membresia']='Plan '.$_SESSION['plan_de_estudio'];
        $allData['forms']['datosformadepago']['installments']=$_SESSION['plan_de_estudio'];
        $allData['forms']['meses']['meses_cre']=$_SESSION['plan_de_estudio'];
        $allData['forms']['first']['estilodepago']='suscripcion';
		$allData['cart']['membresia'] = 'set';
        $plan = null;


        

        switch ($_SESSION['plan_de_estudio']){
            case '12':
                $plan = get_postType('plan-tienda', 1);
                $plan = get_field('plan_12', $plan->ID)[0];
                break;
            case '18':
                 $plan = get_postType('plan-tienda', 1);
                 $plan = get_field('plan_18', $plan->ID)[0];
                break;
            case '24':
                $plan = get_postType('plan-tienda', 1);
                $plan = get_field('plan_24', $plan->ID)[0];
            break;
        }
        
        $allData['cart']['total'] = array_reduce($plan['precios'], 'filterPais');
        $allData['cart']['subtotal'] = array_reduce($plan['precios'], 'filterPais'); //total sin descuento
		$allData['cart']['total_membresia'] = array_reduce($plan['precios'], 'filterPais');
		$allData['cart']['cuota_membresia'] = array_reduce($plan['precios'], 'filterPaisSimple');
        $allData['forms']['datosformadepago']['amount'] = array_reduce($plan['precios'], 'filterPais');

        foreach ($allData['cart']['products'] as $key => $producto) {
           $allData['cart']['products'][$key]['price']=$allData['cart']['total'] / sizeof($allData['cart']['products']);
        }

        $coupons = WC()->cart->get_coupons();
        $totalventa = $allData['cart']['total'];

		
		//SOLO CONSIDERA 1 CUPON
		// *
		// *
		// *
		// *
		// *
        foreach ($coupons as $key => $coupon) {
            $discount_type = $coupon->get_discount_type(); // Get coupon discount type
            $coupon_amount = $coupon->get_amount();

            if ($discount_type == 'percent') 
			{
                $allData['cart']['total'] = $totalventa - (($totalventa * $coupon_amount) / 100);
				$allData['cart']['total_membresia'] = $totalventa - (($totalventa * $coupon_amount) / 100);
				$allData['cart']['cuota_membresia'] = $allData['cart']['cuota_membresia'] - (($allData['cart']['cuota_membresia'] * $coupon_amount) / 100);
            }
        }

    }

    //Transaction result
    // echo '<pre>';
    // print_r($allData);
    // echo '</pre>';

    // exit();
    $response = process_transaction_for_crm($allData);
    // $response['data'] =$allData;
    //var_dump($response);

    if($response)
        echo($response);
    else
        echo('error');
	
    wp_die();
}

function get_max_available_installments($cart)
{
    //Always show max amount of installments on the mini cart
    $available_installments = get_available_installments($cart);
    return end($available_installments);
}

function get_available_installments($cart = NULL)
{
    if (isset($cart)) {
        if (only_bibliographies_in_cart($cart)) {
            return [1, 3, 6];
        }
    }
    switch (get_country_code_from_subdomain()) {
        case 'cl': {
                return [1, 3, 6, 8];
            } //Chile
        case 'co': {
                return [1, 3, 5, 7];
            } //Colombia
        case 'cl.devs': {
                return [1, 3, 6, 8];
            } //Chile
        case 'co.devs': {
                return [1, 3, 5, 7];
            } //Colombia
        default: {
                return [1, 3, 6, 9, 12];
            } //All the others
    }
}

//toma todos los elementos del carrito y los pasa a array, 
//lo mas importante es que toma los cursos y separa sus licencias
function util_pack_cart_separated()
{
	$answer = array();
	$items = WC()->cart->get_cart();
	$total_usd = 0;

	foreach ($items as $item => $values) 
	{
		$newProduct = array();
		$isVariation = false;

		// Retrieve WC_Product object from the product-id:
		if ($values['variation_id'] != 0) {
			$_woo_product = wc_get_product($values['variation_id']);
			$isVariation = true;
		} else {
			$_woo_product = wc_get_product($values['product_id']);
		}

		//nombre en limpio
		$newProduct['name'] = util_get_basic_name($_woo_product, $isVariation);

		//tipo
		$prod_type = get_product_type($values['product_id']);
		$newProduct['type'] = $prod_type;

		$price = $values['line_subtotal'];
		$price_usd = get_usd_price($values['product_id']);

		$newProduct['price'] = $price;
		$newProduct['price_usd'] = $price_usd;

		$total_usd += $price_usd;

		//cantidad	
		$newProduct['quantity'] = $values['quantity'];

		$answer['products'][] = $newProduct;
	}
	
	$answer['total'] = WC()->cart->total;
	$answer['total_usd'] = $total_usd;

	return ($answer);
}

//te da el nombre básico, especialmente útil para los cursos cuando llevan certificaciones
function util_get_basic_name($product, $isVariation)
{
	$answer = '';

	//es variación
	if ($isVariation) {
		//dado que es variación, busca al padre
		$father = wc_get_product($product->get_parent_id());
		$answer = $father->get_name();
	} else {
		$answer = $product->get_name();
	}

	return ($answer);
}

function only_bibliographies_in_cart($cart)
{
    // Loop through all products in the Cart
    foreach ($cart as $cart_item_key => $cart_item) {
        $father_post_id = get_field('father_post_id', $cart_item['product_id']);
        if (!is_producto($father_post_id)) {
            return false;
        }
    }
    return true;
}


function process_transaction_for_crm($data){
    $suscripcion_url = return_domain();
    //enviar a cake
    $handler = curl_init();
    curl_setopt($handler, CURLOPT_URL, 'https://oceanomedicina.com.ar/'.$suscripcion_url.'/middle/EvaluateForm');
    curl_setopt($handler, CURLOPT_POST,true);
    curl_setopt($handler, CURLOPT_RETURNTRANSFER,true);
    curl_setopt($handler, CURLOPT_POSTFIELDS,json_encode($data));
    //var_dump(json_encode($data));

    $headers = array();
    $headers[] = "Content-Type: application/json";
    curl_setopt($handler, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec ($handler);
    curl_close($handler);
	
	
    //checkear respuesta
    save_order_log($data, $response);

    $decoded = json_decode($response,true);
    if(is_array($decoded))
        if(isset($decoded['contact']))
            return $response;
    return false;
}

function save_order_log($request, $response){
    global $wpdb;

    $table_name = $wpdb->prefix . "order_logs";
    $wpdb->insert( $table_name, array(
        'request' => serialize($request),
        'response' => serialize($response)
    ) );
}

add_action('admin_post_nopriv_cargar_plan_de_estudio', 'cargar_plan_de_estudio');
add_action('admin_post_cargar_plan_de_estudio', 'cargar_plan_de_estudio');
add_action('wp_ajax_nopriv_cargar_plan_de_estudio', 'cargar_plan_de_estudio');
add_action('wp_ajax_cargar_plan_de_estudio', 'cargar_plan_de_estudio');

include_once WP_PLUGIN_DIR . '/woocommerce/woocommerce.php';

function cargar_plan_de_estudio()
{

	global $woocommerce;

	WC()->frontend_includes();
	WC()->session = new WC_Session_Handler();
	WC()->session->init();
	WC()->customer = new WC_Customer(get_current_user_id(), true);
	WC()->cart = new WC_Cart();

	$woocommerce->cart->empty_cart();

	$_SESSION['plan_de_estudio'] = $_POST['plan']['plan'];

	//EL PRINCPAL
	WC()->cart->add_to_cart($_POST["plan"]['principal']['id'], 1);
	foreach ($_POST["plan"]['secundarios'] as $key => $id) {
		WC()->cart->add_to_cart($id, 1);
	}
	// $woocommerce
	//tiene que devolver fecha maxima y fecha minima del combo.

	//un mes antes de que termine la prorroga.
	echo json_encode(array("estado" => true));
}

function check_duplicados_cart($eliminarlos = 0)
{

	$elimino = false;
	$cart = WC()->instance()->cart;
	global $woocommerce;
	foreach ($woocommerce->cart->get_cart() as $key => $val) {
		$_product = $val['data'];
		if ($val['quantity'] > 1) {
			if ($eliminarlos) {
				$elimino = 1;
				$cart->set_quantity($key, 1);
			} else {
				return 1;
			}
		}
	}

	if ($elimino)
		return 1;

	return 0;
}

function getTotalPrice()
{
    $totalventa = get_cart_total_installments(1);
    return $totalventa;
}



function get_posts_to_hide()
{
    $coupons_products = get_field('free_products_coupons', 'options');
    $products_to_hide = [];
    foreach ($coupons_products as $coupon_product) {
        foreach ($coupon_product['producto'] as $product) {
            $products_to_hide[] = $product->ID;
        }
    }
    return $products_to_hide;
}
add_action('admin_post_nopriv_eliminar_duplicados', 'eliminar_duplicados');
add_action('admin_post_eliminar_duplicados', 'eliminar_duplicados');
add_action('wp_ajax_nopriv_eliminar_duplicados', 'eliminar_duplicados');
add_action('wp_ajax_eliminar_duplicados', 'eliminar_duplicados');



function eliminar_duplicados()
{
	echo json_encode(array("estado" => check_duplicados_cart(1)));
}

add_action('wp_ajax_nopriv_eliminarcupones', 'sacar_cargar_productos');
add_action('wp_ajax_eliminarcupones', 'sacar_cargar_productos');
function sacar_cargar_productos(){
    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item):
        $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
        $array_productos[] = $product_id;
    endforeach;
    $reduce_stock = $_POST['reduce_stock'];
	if ($reduce_stock) {
		reduce_stock();
	}
	empty_cart();
    WC()->cart->remove_coupons();
    wc_clear_notices();
	foreach ($array_productos as $key => $id) {
		WC()->cart->add_to_cart($id, 1);
	}
    echo 1;
    die();
}


add_action('template_redirect', 'remove_coupon_for_non_valid_countries', 10, 3);

add_action('woocommerce_applied_coupon', 'apply_free_product_on_coupon');
function apply_free_product_on_coupon()
{
	global $woocommerce;
	$coupons_products = get_field('free_products_coupons', 'options');
	foreach ($coupons_products as $coupon_product) {
		foreach ($coupon_product['coupon'] as $key => $coupon) {
			if (in_array(strtolower($coupon->post_title), $woocommerce->cart->get_applied_coupons())) {
				$woocommerce->cart->add_to_cart($coupon_product['producto'][$key]->ID, 1);
				foreach ($coupon_product['producto'] as $prod) {
					$woocommerce->cart->add_to_cart($prod->ID, 1);
				}
			}
		}
	}
}





?>