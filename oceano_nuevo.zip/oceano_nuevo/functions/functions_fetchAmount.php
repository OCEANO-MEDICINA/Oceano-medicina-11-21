<?php

//hace un echo que dice si...
//hay UN curso entre los productos
//hay entre los productos ALGO que no sea un curso (producto físico) (bibliografia)	
function echoOptions()
{
	$answer = '';
	$oneCourse = false;
	$onePhysicalProduct = false;
	
	$items = WC()->cart->get_cart();
	$product_names = array();

	$index = 0;
	
	foreach($items as $item => $values) 
	{ 
	
		$isCourse = false;
		
		// Retrieve WC_Product object from the product-id:
		$_woo_product = wc_get_product( $values['product_id'] );
		
		$prod_type = get_product_type($values['product_id']);
		
		if($prod_type == 'course')
			$isCourse = true;
		
				
		if($isCourse)
			$oneCourse = true;
		else
			$onePhysicalProduct = true;
		
		$index++;
	}
	
	if($oneCourse)
		$answer.='<div id="id_data_1" data-course="1" ';
	else
		$answer.='<div id="id_data_1" data-course="0" ';
	
	if($onePhysicalProduct)
		$answer.='data-physical="1" ></div>';
	else
		$answer.='data-physical="0" ></div>';
	
	return($answer);
}
		


//lista los productos del carrito en LA PARTE AZUL		
function displayProductsCart2()
{
	$answer = '';
	
	$items = util_pack_cart_separated();

	foreach($items['products'] as $i){
		if($i['quantity'] > 1)
			// $answer.= '<h5 class="title col-8">'.$i['name'].' x' . $i['quantity'] . '</h5>';
			$answer.= '<h5 class="title col-8">'. $i['quantity'].' '.$i['name']. '</h5>';
		else
			$answer.= '<h5 class="title col-8">'.$i['name'].'</h5>';
		
		$answer.= '<h5 class="price col-4 label_small_price" data-amount="'.$i['price'].'" data-symbol="'.get_currency_symbol().'">'.get_currency_symbol().'</h5>';
		$answer.='<br>';
	}
	
	return($answer);
}

//lista los items del carrito en la parte BLANCA IZQUIERDA DE CONFIRMAR COMPRA!
function listItems(){
	$items = WC()->cart->get_cart();
	$product_names = array();

	$index = 0;
	
	$answer = '';
	
	foreach($items as $item => $values) 
	{ 

		// Retrieve WC_Product object from the product-id:
		$_woo_product = wc_get_product( $values['product_id'] );
		
		
		$isVariation = false;
	
		// Retrieve WC_Product object from the product-id:
		if($values['variation_id'] != 0)
		{
			$_woo_product = wc_get_product( $values['variation_id'] );
			$isVariation = true;
		}
		else
		{
			$_woo_product = wc_get_product( $values['product_id'] );
		}
	
		$parent_post_id = get_field('father_post_id', $values['product_id']);

		$name = util_get_full_product_name($_woo_product,$isVariation);
				
		$answer.='
		<div class="cartcontent row align-items-center">
			<div class="cartimage col-5 col-md-4 col-lg-3">
				<img src="'.get_cart_product_image_url($_woo_product).'">
			</div>
			
			<div class="cartproduct col-7 col-md-8 col-lg-5">
				<h4 class="productclass">'.get_primary_category_string($parent_post_id).'</h4>
				<h3 class="producttitle">'.$name.'</h3>
			</div>
		</div>
		';
			
			
		
		$index++;
	}
	
	return($answer);
	
}


/*
	$items = WC()->cart->get_cart();
	$product_names = array();

	$index = 0;
	
	foreach($items as $item => $values) 
	{ 
	
		
		// Retrieve WC_Product object from the product-id:
		if($values['variation_id'])
			$_woo_product = wc_get_product( $values['variation_id'] );
		else
			$_woo_product = wc_get_product( $values['product_id'] );
		
		$parent_post_id = get_field('father_post_id', $values['product_id']);
		
		echo get_field('codigo_unico', $parent_post_id);
		echo '<br>';
		echo get_field('codigo_unico_cert', $parent_post_id);
		echo 'elu';
	
		$index++;
	}
	
	die();
*/

//en el panel derecho, muestra los cupones usados
function displayCouponsCart()
{
	$answer = '';
	
	$coupons = WC()->cart->get_coupons();

	foreach($coupons as $c) 
	{ 
		$answer.= '<h5 class="title col-8">Cupón "'.$c->get_code().'"</h5>';
		
		$answer.= '<h5 class="price col-4">(-'.$c->get_amount().'%)</h5>';
		
		$answer.='<br>';

	}
	
	return($answer);
}

//pega el lenguaje para que js y eventualmente php lo tome
function echoLang(){
	$answer = 'nope'; //el default, porque algunos paises no los tengo ahora

	switch(ICL_LANGUAGE_CODE){
		case 'bo': {$answer = 'bo'; break;}
		case 'cl': {$answer = 'ch'; break;}
		case 'gt': {$answer = 'gt'; break;}
		case 'hn': {$answer = 'hn'; break;}
		case 'uy': {$answer = 'ur'; break;}
		case 'pe': {$answer = 'pe'; break;}
		case 'arg': {$answer = 'ar'; break;}
		case 'mx': {$answer = 'mx'; break;}
		case 'co': {$answer = 'co'; break;}	
				
		case 'cr': {$answer = 'cr'; break;}	//costa rica
		case 'ec': {$answer = 'ec'; break;}	//ecuador
		case 'sal': {$answer = 'sal'; break;} //el salvador
		case 'es': {$answer = 'es'; break;}	//españa
		case 'ni': {$answer = 'ni'; break;}	//nicaragua
		case 'pnm': {$answer = 'pnm'; break;} //panama
		case 'py': {$answer = 'py'; break;}	//paraguay
	}

	return ($answer);
	//return ('ch');
}

//pega el procesador para JS
function echoProcessor(){
	$answer = 'mercadopago';
	switch(ICL_LANGUAGE_CODE){
		case 'cl':
		case 'uy':
		case 'pe':
		case 'arg':
		case 'mx':
		case 'co': {$answer = 'mercadopago'; break;}	
				
		case 'cr': 	//costa rica
		case 'ec': 	//ecuador
		case 'sal':  //el salvador
		case 'es': 	//españa
		case 'ni': 	//nicaragua
		case 'pnm':  //panama
		case 'py': {$answer = 'paypal'; break;}	//paraguay
	}

	return ($answer);
}

//devuelve key de MP para usar, ya sea sandbox, productivo.... y de pais!
function paste_mp_key()
{
	$answer = '';
	
	$country = echoLang();
	$domain = return_domain();
	
	if($domain == 'suscripcion')
	{
		switch($country)
		{
			case 'ur': { $answer = 'APP_USR-da97cee7-3b62-464a-b1bb-40996aae2863'; break; }
			case 'ar': { $answer = 'APP_USR-bdc9f1b1-12e3-4610-9e88-4c4220bab65e'; break; }
			case 'ch': { $answer = 'APP_USR-4e2ad08f-79d3-4f9b-9138-6f56a218bc43'; break; }
			case 'co': { $answer = 'APP_USR-7130877a-1ef6-404a-950e-74bd0765caef'; break; }
			case 'mx': { $answer = 'APP_USR-6ab49f25-f9c6-4c65-a51a-8e48c98ce69f'; break; }
			case 'pe': { $answer = 'APP_USR-6aa7d401-2927-4753-b2d8-a54cab765c1a'; break; }
		}
	}
	else if($domain == 'suscripciontest')
	{
		//comment
		switch($country)
		{
			case 'ur': { $answer = 'TEST-eea343c8-1bd0-4288-822b-668debb9bee9'; break; }
			case 'ar': { $answer = 'TEST-1a0c4566-07f0-474a-a0b4-3ead7a1d0940'; break; }
			case 'ch': { $answer = 'TEST-1b085c1a-0241-4125-ad27-59cf47bdc04d'; break; }
			case 'co': { $answer = 'TEST-4d6c97e3-5341-4736-8c62-5d407407b1e3'; break; }
			case 'mx': { $answer = 'TEST-bfeceae0-2ebd-4f15-b116-8cc58605d8e0'; break; }
			case 'pe': { $answer = 'TEST-f6112a66-206d-4dd8-ad12-8e78755784d1'; break; }
		}
	}

	return($answer);
}

?>