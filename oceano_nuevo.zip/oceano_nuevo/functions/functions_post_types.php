<?php 
/* Aca se crean los diferentes post_types */
function create_post_type()
{
    $labels = array(
        'name' => __('Cursos'),
        'singular_name' => __('Curso'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Course'),
        'edit_item' => __('Edit Course'),
        'new_item' => __('New Course'),
        'view_item' => __('View Course'),
        'search_items' => __('Search Course'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => null,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments', 'taxonomies', 'revisions'),
        'taxonomies' => array('product_cat'),
    );
    register_post_type('course', $args);

    $labels = array(
        'name' => __('Bibliografías'),
        'singular_name' => __('Bibliografía'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Bibliography'),
        'edit_item' => __('Edit Bibliography'),
        'new_item' => __('New Bibliography'),
        'view_item' => __('View Bibliography'),
        'search_items' => __('Search Bibliography'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => null,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments', 'taxonomies', 'revisions'),
        'taxonomies' => array('product_cat'),
    );
    register_post_type('bibliography', $args);

    $labels = array(
        'name' => __('Combos'),
        'singular_name' => __('Combo'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Combo'),
        'edit_item' => __('Edit Combo'),
        'new_item' => __('New Combo'),
        'view_item' => __('View Combo'),
        'search_items' => __('Search Combo'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => null,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments', 'taxonomies', 'revisions'),
        'taxonomies' => array('product_cat')
    );
    register_post_type('combo', $args);

    $labels = array(
        'name' => __('Descargables'),
        'singular_name' => __('Descargable'),
        'add_new' => __('Agregar Nuevo'),
        'add_new_item' => __('Agregar Nuevo Descargable'),
        'edit_item' => __('Edit Descargable'),
        'new_item' => __('New Descargable'),
        'view_item' => __('View Descargable'),
        'search_items' => __('Search Descargable'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => null,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments', 'taxonomies', 'revisions'),
        'taxonomies' => array('product_cat'),
    );
    register_post_type('downloadable', $args);

    $labels = array(
        'name' => __('Autores'),
        'singular_name' => __('Autor'),
        'add_new' => __('Agregar Nuevo'),
        'add_new_item' => __('Agregar Nuevo Autor'),
        'edit_item' => __('Edit Autor'),
        'new_item' => __('New Autor'),
        'view_item' => __('View Autor'),
        'search_items' => __('Search Autor'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => null,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'revisions'),
        'taxonomies' => array('product_cat'),
    );
    register_post_type('author', $args);

    $labels = array(
        'name' => __('Avales'),
        'singular_name' => __('Aval'),
        'add_new' => __('Agregar Nuevo'),
        'add_new_item' => __('Agregar Nuevo Aval'),
        'edit_item' => __('Editar Aval'),
        'new_item' => __('Nuevo Aval'),
        'view_item' => __('Ver Aval'),
        'search_items' => __('Buscar Aval'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => null,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'revisions'),
        'taxonomies' => array('product_cat'),
    );
    register_post_type('aval', $args);

    $labels = array(
        'name' => __('Metodologías'),
        'singular_name' => __('Metodología'),
        'add_new' => __('Agregar Nueva'),
        'add_new_item' => __('Agregar Nueva Metodología'),
        'edit_item' => __('Editar Metodología'),
        'new_item' => __('Nueva Metodología'),
        'view_item' => __('Ver Metodología'),
        'search_items' => __('Buscar Metodología'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => null,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'revisions'),
        'taxonomies' => array(),
    );
    register_post_type('methodology', $args);

    $labels = array(
        'name' => __('Profesiones'),
        'singular_name' => __('Profesión'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Profesión'),
        'edit_item' => __('Edit Profesión'),
        'new_item' => __('New Profesión'),
        'view_item' => __('View Profesión'),
        'search_items' => __('Search Profesión'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('profession', $args);
    // nuevo custom post para el slider del home (hero)
    $labels = array(
        'name' => __('Slider home'),
        'singular_name' => __('Slider home'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New slider-home'),
        'edit_item' => __('Edit slider-home'),
        'new_item' => __('New slider-home'),
        'view_item' => __('View slider-home'),
        'search_items' => __('Search slider-home'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-slides',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('slider-home', $args);

    $labels = array(
        'name' => __('Slider tienda'),
        'singular_name' => __('slider tienda'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New slider tienda'),
        'edit_item' => __('Edit slider tienda'),
        'new_item' => __('New slider tienda'),
        'view_item' => __('View slider tienda'),
        'search_items' => __('Search slider tienda'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-slides',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('slider-tienda', $args);

    $labels = array(
        'name' => __('Slider Planes'),
        'singular_name' => __('Slider plan'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Planes'),
        'edit_item' => __('Edit Planes'),
        'new_item' => __('New Plan'),
        'view_item' => __('View Planes'),
        'search_items' => __('Search Planes'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('slider-plan', $args);

    // nuevo custom post para los destacados
    $labels = array(
        'name' => __('Destacados home'),
        'singular_name' => __('Destacados home'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Destacados-home'),
        'edit_item' => __('Edit Destacados-home'),
        'new_item' => __('New Destacados-home'),
        'view_item' => __('View Destacados-home'),
        'search_items' => __('Search Destacados-home'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('destacados-home', $args);

    $labels = array(
        'name' => __('Banner home'),
        'singular_name' => __('Banner home'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Banner-home'),
        'edit_item' => __('Edit Banner-home'),
        'new_item' => __('New Banner-home'),
        'view_item' => __('View Banner-home'),
        'search_items' => __('Search Banner-home'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('banner-home', $args);

    $labels = array(
        'name' => __('Banner promocional tienda'),
        'singular_name' => __('banner promocional tienda'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New banner promocional tienda'),
        'edit_item' => __('Edit banner promocional tienda'),
        'new_item' => __('New banner promocional tienda'),
        'view_item' => __('View banner promocional tienda'),
        'search_items' => __('Search banner promocional tienda'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('promocional-tienda', $args);

    $labels = array(
        'name' => __('Testimoniales home'),
        'singular_name' => __('Testimoniales home'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Testimoniales-home'),
        'edit_item' => __('Edit Testimoniales-home'),
        'new_item' => __('New Testimoniales-home'),
        'view_item' => __('View Testimoniales-home'),
        'search_items' => __('Search Testimoniales-home'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('testimonales-home', $args);

    $labels = array(
        'name' => __('Webinars home'),
        'singular_name' => __('webinars home'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New webinars-home'),
        'edit_item' => __('Edit webinars-home'),
        'new_item' => __('New webinars-home'),
        'view_item' => __('View webinars-home'),
        'search_items' => __('Search webinars-home'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('webinars-home', $args);

    $labels = array(
        'name' => __('Planes'),
        'singular_name' => __('Planes'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Planes'),
        'edit_item' => __('Edit Planes'),
        'new_item' => __('New Plan'),
        'view_item' => __('View Planes'),
        'search_items' => __('Search Planes'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('plan-tienda', $args);

    $labels = array(
        'name' => __('Webinar producto'),
        'singular_name' => __('Webinar producto'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Webinar producto'),
        'edit_item' => __('Edit Webinar producto'),
        'new_item' => __('New Plan'),
        'view_item' => __('View Webinar producto'),
        'search_items' => __('Search Webinar producto'),
        'not_found' =>  __('Nothing found'),
        'not_found_in_trash' => __('Nothing found in Trash'),
        'parent_item_colon' => ''
    );

    

    $args = array(
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'thumbnail', 'taxonomies', 'revisions'),
    );
    register_post_type('webinar-producto', $args);
}
add_action('init', 'create_post_type');

if (function_exists('acf_add_options_page')) {
    acf_add_options_page();

    acf_add_options_page(array(
        'page_title'    => __('Sliders'),
        'menu_title'    => __('Sliders'),
        'menu_slug'     => 'sliders',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
}



//  Aca se obtiene todos los datos por tipo de post type especificado
function get_postType($post_type, $posts_per_page)
{
    $args = array(
        'post_type' => $post_type,
        'posts_per_page' => $posts_per_page
    );
    $the_query = new WP_Query($args);
    if ($the_query->have_posts()) {
        return $the_query->posts[0];
    }
    return null;
}


function get_list_specialties(){
    $args = array(
        'post_type' => 'profession',
        'posts_per_page' => 1,
    );
    $the_query = new WP_Query($args);
        while ($the_query->have_posts()) { $the_query->the_post();
            return $list_profession_terms = get_field('specialties', $the_query->ID);
        }
}


function get_list_specialties_with_products($profession_metida){
    $args = array(
        'post_type' => 'profession',
        'posts_per_page' => 1,
    );
    $the_query = new WP_Query($args);
        while ($the_query->have_posts()) { $the_query->the_post();
            $list_profession_terms = get_field('specialties', $the_query->ID);
        }
    $args_productos = array(
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key'     => '_stock_status',
                'value'   => 'outofstock',
                'compare' => '!=',
            ),
        ),
    );

    $products = new WP_Query($args_productos);
    $array_categories = [];
    foreach($products->posts as $product) {
        $father_id = get_field('father_post_id', $product->ID);
        $product_profession_array = get_professions_list($father_id);
        $product_categories_array = strip_tags(removeAccents(strtolower(wc_get_product_category_list($product->ID, ',', '', ''))));
        $concatenar_array = false;
        foreach ($product_profession_array as $profesion) {  
                if ($profesion->name == $profession_metida ) {
                   $concatenar_array = true;
                }
        }
        if ($concatenar_array) {
            if (strpos($product_categories_array, ',')) {
                foreach(explode(',', $product_categories_array) as $key){
                    $array_categories[] = $key;  
                }
            } else {
                $array_categories[] = $product_categories_array;
            }
        }
    }

    $array_categories= array_unique($array_categories);
    $array_final= [];
    foreach ($array_categories as $category) {
        foreach ($list_profession_terms as $profession) {
           if($category == removeAccents(strtolower($profession->name))){
                $array_final[] = (object) array(
                    'slug' => $profession->slug,
                    'name' => $profession->name
                );
           }
        }
    }
     return $array_final;  
}


function getCursosPrincipales()
{

	$query_args = array(
		'post_type' => 'course',
		'post_per_page' => -1,
		'nopaging' => true,
		
	);


	$principales = new WP_Query($query_args);


	$args = array(
		'post_type' => 'product',
		'posts_per_page' => -1,
		'meta_key' => '_price',
		'meta_query' => array( 
            'relation' => 'AND', 
            array( 
                'key' => '_price', 'value' => 0, 'compare' => '>', 'type' => 'NUMERIC'), 
            array( 
                'show_post_query' => array('key' => 'posicion_planes', 'value' => 'principal'), 
           )),
	);

    

	$productos = new WP_Query($args);

	$productosv2 = array();
	$woop_temp = array();
	foreach ($productos->posts as $key => $producto) {
		$parent_id = get_field('father_post_id', $producto->ID);
		$productosv2[] = $parent_id;
		$woop_temp[] = $producto;
	}


	$disponibles = array();

	foreach ($principales->posts as $key => $p) {
		$id = array_search($p->ID, $productosv2);
		if (!($id === false)) {
			$p->wooP = $woop_temp[$id];
			$disponibles[] = $p;
		}
	}


	function mapita($el)
	{
		return $el->ID;
	}

	return $disponibles;
	// return ''.array_search('103792', $productosv2)===false;
	// return array_map('mapita',$disponibles);
}

function getCursosSecundarios()
{
	$query_args = array(
		'post_type' => 'course',
		'nopaging' => true,
		'post_per_page' => -1,
		
	);


	$principales = new WP_Query($query_args);


	$args = array(
		'post_type'      => 'product',
		'posts_per_page' => -1,
		'meta_key' => '_price',
		'meta_query' => array( 
            'relation' => 'AND', 
            array( 
                'key' => '_price', 'value' => 0, 'compare' => '>', 'type' => 'NUMERIC'), 
            array( 
                'show_post_query' => array('key' => 'posicion_planes', 'value' => 'secundario'), 
            )));

	$productos = new WP_Query($args);

	$productosv2 = array();
	$woop_temp = array();
	foreach ($productos->posts as $key => $producto) {
		$parent_id = get_field('father_post_id', $producto->ID);
		$productosv2[] = $parent_id;
		$woop_temp[] = $producto;
	}


	$disponibles = array();

	foreach ($principales->posts as $key => $p) {
		$id = array_search($p->ID, $productosv2);
		if (!($id === false)) {
			$p->wooP = $woop_temp[$id];
			$disponibles[] = $p;
		}
	}

	return $disponibles;
}

function display_banner_plan_estudio($iteradorOrder){

    $promoTienda = get_postType('promocional-tienda', 1);
    $promoTienda = get_field('banner_promocional_tienda', $promoTienda->ID)[0];
    $titloPromoTienda = $promoTienda['titulo'];
    $contenidoPromoTienda = $promoTienda['contenido'];
    $imagenPromoTienda = $promoTienda['imagen']['url'];
    $placeHolderPromoTienda = $promoTienda['placeholder'];
    $linkPromoTienda = $promoTienda['link']['url'];
    ?>

    <div style="order: <?= $iteradorOrder ?>; display: none;" data-banner="true" disabled="disabled" class="card product-card enfermeros-auxiliares card-big big-card ">
        <div class="card-big-info banner-tienda" style="background: url(<?= $imagenPromoTienda; ?>);">
            <h3 class="card-big-info-title"><?= $titloPromoTienda;  ?></h3>
            <p class="card-big-info-bajada"><?= $contenidoPromoTienda;  ?></p>
            <a class="card-info-footer-boton btn btn-mid" target="_blank" href="<?= $linkPromoTienda; ?>"><?= $placeHolderPromoTienda; ?></a>
        </div>
    </div>


<?php } 






?>