<?php 


/* Removedor de acentos para palabras */
function removeAccents($str) {
    $a = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ', 'Ά', 'ά', 'Έ', 'έ', 'Ό', 'ό', 'Ώ', 'ώ', 'Ί', 'ί', 'ϊ', 'ΐ', 'Ύ', 'ύ', 'ϋ', 'ΰ', 'Ή', 'ή');
    $b = array('A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o', 'Α', 'α', 'Ε', 'ε', 'Ο', 'ο', 'Ω', 'ω', 'Ι', 'ι', 'ι', 'ι', 'Υ', 'υ', 'υ', 'υ', 'Η', 'η');
    return str_replace($a, $b, $str);
}

function get_country_code_from_subdomain(){
    $subdomain = join('.', explode('.', $_SERVER['HTTP_HOST'], -2));
    return (!empty($subdomain)) ? $subdomain : 'int';
}

function fechaCastellano($fecha, $sinYY = true)
{
	$fecha = substr($fecha, 0, 10);
	$numeroDia = date('d', strtotime($fecha));
	$dia = date('l', strtotime($fecha));
	$mes = date('F', strtotime($fecha));
	$anio = date('Y', strtotime($fecha));
	$dias_ES = array("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");
	$dias_EN = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
	$nombredia = str_replace($dias_EN, $dias_ES, $dia);
	$meses_ES = array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
	$meses_EN = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	$nombreMes = str_replace($meses_EN, $meses_ES, $mes);

	if ($sinYY)
		return $nombredia . " " . $numeroDia . " de " . $nombreMes;

	return $nombredia . " " . $numeroDia . " de " . $nombreMes . " de " . $anio;
}

function print_state_field($name){
    ?>
    <div class="">
        <label class="form-check-label" for="<?php echo $name; ?>">Estado / Provincia*</label>
        <?php
        if (ICL_LANGUAGE_CODE != 'arg'){
            ?><input class="form-check-input input-texto" type="text" name="<?php echo $name; ?>" required data-parsley-error-message="Por favor ingrese un estado / provincia"><?php
        }else{
            ?>
            <select name="<?php echo $name; ?>" id="<?php echo 'id_'.$name; ?>" class="minimal">
                <option > Seleccionar</option>
                <option value="01 - C.A.B.A.">Capital Federal</option>
                <option value="02 - BUENOS AIRES">Buenos Aires</option>
                <option value="03 - CORDOBA">Córdoba</option>
                <option value="04 - SANTA FE">Santa Fé</option>
                <option value="05 - LA PAMPA">La Pampa</option>
                <option value="06 - MENDOZA">Mendoza</option>
                <option value="07 - ENTRE RIOS">Entre Ríos</option>
                <option value="08 - SAN JUAN">San Juan</option>
                <option value="09 - SAN LUIS">San Luis</option>
                <option value="10 - TUCUMAN">Tucumán</option>
                <option value="11 - SANTIAGO DEL ESTERO">Santiago del Estero</option>
                <option value="12 - SALTA">Salta</option>
                <option value="13 - LA RIOJA">La Rioja</option>
                <option value="14 - CATAMARCA">Catamarca</option>
                <option value="15 - JUJUY">Jujuy</option>
                <option value="16 - RIO NEGRO">Río Negro</option>
                <option value="17 - NEUQUEN">Neuquén</option>
                <option value="18 - CHUBUT">Chubut</option>
                <option value="19 - SANTA CRUZ">Santa Cruz</option>
                <option value="20 - TIERRA DEL FUEGO">Tierra del Fuego</option>
                <option value="21 - CORRIENTES">Corrientes</option>
                <option value="22 - CHACO">Chaco</option>
                <option value="23 - FORMOSA">Formosa</option>
                <option value="24 - MISIONES">Misiones</option>
            </select>
            <?php
        }
        ?>
    </div>
    <?php
}

function get_currency_code_by_wpml(){
    $currencies = [];
    $currencies ["arg"] = "ARS";
    $currencies ["cl"] = "CLP";
    $currencies ["co"] = "COP";
    $currencies ["cr"] = "USD";
    $currencies ["ec"] = "USD";
    $currencies ["sal"] = "USD";
    $currencies ["es"] = "EUR";
    $currencies ["mx"] = "MXN";
    $currencies ["ni"] = "USD";
    $currencies ["pnm"] = "USD";
    $currencies ["py"] = "USD";
    $currencies ["pe"] = "PEN";
    $currencies ["uy"] = "UYU";
    $wpml_country = get_wpml_country_code();
    return ($currencies[$wpml_country]);
}

function return_domain()
{
	return is_test_environment() ? 'suscripciontest' : 'suscripcion';
}

function is_test_environment()
{
	$url = $_SERVER['SERVER_NAME'];
	if (explode(".", $_SERVER['SERVER_NAME'])[2] == 'tech') {
		return true;
	}
	return false;
}


function get_wpml_country_code(){
    $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $uri_segments = explode('/', $uri_path);
    $urlCode = $uri_segments[1];
    $languages = icl_get_languages('skip_missing=0&orderby=KEY&order=DIR&link_empty_to=str');
    foreach ($languages as $language){
        if ($urlCode == $language['code']){return $urlCode;}
    }
    return 'arg';
}

function get_stripe_plan_id($country){
    $is_test_environment = is_test_environment();
    switch($country){
        case 'int': {$answer = 'Internacional'; break;}
        case 'bo': {$answer = 'price_1H30abBZ0DURRH2Fi49CMqre'; break;} //Bolivia
        // case 'cl': {$answer = 'price_1Gxl0JBZ0DURRH2FdpW5kUuL'; break;} //Chile
        // case 'ch': {$answer = 'price_1Gxl0JBZ0DURRH2FdpW5kUuL'; break;} //Chile
        case 'cl': {$answer = $is_test_environment ? 'plan_HHVYpZ6DNzgawx' : 'price_1Gxl0JBZ0DURRH2FdpW5kUuL'; break;} //Chile
        case 'ch': {$answer = $is_test_environment ? 'plan_HHVYpZ6DNzgawx' : 'price_1Gxl0JBZ0DURRH2FdpW5kUuL'; break;} //Chile
        case 'gt': {$answer = $is_test_environment ? 'price_1H3SA4BZ0DURRH2FguR39sjM' : 'price_1H3S0vBZ0DURRH2Fzeg4prPf'; break;} //Guatemala
        case 'hn': {$answer = $is_test_environment ? 'price_1H3SANBZ0DURRH2FnRG34HhX' : 'price_1H30gdBZ0DURRH2FU4tPMS51'; break;} //Honduras
        case 'uy': {$answer = $is_test_environment ? 'plan_HHVXws46gijnOU' : 'plan_HIlqECniUZ2kFb'; break;} //Uruguay
        case 'ur': {$answer = $is_test_environment ? 'plan_HHVXws46gijnOU' : 'plan_HIlqECniUZ2kFb'; break;} //Uruguay
        case 'pe': {$answer = 'price_HJCn7S4fnRLHwO'; break;} //Perú
        case 'ar': {$answer = 'Argentina'; break;} //Argentina
        case 'mx': {$answer = 'Mexico'; break;} //Mexico
        case 'co': {$answer = 'price_HJZJEiPbNg2FXu'; break;} // Colombia
        case 'cr': {$answer = $is_test_environment ? 'price_1IEpeYBZ0DURRH2FFAabUAMJ' : 'price_1IEpenBZ0DURRH2Fz8HdN2N0'; break;} //costa rica
        case 'ec': {$answer = 'price_HJZICHachk2Y4m'; break;}	//ecuador
        case 'sv': {$answer = 'El Salvador'; break;} //el salvador
        case 'sal': {$answer = 'El Salvador'; break;} //el salvador
        case 'es': {$answer = 'España'; break;}	//españa
        case 'ni': {$answer = $is_test_environment ? 'price_1IEq6oBZ0DURRH2FYTeuQKHM' : 'price_1IEq5uBZ0DURRH2FwbkFYbMw'; break;} 	//nicaragua
        case 'pnm': {$answer = $is_test_environment ? 'plan_HHVZXGf5PHlRVM' : 'price_HJH0jgSVSdq0vs'; break;} //Panamá
        case 'pa': {$answer = $is_test_environment ? 'plan_HHVZXGf5PHlRVM' : 'price_HJH0jgSVSdq0vs'; break;} //Panamá
        case 'py': {$answer = 'price_HJZKilKlCv4X5v'; break;} //Paraguay
    }
    return $answer;
}


?>