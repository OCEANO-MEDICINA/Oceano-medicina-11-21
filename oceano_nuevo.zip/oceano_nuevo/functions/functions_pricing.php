<?php 

function get_base_price($product_id, $installments = 12)
{
    $product = wc_get_product($product_id);
    if ($product) {
        if (0 == $product->get_price()) {
            return false;
        } else {
            $price = $product->is_type('variable') ? $product->get_variation_regular_price('min', true) : $product->get_regular_price();
            return round(floatval($price) / $installments, 2);
        }
    }
    return false;
}

function get_base_sale_price($product_id, $installments = 12)
{
    $product = wc_get_product($product_id);
    if ($product) {
        $price_regular = $product->is_type('variable') ? $product->get_variation_regular_price('min', true) : $product->get_regular_price();
        $price_sale = $product->is_type('variable') ? $product->get_variation_sale_price('min', true) : $product->get_sale_price();
        if ($price_regular != $price_sale) {
            return round(floatval($price_sale) / $installments, 2);
        }
    }
    return false;
}

function get_max_installments()
{
    $max_installments = get_field('max_installments', 'option');
    return ($max_installments) ? $max_installments : '12';
}

function get_currency_symbol(){
    return (get_field('currency_symbol', 'option')) ? get_field('currency_symbol', 'option') : '$';
}

function get_installments_string($installment = null)
{
    $installment = ($installment) ? $installment : get_installments();
    if (intval($installment) != 1) {
        return 'cuotas';
    }
    return 'cuota';
}

function get_price_installments($price, $dues = 12)
{
    $result = (!empty($price)) ? $price / $dues : 0;
    if (is_decimal($result)) {
        return number_format($result, 2, ',', '');
    } else {
        return $result;
    }
}

function is_decimal( $val ){
    return is_numeric( $val ) && floor( $val ) != $val;
}



function get_product_price_installments($product_id, $dues)
{
    $product = wc_get_product($product_id);
    if ($product->is_on_sale()) {
        return get_sale_price_installments($product, $dues);
    }
    return get_regular_price_installments($product, $dues);
}

function get_regular_price_installments($product, $dues = 12)
{
    return get_price_installments($product->get_regular_price(), $dues);
}

function get_sale_price_installments($product, $dues = 12)
{
    return get_price_installments($product->get_sale_price(), $dues);
}

function get_cart_total_installments($dues = 12)
{
    return get_price_installments(WC()->cart->cart_contents_total, $dues);
}

function get_sale_discount_percentage($product)
{
    //if( $product->is_on_sale() && ! is_admin() && ! $product->is_type('variable')){
    $percentage = 0;
    if ($product->is_on_sale()) {
        // Get product prices
        $regular_price = (float) $product->get_regular_price(); // Regular price
        $sale_price = (float) $product->get_sale_price(); // Active price (the "Sale price" when on-sale)
        $percentage = round(100 - ($sale_price / $regular_price * 100), 1);
    }
    return $percentage;
}

function get_variation_sale_discount_percentage($price, $old_price)
{
    $regular_price = (float) $old_price; // Regular price
    $sale_price = (float) $price; // Active price (the "Sale price" when on-sale)
    $percentage = round(100 - ($sale_price / $regular_price * 100), 1);
    return $percentage;
}

function get_sale_discount($product)
{
    //if( $product->is_on_sale() && ! is_admin() && ! $product->is_type('variable')){
    $discount = 0;
    if ($product->is_on_sale()) {
        // Get product prices
        $regular_price = (float) $product->get_regular_price(); // Regular price
        $sale_price = (float) $product->get_sale_price(); // Active price (the "Sale price" when on-sale)
        $discount = round($regular_price - $sale_price);
    }
    return $discount;
}

function get_installments()
{
    $template = get_page_template_slug();
    $cookie_name = 'installments-cookie-' . ICL_LANGUAGE_CODE;
    //$cookie_value = isset($_COOKIE[$cookie_name]) ? intval($_COOKIE[$cookie_name]) : 0;
    $max_installments = get_field('max_installments', 'option');
    /*if (($cookie_value == 0) || ($cookie_value > $max_installments)){
        //set the cookie to max installments
        $cookie_value = $max_installments ? $max_installments : '12';
    }*/

    if (is_single()) {
        global $product;
        $id = $product->ID;
        $father_post_id = get_field('father_post_id', $id);
        if (is_producto($father_post_id)) {
            return ($max_installments > 6) ? 6 : $max_installments;
        } else {
            return $max_installments;
        }
    }
    if (is_page_template('pages/carrito.php') || is_page_template('pages/pagos.php') || is_cart()) {
        $cookie_value = isset($_COOKIE[$cookie_name]) ? intval($_COOKIE[$cookie_name]) : 0;
        if (($cookie_value == 0) || ($cookie_value > $max_installments)) {
            //set the cookie to max installments
            $max_installments = $max_installments ? $max_installments : '12';
        } else {
            $max_installments = $cookie_value;
        }
        global $woocommerce;
        $woocommerce->cart->get_cart();
        if (only_bibliographies_in_cart($woocommerce->cart->get_cart())) {
            return ($max_installments <= 6) ? $max_installments : 6;
        }
    }
    return $max_installments;
}

function format_number($number){
    if (strlen($number) > 3){
        return number_format(floatval($number), 0, ',', '.');
    }
    return $number;
}


function get_usd_price($post_id)
{
    if (get_post_type($post_id) == 'product') {
        $father_id = get_field('father_post_id', $post_id);

        $father_usd_price = get_field('price_usd', $father_id);
        $father_usd_price_sale = get_field('price_usd_sale', $father_id);

        $product_usd_price = get_field('price_usd', $post_id);
        $product_usd_price_sale = get_field('price_usd_sale', $post_id);

        //Check if the USD price for the Woocommerce product is set
        if (!empty($product_usd_price) || !empty($product_usd_price_sale)) {
            if (!empty($product_usd_price_sale)) {
                return $product_usd_price_sale;
            }
            if (!empty($product_usd_price)) {
                return $product_usd_price;
            }
        } else {
            //As the woocommerce USD price is not set, we use the abstract product usd price
            if (!empty($father_usd_price_sale)) {
                return $father_usd_price_sale;
            }
            if (!empty($father_usd_price)) {
                return $father_usd_price;
            }
        }
    }
    return false;
}

function consider_coupons()
{
	$answer = array();

	$coupons = WC()->cart->get_coupons();

	foreach ($coupons as $c) {
		$newC = array();
		$newC['name'] = $c->get_code();
		$newC['amount'] = $c->get_amount();

		$answer[] = $newC;
	}

	return ($answer);
}

// add_action('wp_ajax_nopriv_eliminarcupones','eliminarcupones');
// add_action('wp_ajax_eliminarcupones','eliminarcupones');

// function eliminarcupones(){
//     global $woocommerce;
//     // $user_id = apply_filters('determine_current_user', false);
// 	// wp_set_current_user($user_id);
// 	// $user = get_userdata($user_id);
//     foreach ( $woocommerce->cart->get_coupons() as $code => $coupon ){
       
//         $woocommerce->cart->remove_coupon( $code );
    
//      }
//     //  $woocommerce->cart->remove_coupon('FREEPRO' );
//     // WC()->cart->remove_coupons();
//     $woocommerce->cart->calculate_totals();
//     // print_r(WC()->cart->get_coupons());
//      wc_clear_notices();    
//      echo 1;
//      die();
//      return 1;
// }

// eliminarcupones();

function util_append_discounts($products)
{

	$coupons = WC()->cart->get_coupons();

	//recorro productos, y observo qué cupones les corresponden
	foreach ($products as $k => $p) {
		$object_product = wc_get_product($p['item_id']);

		foreach ($coupons as $c) {
			$disc = (float) $c->get_amount();

			if ($c->is_valid_for_product($object_product)) {
				$products[$k]['discount'] += $disc;
			}
		}
	}
	return ($products);
}



function filterPaisSimple($carry,$item){
    $cc =str_replace('.devs','',get_country_code_from_subdomain());

    if($item['codigo_de_pais']==$cc){
        $carry += $item['precio'];
    }
    
    return $carry;
}

function filterPais($carry,$item){
    $cc =str_replace('.devs','',get_country_code_from_subdomain());

    if($item['codigo_de_pais']==$cc){
        $carry += $item['precio'] * $_SESSION['plan_de_estudio'];
    }

    return $carry ;
}


function is_disabled_country()
{
    // All countries have been enabled
    $disabled_countries = [];
    //$disabled_countries = ['cr', 'ec', 'sal', 'es', 'ni', 'pnm', 'py'];
    $country = ICL_LANGUAGE_CODE;
    if (in_array($country, $disabled_countries)) {
        return true;
    };
    return false;
}

function accepts_mercadopago()
{
    if (ICL_LANGUAGE_CODE == 'AR') {
        return true;
    }
    return false;
}

function get_wpml_country_code_from_iso($country_code)
{
    $countries = get_country_codes_iso_wpml_array();
    return $countries[$country_code];
}

function get_iso_country_code_from_wpml($country_code)
{
    $countries = get_country_codes_iso_wpml_array();
    return array_search($country_code, $countries);
}

function get_country_code_by_IP()
{
    /*
	 * Countries by ID
	 * https://dev.maxmind.com/geoip/legacy/codes/iso3166/
	 *
	 *  Argentina ["AR"]=>"Argentina"
		Uruguay ["UY"]=>"Uruguay"
		Paraguay "PY"]=>"Paraguay"
		Chile  ["CL"]=>"Chile"
		Perú ["PE"]=>"Perú"
		Ecuador ["EC"]=> "Ecuador"
		Colombia ["CO"]=> "Colombia"
		Mexico ["MX"]=> "México"
		España ["ES"]=>"España"
		Costa Rica ["CR"]=> "Costa Rica"
		El Salvador => ["SV"]
		Nicaragua => ["NI"]
		Panamá => ["PA"]
	 * */

    $available_countries = get_iso_code_countries_from_wpml();
    $geo      = new WC_Geolocation(); // Get WC_Geolocation instance object
    $user_ip  = $geo->get_ip_address(); // Get user IP
    $user_geo = $geo->geolocate_ip($user_ip); // Get geolocated user data.
    $country  = $user_geo['country']; // Get the country code
    $country  = (in_array($country, $available_countries)) ? $country : 'AR';
    return  get_wpml_country_code_from_iso($country);
}






?>