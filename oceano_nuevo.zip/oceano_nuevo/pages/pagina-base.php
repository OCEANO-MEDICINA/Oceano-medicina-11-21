<?php

/**
 * Template Name: Pagina base
 */
 
get_header(null, [ 'type_header' => 'translucent' ]);?>

 <style>
    .hero { background: 25% top url(<?= get_template_directory_uri().'/assets/media/textura.png'?>) ;background-size: cover;
        background-color: rgb(70 103 189);}
    .wpdberror{ display:none; }
    #error{ display:none; }
 </style>

<section id="hero" class="hero">
    <article class="hero-cont contenedor mx-auto ">
    
        <h1 class="is-uppercase">PAGINA EN CONSTRUCCION</h1>

        <!-- <h2 class="is-uppercase">La herramienta de hoy para <span class="salto-de-linea">impulsar tu futuro</span> -->
        </h2>
    </article>
</section>

<?php get_footer(null, [ 'type_footer' => 'full' ]); ?>

