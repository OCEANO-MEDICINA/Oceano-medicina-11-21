<?php

/**
 * Template Name: Planes_estudio
 */
 
get_header(null, [ 'type_header' => 'translucent' ]);

$country_code = '';
if (defined('ICL_LANGUAGE_CODE')) {
	if (ICL_LANGUAGE_CODE != 'arg') {
		$country_code = '/' . ICL_LANGUAGE_CODE;
	}
}


/*  ------  Funciones y obtencion de datos desde el backend ---------- */

// Obtencion de datos para la seccion II.CTA-PLANES
$telefonoContacto = get_field('telefonocontacto', 'options');
$tituloContacto = get_field('titulo', 'options');
$placeholderContacto = get_field('placeholder', 'options');
$linkContacto = get_field('link', 'options')['url'];

// Obtencion de datos para la seccion 1.HERO.
$hero = get_postType('slider-plan', 1);
$camposHero = get_field('slider_plan', $hero->ID)[0];
$tituloHero = $camposHero['titulo'];
$subtitulosHero = $camposHero['sub_titulo'];
$imagensHero = $camposHero['imagen']['url'];


// Obtencion de datos para la seccion 2.SELECCION-PLAN
$Planes = get_postType('plan-tienda', 1);
$camposPlan12 = get_field('plan_12', $Planes->ID)[0];
$camposPlan18 = get_field('plan_18', $Planes->ID)[0];
$camposPlan24  = get_field('plan_24', $Planes->ID)[0];

/* Plan 12 */
$tituloPlan12 = $camposPlan12['titulo'];
$subtituloPlan12 = $camposPlan12['sub_titulo'];
$descripcionPlan12 = $camposPlan12['descripcion'];
$caracteristicaPlan12 = $camposPlan12['caracteristica'];
$aclaracionPlan12 = $camposPlan12['aclaracion_'];
$precioPlan12 = array_reduce($camposPlan12['precios'], 'filterPaisSimple');

/* Plan 18 */
$tituloPlan18 = $camposPlan18['titulo'];
$subtituloPlan18 = $camposPlan18['sub_titulo'];
$descripcionPlan18 = $camposPlan18['descripcion'];
$caracteristicaPlan18 = $camposPlan18['caracteristica'];
$aclaracionpPlan18 = $camposPlan18['aclaracion_'];
$aclaracion2Plan18 = $camposPlan18['aclaracion2'];
$precioPlan18 = array_reduce($camposPlan18['precios'], 'filterPaisSimple');

/* Plan 24 */
$tituloPlan24 = $camposPlan24['titulo'];
$subtituloPlan24 = $camposPlan24['sub_titulo'];
$descripcionPlan24 = $camposPlan24['descripcion'];
$caracteristicaPlan24 = $camposPlan24['caracteristica'];
$aclaracionPlan24 = $camposPlan24['aclaracion_'];
$aclaracion2Plan24 = $camposPlan24['aclaracion2'];
$aclaracion3Plan24 = $camposPlan24['aclaracion3'];
$precioPlan24 = array_reduce($camposPlan24['precios'], 'filterPaisSimple');

// print_r(get_subfield('precios',$plan12->ID));

?>

<style>
    @media screen and (min-width: 767px){.hero { background: 25% top url(<?= $imagensHero;?>);background-size: cover }}
    .wpdberror{ display:none; }
    #error{ display:none; }
 </style>

<style>
.notification {
  padding: 0;
  z-index: 100;
  position: absolute;
  background: transparent;
  width: min(100% - 32px, 646px);
  top: 14vh;
  left: 50%;
  -webkit-transform: translateX(-50%);
          transform: translateX(-50%);
          position: -webkit-sticky;
    position: sticky;
 
}

.notification.success .notification-cont {
  border: 1px solid #32bea6;
}

.notification.error .notification-cont {
  border: 1px solid #e04f5f;
}

.notification-cont {
  width: 100%;
  padding: 1rem 1rem;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: justify;
      -ms-flex-pack: justify;
          justify-content: space-between;
  background: #ffffff;
  -webkit-box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
          box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
  border-radius: 4px;
}

.notification-cont .info {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-column-gap: 1rem;
          column-gap: 1rem;
}

.notification-cont .info i {
  line-height: 1;
}

.notification-cont .info h5 {
  font-size: 1.25rem;
  font-weight: 700;
  color: #02204d;
}

.notification-cont button {
  cursor: pointer;
}

</style>



<!----1.HERO---->

<section id="hero" class="hero">
    <article class="hero-cont contenedor mx-auto">
        <h1 class="is-uppercase"><?= $tituloHero ?></h1>
        <h2 class="is-uppercase"><?= $subtitulosHero ?></h2>
    </article>
</section>

<section id="notification-error" class="notification error" style="display:none;">
         <article class="notification-cont">
             <div class="info">
                 <i class="mdi mdi-close-circle is-size-1 has-text-danger"></i>
                 <div class="info-text">
                     <h5>Error</h5>
                     <h6>ya hay 4 cursos secundarios seleccionados!</h6>
                 </div>
             </div>
             <button id="close-notif"><i class="mdi mdi-close is-size-5"></i></button>
         </article>
        </section>

<!----1.END-HERO---->


<section id="plan" class="plan">
    <div class="solapa-sup"></div>
    <article class="plan-cont contenedor mx-auto">
        <div class="plan-cont-header">
            <div class="plan-cont-header-info">
                <div id="plan-title-1" class="plan-cont-header-info-title title-1">
                    <h3>PLANES DE ESTUDIO</h3>
                    <h4>Seleccioná el tuyo de acuerdo
                        a tus expectativas</h4>
                </div>
                <div id="plan-title-2" class="plan-cont-header-info-title title-2 invisible">
                    <h3>CURSO PRINCIPAL</h3>
                    <h4>Seleccioná un curso de la lista</h4>
                </div>
                <div id="plan-title-3" class="plan-cont-header-info-title title-3 invisible">
                    <h3>CURSOS SECUNDARIOS</h3>
                    <h4>Seleccioná hasta 4 cursos</h4>
                </div>
                <div id="plan-title-4" class="plan-cont-header-info-title title-4 invisible">
                    <h3>CONFIRMACIÓN</h3>
                    <h4>Confirmá tu plan de estudio elegido</h4>
                </div>
                <div class="plan-cont-header-info-bajada">
                    <p>¿Necesitás ayuda?</p>
                    <a target="_blank" class="btn-mid" href="<?= $linkcel ?>"><i class="mdi mdi-whatsapp"></i> CONTACTANOS POR WHATSAPP</a>
                </div>
            </div>
            <div class="plan-cont-header-progress">
                <div class="progress">
                    <div id="progress" class="progress progress-bar background-primary" style="width: 0%"
                        role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <div class="progress-item">
                    <div id="progress-1" class="numbers active">
                        <div class="num">1</div>
                        <div class="circle"></div>
                    </div>
                    <span>Planes de estudio</span>
                </div>
                <div class="progress-item">
                    <div id="progress-2" class="numbers">
                        <div class="num">2</div>
                        <div class="circle"></div>
                    </div>
                    <span>Curso principal</span>
                </div>
                <div class="progress-item">
                    <div id="progress-3" class="numbers">
                        <div class="num">3</div>
                        <div class="circle"></div>
                    </div>
                    <span>Cursos secundarios</span>
                </div>
                <div class="progress-item">
                    <div id="progress-4" class="numbers">
                        <div class="num">4</div>
                        <div class="circle"></div>
                    </div>
                    <span>Confirmar</span>
                </div>
            </div>
        </div>

        <!----2.SELECCION-PLAN---->

        <div id="paso-1" class="paso paso-1">
            <div class="swiper">
                <div class="swiper-pagination-clickable"></div>
                <div class="swiper-wrapper">
                    <!-- Slides -->

                    <div class="swiper-slide">
                        <div class="card-plan">
                            <div class="card-plan-header">
                                <h3 class="card-plan-header-title"><?= $tituloPlan12 ?></h3>
                                <h4 class="card-plan-header-subtitle"><?= $subtituloPlan12 ?></h4>
                            </div>
                            <ul class="card-plan-list">
                                <li><?= $descripcionPlan12['item_1'] ?></li>
                                <li><?= $descripcionPlan12['item_2'] ?></li>
                                <li><?= $descripcionPlan12['item_3'] ?></li>
                                <li><?= $descripcionPlan12['item_4'] ?></li>
                                
                            </ul>
                            <div class="card-plan-specs">
                                <div class="card-plan-specs-grid">
                                    <div class="specs-item">
                                        <i class="mdi mdi-hours-24"></i>
                                        <p><?= $caracteristicaPlan12['item_1'] ?></p>
                                    </div>
                                    <div class="specs-item">
                                        <i class="mdi mdi-whatsapp"></i>
                                        <p><?= $caracteristicaPlan12['item_2'] ?></p>
                                    </div>
                                </div>
                                <div class="card-plan-specs-info"></div>
                            </div>
                            <div class="card-plan-footer">
                                <h4><?= get_currency_symbol() . format_number($precioPlan12) ?> <span class="mes"> / mes</span> </h4>
                                <a idplan='12' href="#hero" class="btn btn-big btn-elegir_planEstudio">ELEGIR PLAN</a>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="card-plan">
                            <div class="card-plan-header">
                                <h3 class="card-plan-header-title"><?= $tituloPlan18 ?></h3>
                                <h4 class="card-plan-header-subtitle"><?= $subtituloPlan18 ?></h4>
                            </div>
                            <ul class="card-plan-list">
                                <li><?= $descripcionPlan18['item_1'] ?></li>
                                <li><?= $descripcionPlan18['item_2'] ?></li>
                                <li><?= $descripcionPlan18['item_3'] ?></li>
                                <li><?= $descripcionPlan18['item_4'] ?></li>
                              
                            </ul>
                            <div class="card-plan-specs">
                                <div class="card-plan-specs-grid">
                                    <div class="specs-item">
                                        <i class="mdi mdi-hours-24"></i>
                                        <p><?= $caracteristicaPlan18['item_1'] ?></p>
                                    </div>
                                    <div class="specs-item">
                                        <i class="mdi mdi-whatsapp"></i>
                                        <p><?= $caracteristicaPlan18['item_2'] ?></p>
                                    </div>
                                    <div class="specs-item">
                                        <i class="mdi mdi-sale"></i>
                                        <p><?= $caracteristicaPlan18['item_3'] ?></p>
                                    </div>
                                    <div class="specs-item">
                                        <i class="mdi mdi-book-education-outline"></i>
                                        <p><?= $caracteristicaPlan18['item_4'] ?></p>
                                    </div>
                                </div>
                                <div class="card-plan-specs-info">
                                    <h5 class="first-spec"><?= $aclaracionpPlan18 ?></h5>
                                    <h5><?= $aclaracion2Plan18 ?></h5>
                                </div>
                            </div>
                            <div class="card-plan-footer">
                                <h4><?= get_currency_symbol() . format_number($precioPlan18) ?> <span class="mes"> / mes</span> </h4>
                                <a idplan='18' href="#hero" class="btn btn-big btn-elegir_planEstudio">ELEGIR PLAN</a>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide plan-24">
                        <div class="card-plan plan-24-card">
                            <div class="card-plan-header">
                                <h3 class="card-plan-header-title"><?= $tituloPlan24 ?></h3>
                                <h4 class="card-plan-header-subtitle"><?= $subtituloPlan24 ?></h4>
                            </div>
                            <ul class="card-plan-list">
                                <li><?= $descripcionPlan24['item_1'] ?></li>
                                <li><?= $descripcionPlan24['item_2'] ?></li>
                                <li><?= $descripcionPlan24['item_3'] ?></li>
                                <li><?= $descripcionPlan24['item_4'] ?></li>
                               
                            </ul>
                            <div class="card-plan-specs">
                                <div class="card-plan-specs-grid">
                                    <div class="specs-item">
                                        <i class="mdi mdi-hours-24"></i>
                                        <p><?= $caracteristicaPlan24['item_1'] ?></p>
                                    </div>
                                    <div class="specs-item">
                                        <i class="mdi mdi-whatsapp"></i>
                                        <p><?= $caracteristicaPlan24['item_2'] ?></p>
                                    </div>
                                    <div class="specs-item">
                                        <i class="mdi mdi-sale"></i>
                                        <p><?= $caracteristicaPlan24['item_3'] ?></p>
                                    </div>
                                    <div class="specs-item">
                                        <i class="mdi mdi-book-education-outline"></i>
                                        <p><?= $caracteristicaPlan24['item_4'] ?></p>
                                    </div>
                                </div>
                                <div class="card-plan-specs-info">
                                    <h5 class="first-spec"><?= $aclaracionPlan24 ?></h5>
                                    <h5><?= $aclaracion2Plan24 ?></h5>
                                    <h6><?= $aclaracion3Plan24 ?></h6>
                                </div>
                            </div>
                            <div class="card-plan-footer">
                                <h4><?= get_currency_symbol() . format_number($precioPlan24) ?> <span class="mes"> / mes</span> </h4>
                                <a idplan='24' href="#hero" class="btn btn-big btn-elegir_planEstudio">ELEGIR PLAN</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!----2.END-SELECCION-PLAN---->
        <!----X.---->
        <!----X.---->
        <!----3.SELECCION-CURSO-PRINCIPAL---->

        <div id="paso-2" class="paso paso-2 invisible">

            <?php $cursosPrincipales = getCursosPrincipales(); ?>

            <div class="grilla-cursos-planes">

                <?php foreach ($cursosPrincipales as $curso) {
					$image = wp_get_attachment_image_src(get_post_thumbnail_id($curso->ID), 'single-post-thumbnail');

				?>
                <div class="course">
                    <div class="course-card">
                        <div class="course-card-img">
                            <div class="img-course">
                                <img class="img-curso" src="<?= $image[0] ?>" alt="imagen del curso <?= $curso->post_title ?>">
                            </div>
                            <div class="avales">
                                <p>AVALES</p>
                                <?php
									$endorsments = get_field('endorsments_list', $curso->ID);
									foreach ($endorsments as $endorsment) {
										$endorsment_id = $endorsment['endorsment'][0]->ID;
									?>
                                        <div class="aval"><img src="<?= get_the_post_thumbnail_url($endorsment_id); ?>" alt="Aval "></div>
									<?php }; ?>
                            </div>
                        </div>
                        <div class="course-card-info">
                            <div class="horas">
                                <i class="mdi mdi-clock-outline"></i>
                                <p class="horasCursoPrincipal"><?= get_field('duration', $curso->ID) ?> HORAS ESTIMADAS DE LECTURA</p>
                            </div>
                            <h4 class="tituloCursoPrincipal"><?= $curso->post_title ?></h4>
                            <p class="descripcionCursoPrincipal"><?= strip_tags(get_field('why_course', $curso->ID)['first_box']['description']) ?></p>
                            <div class="mas-info">
                                <a class="btn btn-mid background-medicina-dark accordion-trigger">
                                    CONOCER MÁS <i class="mdi mdi-chevron-down"></i></a>
                                <div class="accordion-panel">
                                    <div class="mas-info-autores">
                                        <h6>AUTORES</h6>
                                        <ul>
                                        <?php
								            $autores = get_field('authors',         $curso->ID);
								            foreach ($autores as $autor) {
								            	echo '<li>' . $autor['name'] . '</li>';
								            }
								        ?>
                                        </ul>
                                    </div>
                                    <div class="mas-info-modulos">
                                        <h6>MODULOS</h6>
                                        <ul>
                                            <?php
							                    $modulos = get_field('cards', $curso->ID);
							                    foreach ($modulos as $modulo) :?>
							                    <li> <?php  if(strpos($modulo['card_title'], ':')) { echo explode(":",str_replace('Módulo ', '', $modulo['card_title']))[1]; } else { echo explode(".",str_replace('Módulo ', '', $modulo['card_title']))[1]; } ?></li>
                                                <?php endforeach; ?>
                                        </ul>
                                    </div>
                                </div>
                                <a data-id='<?= $curso->wooP->ID ?>' class="btn btn-mid background-ccc seleccionar btn-elegir_CursoPrincipal">SELECCIONAR</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }; ?>
                
               <div id='avanzar_paso_secundarios' class="control-buttons columns">
                   <a class="column prev btn-prev_planEstudio" href="#hero" >VOLVER ATRÁS</a>
                   <a class="column next btn-next_planEstudio" href="#hero" >AVANZAR</a>
               </div>
            </div>
        </div>

        <!----3.END-SELECCION-CURSO-PRINCIPAL--->
        <!----X.---->
        <!----X.---->
        <!----4.SELECCION-CURSO-SECUNDARIO---->

        <div id="paso-3" class="paso paso-3 grid-w-side invisible">
                <div class="grid-w-side-cont">
                    <div class="grid-w-side-cont-filtros filtros">
                        <div class="cta-main-course">
                            <span>CURSO PRINCIPAL</span>
                            <h5 class="titulocursoprincipal">Formación integral en obstetricia</h5>
                            <a href="#hero" class="btn btn-mid botoncambiarcurso">CAMBIAR CURSO</a>
                        </div>
                        <div class="filtros-cont">
                            <div class="searchbar-cursos-sec">
                                <div class="field">
                                    <p class="control has-icons-left has-icons-right">
                                        <input id="quicksearch" class="input searchbar-cursos-sec-campo" type="search"
                                            placeholder="Buscar">
                                        <span class="icon is-small is-left">
                                            <i class="mdi mdi-magnify"></i>
                                        </span>
                                        <span class="icon is-small is-right">
                                            <i class="mdi mdi-chevron-right"></i>
                                        </span>
                                    </p>
                                </div>

                            </div>
                            <div class="filtros-cont-seleccionados">
                                <a class="accordion-trigger" onclick="">
                                    <span class="text-mobile">Tus cursos secundarios</span>
                                    <span class="text-desktop">Cursos secundarios</span>
                                    <i class="mdi mdi-chevron-down"></i></a>
                                <span class="trigger-bajada">Elige 4 más</span>
                                <ul class="accordion-panel">
                                    
                                    <li><a class="cursoSecundario"  id='cursoSecundario1' n='1'>Sin Elegir</a></li>
                                    <li><a class="cursoSecundario"  id='cursoSecundario2' n='2'>Sin Elegir</a></li>
                                    <li><a class="cursoSecundario"  id='cursoSecundario3' n='3'>Sin Elegir</a></li>
                                    <li><a class="cursoSecundario"  id='cursoSecundario4' n='4'>Sin Elegir</a></li>
                                        
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="grid-cursos">
                        <div class="grid-cursos-filters">
                            <div class="searchbar-cursos-sec">
                                <div class="field">
                                    <p class="control has-icons-left has-icons-right">
                                        <input id="quicksearch2" class="input searchbar-cursos-sec-campo" type="search"
                                            placeholder="Escribí tu especialidad de interés">
                                        <span class="icon is-small is-left">
                                            <i class="mdi mdi-magnify"></i>
                                        </span>
                                        <span class="icon is-small is-right">
                                            <i class="mdi mdi-chevron-right"></i>
                                        </span>
                                    </p>
                                </div>

                            </div>

                            <style>
                                .plan-cont .paso-3 .sorting-cont.menu-desplegable {bottom: -0.5rem;}   
                            </style>

                            <style>
                                .carrito-empty-cont {
                                    display: -webkit-box;
                                    display: -ms-flexbox;
                                    display: flex;
                                    -webkit-box-orient: vertical;
                                    -webkit-box-direction: normal;
                                    -ms-flex-direction: column;
                                    flex-direction: column;
                                    -webkit-box-pack: center;
                                    -ms-flex-pack: center;
                                    justify-content: center;
                                    -webkit-box-align: center;
                                    -ms-flex-align: center;
                                    align-items: center;
                                    padding: 3.5rem 0;
                                }   
                                .carrito-empty-cont h1 {
                                    font-size: clamp(1.5rem, 2vw, 2.25rem);
                                    font-weight: 700;
                                    color: #02204d;
                                }
                                .carrito-empty-cont h2 {
                                    font-size: clamp(1rem, 2vw, 1.125rem);
                                }
                                .carrito-empty-cont a {
                                    margin-top: 1.5rem;
                                }

                            </style>

                            <div class="sorting" >

                                <a id="btnOrdenarPor" class="btn-filtro"><i class="mdi mdi-sort"></i> Ordenar</a>
                                <div class="sorting-cont menu-desplegable">
                                    <a class="sorting-cont-button accordion-trigger" type="button" id="dropdownduracion"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        DURACION <i class="mdi mdi-chevron-down"></i>
                                    </a>
                                    <ul class="accordion-panel" aria-labelledby="dropdownMenuButton1">
                                        <li><a class="dropdown-item order_button" data-sortby="duracionAsc">Mayor a
                                                menor <i class="mdi mdi-radiobox-marked"></i></a>
                                        </li>
                                        <li><a class="dropdown-item order_button" data-sortby="duracionDes">Menor a
                                                mayor <i class="mdi mdi-radiobox-blank"></i></a>
                                        </li>
                                    </ul>
                                    <a class="sorting-cont-button accordion-trigger" type="button" id="dropdownnovedad"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        NOVEDAD <i class="mdi mdi-chevron-down"></i>
                                    </a>
                                    <ul class="accordion-panel" aria-labelledby="dropdownMenuButton1">
                                        <li><a class="dropdown-item order_button" data-sortby="novedadAsc">Novedades
                                                Primero
                                                <i class="mdi mdi-radiobox-blank"></i></a>
                                        </li>
                                        <li><a class="dropdown-item order_button" data-sortby="novedadDes">Novedades
                                                Ultimo
                                                <i class="mdi mdi-radiobox-blank"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            

                        </div>
                        <div class="grilla-cursos-planes">

                        <section id="cursos-empty" class="carrito-empty" style="display:none;">
                                <article class="carrito-empty-cont ">
                                    <h1>No hay cursos</h1>
                                    <h2>¡Proba buscando de nuevo!</h2>
                                </article>
                            </section>

                        <?php
						$cursosSecundarios = getCursosSecundarios();
						foreach ($cursosSecundarios as $curso) {
							$image = wp_get_attachment_image_src(get_post_thumbnail_id($curso->ID), 'single-post-thumbnail');
							$cateogrias_course_array = wc_get_product_category_list($curso->ID, '_', '', '');
							$cateogrias_course = strip_tags(removeAccents(strtolower(str_replace('_', ' ', str_replace(' ', '-', $cateogrias_course_array)))));
							$novedad = (get_field("novedad", $curso->ID));
						?>

                            <div class="course course_secundario" data-id='<?= $curso->wooP->ID ?>' data-horas="<?= get_field('duration', $curso->ID) ?>" data-novedad="<?= $novedad; ?>" disabled>
                                <div class="course-card">
                                    <div class="course-card-img">
                                        <div class="img-course">
                                            <img class="img-curso" src="<?= $image[0] ?>" alt="imagen del curso de <?= $curso->post_title ?>">
                                        </div>
                                        <div class="avales">
                                            <?php
											    $endorsments = get_field('endorsments_list', $curso->ID);
											
											    foreach ($endorsments as $endorsment) {
											    	$endorsment_id = $endorsment['endorsment'][0]->ID;
											    ?>
											    	<div class="aval">
											    		<img src="<?= get_the_post_thumbnail_url($endorsment_id); ?>" alt="Imagen aval">

											    	</div>
											<?php } ?>
                                        </div>
                                    </div>
                                    <div class="course-card-info">
                                        <div class="horas">
                                            <i class="mdi mdi-clock-outline"></i>
                                            <p class="horasCursoSecundario"><?= get_field('duration', $curso->ID) ?> HORAS ESTIMADAS DE LECTURA</p>
                                        </div>
                                        <h4 class="tituloCursoSecundario"><?= $curso->post_title ?></h4>
                                        <p class="descripcionCursoSecundario"><?= strip_tags(get_field('why_course', $curso->ID)['first_box']['descripcion_corta']) ?></p>

                                        <div class="mas-info">
                                            <a class="btn btn-mid background-medicina-dark accordion-trigger">
                                                CONOCER MÁS <i class="mdi mdi-chevron-down"></i></a>
                                            <div class="accordion-panel">

                                                <div class="mas-info-autores">
                                                    <h6>AUTORES</h6>
                                                    <ul>
                                                        <?php
										                    $autores = get_field('authors', $curso->ID);
										                    foreach ($autores as $autor) {
										                    	echo '<li>' . $autor['name'] . '</li>';
										                    }
                                                        
										                ?>
                                                    </ul>
                                                </div>
                                                <div class="mas-info-modulos">
                                                    <h6>MODULOS</h6>
                                                    <ul>
                                                        <?php
							                             $modulos = get_field('cards', $curso->ID);
							                                foreach ($modulos as $modulo) :?>
							                                    <li> <?php  if(strpos($modulo['card_title'], ':')) { echo explode(":",str_replace('Módulo ', '', $modulo['card_title']))[1]; } else { echo explode(".",str_replace('Módulo ', '', $modulo['card_title']))[1]; } ?></li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <a class="btn btn-mid background-ccc seleccionar btn-elegir_CursoSecundario" data-id='<?= $curso->wooP->ID ?>'>SELECCIONAR</a>

                                        </div>

                                    </div>
                                </div>

                            </div>
                        <?php } ?>
                            
                        </div>
                    </div>
                    <div class="control-buttons columns">
                        <a class="column prev btn-prev_planEstudio" href="#hero" >VOLVER ATRÁS</a>
                        <a class="column next btn-next_planEstudio" href="#hero" >AVANZAR</a>
                    </div>
                </div> 

        </div>

        <div style="display: none"class="course" id='elbloquemodelo'> 
                    <div class="course-card">
                        <div class="course-card-img">
                            <div class="img-course">
                                <img id='itemlistado_imagen' class="img-curso" src="" alt="Imagen del curso">
                            </div>
                        </div>
                        <div class="course-card-info">
                            <div class="horas">
                                <i class="mdi mdi-clock-outline"></i>
                                <p id='itemlistado_lectura'>Horas</p>
                            </div>
                            <h4 id="itemlistado_titulo"> Titulo</h4>
                            <p id='itemlistado_descripcion'> </p>
                        </div>
                    </div>
                </div>

        <div id="paso-4" class="paso paso-4 invisible">
            <div class="main-course-cont" id='step4_principal'>
                <h3 class="is-uppercase">CURSO PRINCIPAL</h3>
                
            </div>
            <div class="secondary-course-cont" id='step4_secundarios'>
                <h3 class="is-uppercase">CURSOS SECUNDARIOS</h3>
            </div>
            <div class="control-buttons columns">
                        <a class="column prev btn-prev_planEstudio" href="#hero" >VOLVER ATRÁS</a>
                        <a id="confirmar_y_enviar"class="column next btn-next_planEstudio" >CONFIRMAR</a>
            </div>
        </div>
    </article>
</section>

<!----I.END-PASO-3--->
<!----X.---->
<!----X.---->
<!----II.CTA-PLANES--->
<section id="cta-planes" class="cta-planes">
    <article class="cta-planes-cont contenedor">
        <div class="info">
            <img src="<?= get_template_directory_uri().'/assets/media/icon/phone-call 1.svg'?>" alt="icono de telefono">
            <div>
                <span><?= $tituloContacto ?></span>
                <p><?= $telefonoContacto ?></p>
            </div>
        </div>
        <a target="_blank" href="<?= $linkContacto ?>"><i class="mdi mdi-whatsapp"></i> <?= $placeholderContacto ?></a>
    </article>
</section>


<?php get_footer(null, [ 'type_footer' => 'full' ]); ?>