<?php

/**
 * Template Name: Gracias Pagos
 */

if (sizeof(WC()->cart->get_cart()) == 0) {
	header('LOCATION: /');
}
 
get_header(null, [ 'type_header' => 'translucent' ]);



$plan = $_SESSION['plan_de_estudio'];

$coupons = WC()->cart->get_coupons();

$totalventa = get_cart_total_installments(1);
$totalventason = get_cart_total_installments(1);


if ($plan != '') {

    $plan0 = null;

    switch ($_SESSION['plan_de_estudio']) {
        case '12':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_12', $plan0->ID)[0];
            break;
        case '18':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_18', $plan0->ID)[0];
            break;
        case '24':
            $plan0 = get_postType('plan-tienda', 1);
            $plan0 = get_field('plan_24', $plan0->ID)[0];
            break;
    }
    
    $totalventa = array_reduce($plan0['precios'], 'filterPais');
   
    foreach ($coupons as $key => $coupon) {
        $discount_type = $coupon->get_discount_type(); // Get coupon discount type
        $coupon_amount = $coupon->get_amount();

        if ($discount_type == 'percent') {
            $totalventa = $totalventa - (($totalventa * $coupon_amount) / 100);
        }
    }
}
function get_cart_total_installments_nuevo($i = 1, $totalventa)
{

	if ($_SESSION['plan_de_estudio'] != '') {
		return ($totalventa / $i);
	}


	return get_cart_total_installments($i);
}

?>


<style type="text/css">
	.itemresum {
		margin-bottom: 0px;
		text-align: left;
		margin: 0px 10px;
		font-size: 16px !important;
		color: rgba(73, 73, 73, 1) !important;
	}

	h3.titulogracias {
		font-size: 38px;
		font-weight: 700;
	}

	
	h6.nombrecupon {
		font-weight: 500;
		font-family: inherit;
		font-size: 20px;
		color: #494949;
	}

	p.enviamosmail {
		font-family: inherit;
		font-weight: 500;
		font-size: 24px;
	}

	button.botoniralinicio {
		font-size: 20px;
		font-weight: 500;
		font-family: inherit;
	}

	p.resum {
		color: #203B83;
		font-size: 22px !important;
		 font-family: inherit;
		font-weight: 500;
		margin: 10px 10px;
	}

	p.totalgracias {
		font-size: 20px !important;
		font-family: inherit;
		font-weight: 700;
		color: #494949;
		text-align: left;
		margin-left: 10px;
	}

	.nombrecupon {
		color: #494949;
	}

	.seguri {
		color: #494949;
	}

	.cardresumen {
		margin: 20px 70px;
		padding: 24px 20px;
	}

	@media (max-width: 768px) {
		#infonosotros p {
			text-align: left;
		}}

		.enviamosmail {
			text-align: center;
		}

		.textabajocandado {
			text-align: center;
			margin-top: 20px;
		}

	

	@media (min-width: 1200px) {
		p.textabajocandado {
			margin-left: -70px;
		}
	}
	#infonosotros {
    padding: 60px 0;
}
.grey {
    background-color: #f4f4f4;
    padding: 4px 0 100px;
}

#infonosotros .white.nosotros.row, #infonosotros .white.gracias.row {
    padding: 50px 0;
    border-radius: 15px;
}
#infonosotros .row {
    padding: 0;
}

@media only screen and (min-width: 769px) and (max-width: 2000px){
.gracias {
    margin: 0 100px!important;
}}
.white {
    background-color: #fff;
    padding-top: 50px;
}
#infonosotros .white.nosotros.row, #infonosotros .white.gracias.row {
    padding: 50px 0;
    border-radius: 15px;
}
#infonosotros .row {
    padding: 0;
}

@media only screen and (min-width: 769px) and (max-width: 2000px){
.gracias {
    margin: 0 100px!important;
}}
.white {
    background-color: #fff;
    padding-top: 50px;
}
#infonosotros .contenido img {
    position: absolute;
    bottom: -51px;
    left: 2px;
    max-width: 95%;
}
.cleckgracias {
    position: initial!important;
    margin: auto;
}
img, svg {
    vertical-align: middle;
}
h3.titulogracias {
    font-size: 38px;
    font-weight: 700;
}
.titulogracias {
    font-weight: 700;
    color: #203b83;
    letter-spacing: .5px;
	font-family: inherit;
    word-wrap: break-word;
    margin-bottom: 30px;
}
h6.ensuresumen{
    text-align: center!important;
    transition: all 300ms ease;
    list-style: none;
    box-sizing: border-box;
    clear: both;
    color: inherit;
    margin-top: 0;
    margin-bottom: .5rem;
    font-weight: 500;
    line-height: 1.2;
    font-size: 1rem;
	font-family: inherit;
}
h6.nombrecupon {
    font-weight: 500;
	font-family: inherit;
    font-size: 20px;
    color: #494949;
}

.nombrecupon {
    color: #494949;
}
.nombrecupon {
    font-weight: 700;
    margin-bottom: 25px;
}
#infonosotros p {
    font-size: 16px;
    line-height: 24px;
}

p.enviamosmail {
	font-family: inherit;
    font-weight: 500;
    font-size: 24px;
}
.enviamosmail {
    color: #00b6de;
    font-size: 18px!important;
    font-weight: 700;
    margin: 15px;
}
.cardresumen {
    margin: 20px 70px;
    padding: 24px 20px;
}
.cardresumen {
    margin: 20px 120px;
    background: #f5f5f5;
    border-radius: 10px;
}
.seguri {
    color: #494949;
}

.seguri {
    margin: auto 30%;
}
#infonosotros p {
    font-size: 16px;
    line-height: 24px;
}
p.resum {
    color: #203B83;
    font-size: 22px !important;
     font-family: inherit;
    font-weight: 500;
    margin: 10px 10px;
}
.resum {
    color: #203b83;
    font-weight: 700;
	font-family: inherit;
    margin: 20px 30px;
    text-align: left;
}
#infonosotros p {
    font-size: 16px;
    line-height: 24px;
}
.itemresum {
    margin-bottom: 0px;
    text-align: left;
    margin: 0px 10px;
    font-size: 16px !important;
    color: rgba(73, 73, 73, 1) !important;
}
element.style {
    display: inline;
}
@media only screen and (min-width: 769px) and (max-width: 2000px){
#id_label_total_price {
    font-size: 28px;
}}
.text-center {
    text-align: center!important;
	
}

.aBotonInicio{
	display: flex;
    justify-content: center;
}

.botoniralinicio{

    list-style: none;
    box-sizing: border-box;
    border: 1px solid;
    border-color: #ccc #ccc #bbb;
    padding: .6em 1em .4em;
    overflow: visible;
    border-radius: 0;
    margin: 0;
    line-height: inherit;
    text-transform: none;
    -webkit-appearance: unset!important;
    background: #00b6de;
    color: #fff;
    width: 250px;
    cursor: pointer;
    font-size: 20px;
    font-weight: 500;
    font-family: inherit;
}
.candado{
    list-style: none;
    box-sizing: border-box;
    height: auto;
    border-style: none;
    vertical-align: middle;
    position: initial!important;
    margin: auto;
    bottom: -51px;
    left: 2px;
    max-width: 95%;
}


</style>
<div id="content" class="site-content">
    <div id="primary" class="content-area">
        <main id="main" class="site-main">
        
   
<section id="infonosotros" class="grey">
	<div class="container">
		<div class="col-12">
			<div class="white gracias row">
				<div class="col-12 contenido text-center mb-4">
					<img class="cleckgracias" src="/wp-content/themes/oceano/images/check-circle-gif 1.png">
					<h3 class="titulogracias">Su pago fue procesado</h3>
					<br>
					<h6 class="ensuresumen">En su resumen verá reflejado el cargo como:</h6>

					<?php


					$cc = str_replace('.devs', '', get_country_code_from_subdomain());
					if ($cc == 'ar' || $cc == 'mx') {
						$texto = 'MERCADOPAGO*OCEANOMEDICI';
					} else {
						$texto = 'OCEANO MEDICINA';
					}
					?>
					<h6 class="nombrecupon"><?= $texto ?></h6>
					<img class="cleckgracias" src="/wp-content/themes/oceano/images/msjimg.png">
					<p class="enviamosmail">Te enviamos un mail a tu casilla con los pasos a seguir</p>
					<div class="cardresumen">
						<div class="row ">
							<div class="col-12 col-lg-8">

								<div>

									<p class="resum">Resumen de pago</p>
									<?php
									foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
										$nacCert = $intCert = null;
										$item_id = (!empty($cart_item['variation_id'])) ? $cart_item['variation_id'] : '';
										$_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
										$product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
										$father_post_id = get_field('father_post_id', $product_id);
										$product_name = get_the_title($father_post_id);

										$category = (get_field("main_category", $father_post_id)) ? get_field("main_category", $father_post_id) : null;
										$category_name = ($category) ? $category->name : "Desconocido";
										$category_slug = ($category) ? $category->slug : "";

										if ($item_id) {
											$nacCert = get_cart_item_local_cert($item_id);
											$nacCertSlug = get_cart_item_local_cert_slug($item_id);
											$intCert = get_cart_item_int_cert($item_id);
											$intCertSlug = get_cart_item_int_cert_slug($item_id);
											$int_school = get_field('int_schools', $product_id);
										}

									?>

										<?php
										$items = util_pack_cart_separated();
										foreach ($items['products'] as $i) {
											if ($i['quantity'] > 1) {
												$cantidad = $i['quantity'];
											}
										}
										?>


										<p class="itemresum"><?= $product_name ?></p>


									<?php } ?>

								</div>
							</div>
							<div class="col-12 col-lg-4">
								<p class="resum">Total
								</p>
								<?php
								if ($_SESSION['plan_de_estudio']) {
								?>
									<!-- <div class="listaarticulos row"> -->
									<h5 style="display: inline;" class="price" id="id_label_total_price" data-amount="<?php echo $totalventa; ?>" data-symbol=""><?= get_currency_symbol(); ?><?= format_number(get_cart_total_installments_nuevo($plan, $totalventa)); ?></h5>
									<span class="arsindicepaisdif">
										<?php
										$currency_code = get_field('currency_3_digits_code', 'options');
										echo $currency_code;
										?>
									</span>
									<h5 style="display: inline;">/mes durante <?= $plan ?> meses</h5>

									<!-- </div> -->

								<?php
								} else {
								?>
									<p class="totalgracias">
										<?php
										// if($_COOKIE['installments-cookie-'.ICL_LANGUAGE_CODE])
										$cuotas = $_COOKIE['installments-cookie-' . ICL_LANGUAGE_CODE];
										$total = get_cart_total_installments(1);
										$cuotasDe = $total / $cuotas;
										$cuotasDe = format_number($cuotasDe);
										$s = $cuotas > 1 ? 's' : '';
										$currency_code = get_field('currency_3_digits_code', 'options');

										?>

										<?= $cuotas ?> cuota<?= $s ?> de <?= $cuotasDe; ?> <?= $currency_code; ?>
									</p>
								<?php
								}
								?>

							</div>
						</div>
					</div>
					<div class="seguri">
						<div class="row ">
							<div class="col-12 col-lg-3">
								<img class="candado" src="/wp-content/themes/oceano/images/candado.png">
							</div>
							<div class="col-12 col-lg-9">
								<p class="textabajocandado"><strong>Tu información está a salvo</strong><br>
									Tus datos están encriptados <br> y protegidos.</p>
							</div>
						</div>
					</div>
					<a class="aBotonInicio mt-2"href="<?= get_home_url(); ?>">
						<button class="botoniralinicio btn btn-mid">IR AL INICIO</button>
					</a>
				</div>
				<div class="col-12 contenido text-center">
					<!-- <a href="/shop/?category=curso" class="btn btn-pink"><?= $buttonLabel ?></a> -->
				</div>

			</div>
		</div>
	</div>
</section>
</main>
    </div>
</div>
<?php get_footer(null, [ 'type_footer' => 'full' ]); ?>

