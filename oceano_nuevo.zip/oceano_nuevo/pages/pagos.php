<?php

/**
 * Template Name: Pagos
 */


get_header(null, [ 'type_header' => 'translucent' ]);

// print_r(get_page_template_slug());
// echo get_template_directory();
?>

<section id="breadcrumbs">
    <article class="breadcrumbs-cont contenedor">
        <nav class="breadcrumb" aria-label="breadcrumbs">
            <ul>
                <li><a href="#">Carrito</a></li>
                <li><a href="#">Mis productos</a></li>
                <li class="is-active"><a href="#" aria-current="page">Finalizar compra</a></li>
            </ul>
        </nav>
    </article>
</section>

<style>
    .wpdberror{ display:none; }
    #error{ display:none; }
 </style>


<?php 
    $url = $_SERVER['SERVER_NAME'];
    if (explode(".", $_SERVER['SERVER_NAME'])[0] == 'ar' || explode(".", $_SERVER['SERVER_NAME'])[0] == 'mx') {
      include(get_template_directory() . '/template-parts/pagos/pagos-loc.php');
    }
    else {
      include(get_template_directory() . '/template-parts/pagos/pagos-int.php');
    }
 ?>
                            

<?php get_footer(null, [ 'type_footer' => 'full' ]); ?>