<?php
/**
 * Template Name: Shop
 */

include_once(get_template_directory() . "/woocommerce/archive-product.php");