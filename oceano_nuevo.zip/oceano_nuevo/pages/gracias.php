<?php

/**
 * Template Name: Gracias
 */

// if (sizeof(WC()->cart->get_cart()) == 0) {
// 	header('LOCATION: /');
// }

get_header(null, [ 'type_header' => 'null' ]);

?>
<header>
    <div class="contenedor">
        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar-overlay" class="navbar-overlay"></div>
            <div class="navbar-brand">
                <a id="logo" class="navbar-item logo absolute-center" href="<?= get_home_url(); ?>" target="_blank">
                    <img src="<?= get_template_directory_uri().'/assets/media/logo-oceano-medicina.png'; ?>" alt="Logo de oceano medicina">
                </a>

            </div>
        </nav>
    </div>
</header>

<body>

    <section id="hero" class="hero">
        <article class="hero-cont contenedor mx-auto">
            <h1 class="mb-3">Gracias por elegir <span class="salto-de-linea">nuestros contenidos</span> </h1>
            <h2 class="">Tenemos mucho más para ofrecerte <br>
                y queremos compartírtelo
            </h2>
        </article>
    </section>


    <section id="links" class="links">
        <article class="links-cont contenedor mx-auto">
            <div class="links-card" style="background-image: url(<?= get_template_directory_uri().'/assets/media/link-card-capacitacion-online.jpg'; ?>);">
                <div class="links-card-info">
                    <h3 class="links-card-info-title">Capacitación <br>
                        100% online</h3>
                    <h4 class="links-card-info-subtitle">
                        Más de 120 cursos elaborados <br>
                        por profesionales y avalados <br>
                        por prestigiosas instituciones.</h4>
                </div>

                <img src="<?= get_template_directory_uri().'/assets/media/avales-capacitacion.png'; ?>" alt="lista de avales" class="links-card-avales">
                <a href="/tienda/" target="_blank"
                    class="links-card-button button btn btn-big">Ingresar</a>
            </div>
            <div class="links-card" style="background-image: url(<?= get_template_directory_uri().'/assets/media/link-card-informacion-actualizada.jpg'; ?>);">
                <div class="links-card-info">
                    <h3 class="links-card-info-title">Información <br>
                        actualizada</h3>
                    <h4 class="links-card-info-subtitle">Leé las noticias clave y <br>
                        la opinion de importantes <br>
                        figuras del mundo de la <br>
                        medicina y la ciencia.</h4>
                </div>

                <a href="https://magazine.oceanomedicina.com/" target="_blank" class="links-card-button button btn btn-big">Ingresar</a>
            </div>
        </article>
    </section>

    <footer class="footer">
    <article class="footer-cont mx-auto">
        <a href="<?= get_home_url(); ?>" target="_blank" ><img src="<?= get_template_directory_uri().'/assets/media/logo-footer.png'; ?>" alt="Logo de footer"></a>
        <p class="copy">© 2021 OCEANO MEDICINA Todos los derechos reservados</p>
    </article>
</footer>


<?php get_footer(null, [ 'type_footer' => 'null' ]); ?>
