<?php
/**
 * Template Name: Carrito
 */

include_once(get_template_directory() . "/woocommerce/cart/cart.php");