<?php

/**
 * Template Name: Home
 */
 
get_header(null, [ 'type_header' => 'translucent' ]);


/*  ------  Funciones y obtencion de datos desde el backend ---------- */

// Obtencion de datos para la seccion 1.HERO.C/Searchbar
$hero = get_postType('slider-home', 1);
$camposHero = get_field('home_slider', $hero->ID)[0];
$tituloHero = $camposHero['titulo'];
$subtitulosHero = $camposHero['sub_titulo'];
$imagensHero = $camposHero['imagen_fondo']['url'];
$placeholder = $camposHero['placeholder'];


// Obtencion de datos para la seccion 2.COURSES-TOP
$Tarjetas = get_postType('destacados-home', 1);
$camposTarjeta1 = get_field('destacados_grande', $Tarjetas->ID)[0];
$camposTarjeta2 = get_field('destacado_chico_arriba', $Tarjetas->ID)[0];
$camposTarjeta3 = get_field('destacado_chico_abajo', $Tarjetas->ID)[0];

/* Tarjeta 1 */
$tituloTarjeta1 = $camposTarjeta1['titulo'];
$subtituloTarjeta1  = $camposTarjeta1['sub_titulo'];
$imagenTarjeta1  = $camposTarjeta1['imagen']['url'];
$placeholderTarjeta1 = $camposTarjeta1['placeholder'];
$linkTarjeta1  = $camposTarjeta1['link']['url'];

/* Tarjeta 2 */
$tituloTarjeta2 = $camposTarjeta2['titulo'];
$subtituloTarjeta2  = $camposTarjeta2['sub_titulo'];
$imagenTarjeta2  = $camposTarjeta2['imagen']['url'];
$placeholderTarjeta2 = $camposTarjeta2['placeholder'];
$linkTarjeta2  = $camposTarjeta2['link']['url'];

/* Tarjeta 3 */
$tituloTarjeta3 = $camposTarjeta3['titulo'];
$subtituloTarjeta3  = $camposTarjeta3['sub_titulo'];
$imagenTarjeta3  = $camposTarjeta3['imagen']['url'];
$placeholderTarjeta3 = $camposTarjeta3['placeholder'];
$linkTarjeta3  = $camposTarjeta3['link']['url'];


// Obtencion de datos para la seccion 4.BANNER
$banners_promocionales = get_postType('banner-home', 1);
$camposBanners = get_field('banner_home', $banners_promocionales->ID);

// Obtencion de datos para la seccion 6.REVIEWS
$reviews = get_postType('testimonales-home', 1);
$camposreviews = get_field('testimonial', $reviews->ID);


// Obtencion de datos para la seccion 7.WEBINARS
$Webinars = get_postType('webinars-home', 1);
$camposWebinar1 = get_field('webinars_primera', $Webinars->ID)[0];
$camposWebinar2 = get_field('webinars_segunda_', $Webinars->ID)[0];
$camposWebinar3 = get_field('webinars_tercero', $Webinars->ID)[0];

/* Webinar 1 */
$tituloWebinar1 = $camposWebinar1['titulo'];
$titulowebinarMobile1 = $camposWebinar1['titulo-mobile'];
$fechaWebinar1 = $camposWebinar1['fecha'];
$horaWebinar1 = $camposWebinar1['hora'];
$imgWebinar1 = $camposWebinar1['imagen']['url'];
$linkSuscripcionWebinar1 = $camposWebinar1['link_suscripcion'];
$linkVisualizacionWebinar1 = $camposWebinar1['link_visualizacion'];
$linkWebinar1 = $linkSuscripcionWebinar1 ? $linkSuscripcionWebinar1['url'] : $linkVisualizacionWebinar1['url'];


/* Webinar 2 */
$tituloWebinar2 = $camposWebinar2['titulo'];
$titulowebinarMobile2 = $camposWebinar2['titulo-mobile'];
$fechaWebinar2 = $camposWebinar2['fecha'];
$horaWebinar2 = $camposWebinar2['hora'];
$imgWebinar2 = $camposWebinar2['imagen']['url'];
$linkSuscripcionWebinar2 = $camposWebinar2['link_suscripcion'];
$linkVisualizacionWebinar2 = $camposWebinar2['link_visualizacion'];
$linkWebinar2 = $linkSuscripcionWebinar2 ? $linkSuscripcionWebinar2['url'] : $linkVisualizacionWebinar2['url'];

/* Webinar 3 */
$tituloWebinar3 = $camposWebinar3['titulo'];
$titulowebinarMobile3 = $camposWebinar3['titulo-mobile'];
$fechaWebinar3 = $camposWebinar3['fecha'];
$horaWebinar3 = $camposWebinar3['hora'];
$imgWebinar3 = $camposWebinar3['imagen']['url'];
$linkSuscripcionWebinar3 = $camposWebinar3['link_suscripcion'];
$linkVisualizacionWebinar3 = $camposWebinar3['link_visualizacion'];
$linkWebinar3 = $linkSuscripcionWebinar3 ? $linkSuscripcionWebinar3['url'] : $linkVisualizacionWebinar3['url'];

?>


<!-- Esta etiqueta style esta para poder poner la imagen de fondo de la seccion 1.HERO.C/Searchbar de forma dinamica-->
 <style>
    @media screen and (min-width: 767px){.hero { background: 25% top url(<?= $imagensHero;?>);background-size: cover }}
    .wpdberror{ display:none; }
    #error{ display:none; }
 </style>

<?php if (!$show_plan_estudio): ?>
    <style>
        @media screen and (min-width: 1445px){
            .courses-top-cont-grid {
                -ms-grid-columns: 1.5r 1fr;
                grid-template-columns: 1.5fr 1fr 0fr;
        }
    }
    </style>
<?php endif;?>
 
 <!----1.HERO.C/Searchbar---->

 <section id="hero" class="hero">
        <article class="hero-cont contenedor mx-auto">
            <h1 class="is-uppercase"><?= $tituloHero ?></h1>
            <h2 class="is-uppercase"><?= $subtitulosHero ?></h2>

            
            <div class="searchbar-especialidad">
                <div class="dgwt-wcas-search-wrapp dgwt-wcas-has-submit woocommerce js-dgwt-wcas-layout-classic dgwt-wcas-layout-classic js-dgwt-wcas-mobile-overlay-disabled field">
		            <form class="dgwt-wcas-search-form" role="search" action="tienda/" method="get">
		                <div class="dgwt-wcas-sf-wrapp">
						    <label class="screen-reader-text" for="dgwt-wcas-search-input-plkx">Busqueda de productos</label>

			                <input id="dgwt-wcas-search-input-plkx" type="search" class="dgwt-wcas-search-input search_input input searchbar-especialidad-campo accordion-trigger" name="q" value="" placeholder="<?= $placeholder;?>" autocomplete="off">
			                <div class="dgwt-wcas-preloader" style="right: 78.7px;"></div>

							<button type="submit" aria-label="Buscar" class="search_btn searchbar-especialidad-button dgwt-wcas-search-submit">Buscar</button>
			
					    </div>
	                </form>
                </div>
            </div>
           

        </article>
    </section>  

    <!----1.END-HERO.C/Searchbar---->
    <!----X.---->
    <!----X.---->
    <!----2.COURSES-TOP---->

    <section 
        id="courses-top-desktop<?= !$show_plan_estudio ? '-internacional' : ''?>" 
        class="courses-top courses-top-desktop <?= !$show_plan_estudio ? ' internacional  mt-2' : ''?> ">
        <div class="solapa-sup"></div>
        <article class="courses-top-cont contenedor mx-auto">
            <h3 class="courses-top-cont title">
                Tenemos más de 120 cursos avalados por prestigiosas instituciones y preparados por expertos.
                <span class="salto-de-linea">Descubrilos de acuerdo a tu profesión.</span>
            </h3>
            
            <div class="courses-top-cont-grid">
                <div class="courses-top-cont-big c-hover"
                    style="background: url(<?= $imagenTarjeta1 ?>), rgba(63, 108, 187, 1);">
                    <h4 class="courses-top-cont-big-title"><?= $tituloTarjeta1 ?></h4>
                    <a href="<?= $linkTarjeta1  ?>"  class="btn btn-big has-text-white"><?= $placeholderTarjeta1  ?></a>
                </div>

                <div class="courses-top-cont-small c-hover cursos-enfermeria"
                    style="background: url(<?= $imagenTarjeta2 ?>), rgba(0, 128, 102, 1);">
                    <h4 class="courses-top-cont-small-title"><?= $tituloTarjeta2 ?></h4>
                    <a href="<?= $linkTarjeta2  ?>"  class="btn btn-big has-text-white"><?= $placeholderTarjeta2 ?></a>
                </div>
                <?php if ($show_plan_estudio): ?>
                <div class="courses-top-cont-small c-hover plan-estudio"
                    style="background: url(<?= $imagenTarjeta3  ?>), rgba(0, 128, 102, 1);">
                    <h4 class="courses-top-cont-small-title"><?= $tituloTarjeta3 ?></h4>
                    <h5 class="courses-top-cont-small-bajada mt-3"><?= $subtituloTarjeta3 ?>
                    </h5>
                    <a href="<?= $linkTarjeta3  ?> " class="btn btn-big has-text-white"><?= $placeholderTarjeta3 ?></a>
                </div>
                <?php endif; ?>
            </div>
        </article>
    </section>

    <section id="courses-top-mobile" class="courses-top courses-top-mobile">
        <div class="solapa-sup"></div>
        <article class="courses-top-cont contenedor mx-auto">
            <h3 class="courses-top-cont title">
                Tenemos más de 120 cursos avalados por prestigiosas instituciones y preparados por expertos.
                <span class="salto-de-linea">Descubrilos de acuerdo a tu profesión.</span>
            </h3>
            <div class="courses-top-cont-grid">
                <a href="<?= $linkTarjeta1  ?>"  class="courses-top-cont-big"
                    style="background: url(<?= $imagenTarjeta1 ?>), rgba(63, 108, 187, 1);">
                    <h4 class="courses-top-cont-big-title"><?= $tituloTarjeta1 ?></h4>
                </a>

                <a href="<?= $linkTarjeta2  ?>"  class="courses-top-cont-small cursos-enfermeria"
                    style="background: url(<?= $imagenTarjeta2 ?>), rgba(0, 128, 102, 1);">
                    <h4 class="courses-top-cont-small-title"><?= $tituloTarjeta2 ?></h4>
                </a>
                <?php if ($show_plan_estudio): ?>
                <a href="<?= $linkTarjeta3 ?>" class="courses-top-cont-small plan-estudio"
                    style="background: url(<?= $imagenTarjeta3 ?>), rgba(0, 128, 102, 1);">
                    <h4 class="courses-top-cont-small-title"><?= $tituloTarjeta3 ?></h4>
                    <h5 class="courses-top-cont-small-bajada mt-3"><?= $subtituloTarjeta3 ?></h5>
                </a>
                <?php endif; ?>
            </div>
        </article>
    </section>

    <!----2.END-COURSES-TOP---->
    <!----X.---->
    <!----X.---->
    <!----3.BEST-SELLERS---->


    <section id=" best-seller" class="best-seller">
        <article class="best-seller-cont contenedor">
            <h3 class="best-seller-cont-title">Cursos más vendidos</h3>
            <div class="best-seller-cont-grid">
                <div class="swiper">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">
                    
                    <?php 

                        $args_bestSeller = array(
                            'post_type'      => 'product',
                            'posts_per_page' => -1,
                            'product_tag'    => 'bestseller'
                        );

                        
                        $array_bestSeller = get_productos($args_bestSeller);
                
                        foreach ($array_bestSeller as $product) {  ?>
                            
                            <!-- Slides -->
                            <div class="swiper-slide">
                                <div class="card c-hover">
                                    <div class="card-img"
                                        style="background: url(<?= $product->img ?>), linear-gradient(transparent 75%, #00000035 100%);">

                                        <?php
                                            foreach ($product->product_profession_array as $profesion) {  
                                                if ($profesion->name == 'medicos'): ?>
                                                    <a href="/tienda/#filter=.medicos" class="tags tags-medicina">Medicina</a>
                                                <?php elseif ($profesion->name == 'enfermeros-auxiliares'): ?>
                                                    <a href="/tienda/#filter=.enfermeros-auxiliares" class="tags tags-enfermeria">Enfermería</a>
                                                <?php endif; ?>

                                            <?php } ?>
                                    </div>
                                        
                                    <div class="card-info">
                                        <div class="card-info-sup">
                                            <p class="area"><?= $product->product_categories ?></p>
                                            
                                            <span class="horas"><i class="mdi mdi-clock-outline"></i><?= $product->duracion ?> horas</span>
                                        </div>
                                        <div class="card-info-title"><?= $product->title ?></div>
                                      
                                        <div class="card-info-footer">
                                            <div class="card-info-footer-precio">

                                            <?php if ($product->ribbon || !$product->base_old_price) : ?>
                                            <p class="cuotas"><?= get_max_installments(); ?> <?= get_installments_string(); ?></p>
                                            <p class="price">Sin interés</p>
                                             <?php else : ?>
                                                 <p class="cuotas"><?= get_max_installments(); ?> <?= get_installments_string() ?> de</p>
                                                 <p class="price" ><?= get_currency_symbol(); ?><?= $product->precio ?></p>
                                             <?php endif; ?>

                                            </div>
                                            <a href="<?= $product->link ?> " class="card-info-footer-boton btn btn-mid">Descubrir</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                    <?php  } ?>

                    </div>

                    <!-- If we need navigation buttons -->
                    <div class="swiper-button-prev"><i class="mdi mdi-chevron-left"></i></div>
                    <div class="swiper-button-next"><i class="mdi mdi-chevron-right"></i></div>

                </div>
            </div>
        </article>
    </section>

    <!----3-END.BEST-SELLERS---->
    <!----X.---->
    <!----X.---->
    <!----4.BANNER---->

    <section id="banner" class="banner">
        <article class="banner-cont contenedor">
            <div class="swiper-banner">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->

                    <?php
                        foreach ($camposBanners as $banner) {
                            $imgBanner_Small = $banner['imagen_mobile']['url'];
                            $imgBanner_Big = $banner['imagen_desktop']['url'];
                        ?>

                        <div class="swiper-slide">
                        <a href="<?= $banner['url_banner']; ?>">
                            <picture>
                                <source media="(max-width: 480px)" srcset="<?= $imgBanner_Small ?>">
                                <source media="(max-width: 640px)" srcset="<?= $imgBanner_Small ?>">
                                <source media="(max-width: 1920px)"
                                    srcset="<?= $imgBanner_Big ?>">
                                <img src="<?= $imgBanner_Big ?>" alt="">
                            </picture>
                         </a>
                        </div>

                    <?php } ?>

                </div>
                <!-- If we need pagination -->
                <div class="swiper-pagination"></div>
            </div>
        </article>
    </section>

    <!----4.END-BANNER---->
    <!----X.---->
    <!----X.---->
    <!----5.DESTACADOS---->

    <section id="destacados" class="destacados">
        <article class="destacados-cont contenedor">
            <div class="destacados-cont-top">
                <h3 class="destacados-cont-title">Cursos Destacados</h3>
                <div class="destacados-cont-top-filters">
                    <button data-filter="medicos" class="filter-button btn btn-medicina active">Medicina</button>
                    <button data-filter="enfermeros-auxiliares" class="filter-button btn btn-enfermeria">Enfermería</button>
                    <button data-filter="descargable" class="filter-button btn btn-bibliografias">Bibliografías</button>
                </div>
            </div>
            <div class="destacados-cont-grid">
                <div class="swiper">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">
                        <!-- Slides -->

                        <?php 

                        $args_destacados = array(
                            'post_type'      => 'product',
                            'posts_per_page' => -1,
                            'meta_query' => array(
                                'show_post_query' => array(
                                    'key' => 'highlighted_product',
                                    'value' => '1'
                                )
                            ),
                        );
                        $array_destacados = get_productos($args_destacados);
                
                        foreach ($array_destacados as $product): 

                            if ($product->is_downloadable ) {
                                continue;
                            }
                            if ($product->is_bibliography) {
                                $filter = "descargable";
                            }
                            else {
                                $filter = $product->product_profession;
                            }
                        
                        ?>
                           
                            <!-- Slides -->
                            <div class="swiper-slide filter <?= $filter ?>" >
                                <div class="card c-hover">
                                    <div class="card-img"
                                        style="background: url(<?= $product->img ?>), linear-gradient(transparent 75%, #00000035 100%);">

                                        <?php
                                        if($product->is_course):
                                            foreach ($product->product_profession_array as $profesion) {  
                                                if ($profesion->name == 'medicos'): ?>
                                                    <a href="/tienda/#filter=.medicos" class="tags tags-medicina">Medicina</a>
                                                <?php elseif ($profesion->name == 'enfermeros-auxiliares'): ?>
                                                    <a  href="/tienda/#filter=.enfermeros-auxiliares"  class="tags tags-enfermeria">Enfermería</a>
                                                <?php endif; 
                                            }

                                        else: ?>
                                            <a href="/tienda/#filter=.bibliography" class="tags tags-bibliografia">Bibliografía</a>
                                        <?php  
                                         endif; ?>
                                    </div>
                                        
                                    <div class="card-info">
                                        <div class="card-info-sup">
                                            

                                            <?php if ($product->is_course): ?>
                                                <p class="area"><?= $product->product_categories ?></p>
                                                <span class="horas"><i class="mdi mdi-clock-outline"></i><?= $product->duracion ?> horas</span>
                                            <?php else: ?>
                                                <span class="horas"><i class="mdi mdi-truck-fast-outline"></i>Envios a todo el país</span>
                                            <?php endif; ?>
                                            
                                        </div>
                                        <div class="card-info-title"><?= $product->title ?></div>
                                      
                                        <div class="card-info-footer">
                                            <div class="card-info-footer-precio">

                                            <?php if ($product->ribbon || !$product->base_old_price  ) : ?>
                                            <p class="cuotas"><?= get_max_installments(); ?> <?= get_installments_string(); ?></p>
                                            <p class="price">Sin interés</p>
                                             <?php else : ?>
                                                 <p class="cuotas"><?= get_max_installments(); ?> <?= get_installments_string() ?> de</p>
                                                 <p class="price" ><?= get_currency_symbol(); ?><?= $product->precio ?></p>
                                             <?php endif; ?>
                                             
                                            </div>
                                            <a href="<?= $product->link ?>" class="card-info-footer-boton btn btn-mid">Descubrir</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                    <?php endforeach; ?>

                    </div>

                    <!-- If we need navigation buttons -->
                    <div class="swiper-button-prev"><i class="mdi mdi-chevron-left"></i></div>
                    <div class="swiper-button-next"><i class="mdi mdi-chevron-right"></i></div>

                </div>
            </div>
        </article>
    </section>

    <!----5.END-DESTACADOS---->
    <!----X.---->
    <!----X.---->
    <!----6.REVIEWS---->

    <section id="reviews" class="reviews">
        <article class="reviews-cont contenedor mx-auto">
            <h3 class="reviews-cont-title">Más de 50.000 profesionales
                de toda Latinoamérica realizaron
                nuestros cursos y compartieron
                su experiencia.
                <span>¡Unite vos también a <span> nuestra
                        comunidad científica!</span></span>
            </h3>
            <div class="reviews-slider">
                <div class="swiper-reviews">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">

                    
                    <?php
                    foreach ($camposreviews as $testimonial) {
                        $nombreapellidotestimonial = $testimonial['nombre_apellido'];
                        $contenidotestimonial = $testimonial['contenido'];
                        $imagenfoto = $testimonial['foto']['url'];
                        // $testimonialprofesion = $testimonial['profesion'];
                        $redes = $testimonial['redes'];
                        $calficacion = $testimonial['calificacion'];
                        
                    ?>
                        <!-- Slides -->
                        <div class="swiper-slide">
                            <div class="card-review">
                                <div class="card-review-rating">
                                    <?php for($i = 0; $i < $calficacion; $i++) {?>
                                         <img src="<?= get_template_directory_uri().'/assets/media/icon/icon_star.svg'?>" alt="estrella de calificacion">
                                    <?php } ?>
                                </div>
                                <div class="card-review-body">
                                    <?= $contenidotestimonial  ?>
                                </div>
                                <div class="card-review-footer">
                                    <div class="card-review-footer-user">
                                        <div class="profile-picture">
                                            <img src="<?= $imagenfoto ?>" alt="<?= 'Imagen de '. $nombreapellidotestimonial  ?>">
                                        </div>
                                        <p class="review-username"><?= $nombreapellidotestimonial ?></p>
                                    </div>
                                    <?php 
                                    
                                    switch ($redes){
                                        case 'linkedin': ?>
                                            <img class="google-market" src="<?= get_template_directory_uri().'/assets/media/gogle_review.png'?>" alt="">
                                        <?php  break;
                                        case 'trustpilot': ?>
                                            <img class="google-market" src="<?= get_template_directory_uri().'/assets/media/gogle_review.png'?>" alt="">
                                        <?php  break;
                                        case 'google': ?>
                                            <img class="google-market" src="<?= get_template_directory_uri().'/assets/media/gogle_review.png'?>" alt="">
                                        <?php  break;
                                    } ?>
                                    
                                </div>
                            </div>
                        </div>


                    <?php } ?>
                        
                    </div>
                    <!-- If we need pagination -->
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </article>
    </section>

    <!----6.END-REVIEWS---->
    <!----X.---->
    <!----X.---->
    <!----7.WEBINARS---->

    <section id="webinars" class="webinars">
        <article class="webinars-cont contenedor mx-auto">
            <div class="webinars-cont-info">
                <div class="webinars-cont-info-title">
                    <i class="mdi mdi-laptop"></i>
                    <h3 class="is-uppercase">Webinars</h3>
                </div>
                <div class="webinars-cont-info-bajada">
                    <h5>Participá en vivo de las charlas gratuitas con profesionales del ámbito de la medicina y la
                        ciencia. También disfrutá las ediciones pasadas
                        en nuestro canal de YouTube.</h5>
                    <a class="button btn btn-big" target="_blank" href="https://www.youtube.com/channel/UCKtE8yeLq5jkZSbkJt3nFuA">Ver todos</a>
                </div>
            </div>
            <div class="webinars-cont-slider">
                <div class="swiper-webinars">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">
                        <!-- Slides -->

                        <div class="swiper-slide">
                            <div class="card-webinar">
                                <div class="card-webinar-img"
                                    style="background: center/cover url(<?= $imgWebinar1 ?>);"></div>
                                <div class="card-webinar-info">
                                    <div class="card-webinar-info-top">
                                        <?php if (!$linkSuscripcionWebinar1):?>
                                            <p class="fecha">TRANSMISIÓN YA EMITIDA</p>
                                        <?php else: ?>
                                            <i class="mdi mdi-clock-outline"></i>
                                            <p class="fecha"><?= $fechaWebinar1 ?></p>
                                            <p class="horas"><?= $horaWebinar1 ?></p>
                                        <?php endif;?>
                                    </div>
                                    <h4 class="card-webinar-info-title"><?= $titulowebinarMobile1 ?></h4>
                                    
                              
                                    <a href="<?= $linkWebinar1 ?>" target="_blank" class="btn"><?= $linkSuscripcionWebinar1 ? 'Quiero anotarme' : 'Ver en YouTube' ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="card-webinar">
                                <div class="card-webinar-img"
                                    style="background: center/cover url(<?= $imgWebinar2 ?>);"></div>
                                <div class="card-webinar-info">
                                    <div class="card-webinar-info-top">
                                        <?php if (!$linkSuscripcionWebinar2):?>
                                            <p class="fecha">TRANSMISIÓN YA EMITIDA</p>
                                        <?php else: ?>
                                            <i class="mdi mdi-clock-outline"></i>
                                            <p class="fecha"><?= $fechaWebinar2 ?></p>
                                            <p class="horas"><?= $horaWebinar2 ?></p>
                                        <?php endif;?>
                                    </div>
                                    <h4 class="card-webinar-info-title"><?= $titulowebinarMobile2 ?></h4>
                                    
                              
                                    <a href="<?= $linkWebinar2 ?>" target="_blank" class="btn"><?= $linkSuscripcionWebinar2 ? 'Quiero anotarme' : 'Ver en YouTube' ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="card-webinar">
                                <div class="card-webinar-img"
                                    style="background: center/cover url(<?= $imgWebinar3 ?>);"></div>
                                <div class="card-webinar-info">
                                    <div class="card-webinar-info-top">
                                        <?php if (!$linkSuscripcionWebinar3):?>
                                            <p class="fecha">TRANSMISIÓN YA EMITIDA</p>
                                        <?php else: ?>
                                            <i class="mdi mdi-clock-outline"></i>
                                            <p class="fecha"><?= $fechaWebinar3 ?></p>
                                            <p class="horas"><?= $horaWebinar3 ?></p>
                                        <?php endif;?>
                                    </div>
                                    <h4 class="card-webinar-info-title"><?= $titulowebinarMobile3 ?></h4>
                                    
                              
                                    <a href="<?= $linkWebinar3?>" target="_blank" class="btn"><?= $linkSuscripcionWebinar3 ? 'Quiero anotarme' : 'Ver en YouTube' ?></a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- If we need pagination -->
                    <div class="swiper-pagination"></div>
                </div>
                <div class="swiper-webinars-desktop">
                    <!-- Additional required wrapper -->

                    <div class="swiper-wrapper">
                        <!-- Slides -->

                        <div class="swiper-slide">
                            <div class="card-webinar">
                                <div class="card-webinar-img"
                                    style="background: center/cover url(<?= $imgWebinar1 ?>);"></div>
                                <div class="card-webinar-info">
                                    <div class="card-webinar-info-top">
                                        <?php if (!$linkSuscripcionWebinar1):?>
                                            <p class="fecha">TRANSMISIÓN YA EMITIDA</p>
                                        <?php else: ?>
                                            <i class="mdi mdi-clock-outline"></i>
                                            <p class="fecha"><?= $fechaWebinar1 ?></p>
                                            <p class="horas"><?= $horaWebinar1 ?></p>
                                        <?php endif;?>
                                    </div>
                                    <h4 class="card-webinar-info-title"><?= $tituloWebinar1 ?></h4>
                                    <a href="<?= $linkWebinar1 ?>" target="_blank" class="btn"><?= $linkSuscripcionWebinar1 ? 'Quiero anotarme' : 'Ver en YouTube' ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="card-webinar">
                                <div class="card-webinar-img"
                                    style="background: center/cover url(<?= $imgWebinar2 ?>);"></div>
                                <div class="card-webinar-info">
                                    <div class="card-webinar-info-top">
                                        <?php if (!$linkSuscripcionWebinar2):?>
                                            <p class="fecha">TRANSMISIÓN YA EMITIDA</p>
                                        <?php else: ?>
                                            <i class="mdi mdi-clock-outline"></i>
                                            <p class="fecha"><?= $fechaWebinar2 ?></p>
                                            <p class="horas"><?= $horaWebinar2 ?></p>
                                        <?php endif;?>
                                    </div>
                                    <h4 class="card-webinar-info-title"><?= $tituloWebinar2 ?></h4>
                                    <a href="<?= $linkWebinar2 ?>" target="_blank" class="btn"><?= $linkSuscripcionWebinar2 ? 'Quiero anotarme' : 'Ver en YouTube' ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="card-webinar">
                                <div class="card-webinar-img"
                                    style="background: center/cover url(<?= $imgWebinar3 ?>);"></div>
                                <div class="card-webinar-info">
                                    <div class="card-webinar-info-top">
                                        <?php if (!$linkSuscripcionWebinar3):?>
                                            <p class="fecha">TRANSMISIÓN YA EMITIDA</p>
                                        <?php else: ?>
                                            <i class="mdi mdi-clock-outline"></i>
                                            <p class="fecha"><?= $fechaWebinar3 ?></p>
                                            <p class="horas"><?= $horaWebinar3 ?></p>
                                        <?php endif;?>
                                    </div>
                                    <h4 class="card-webinar-info-title"><?= $tituloWebinar3 ?></h4>
                                    <a href="<?= $$linkWebinar3 ?>" target="_blank" class="btn"><?= $linkSuscripcionWebinar3 ? 'Quiero anotarme' : 'Ver en YouTube' ?></a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- If we need pagination -->
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </article>
    </section>

    <!----7.END-WEBINARS---->
    <!----X.---->
    <!----X.---->

    

<?php get_footer(null, [ 'type_footer' => 'full' ]); ?>

