var menu = ["12 meses", "18 meses", "24 meses"];
const swiper = new Swiper(".swiper", {
  // Optional parameters
  effect: "coverflow",
  grabCursor: true,
  centeredSlides: true,
  slidesPerView: "auto",
  initialSlide: 1,
  coverflowEffect: {
    rotate: 0,
    stretch: 0,
    depth: 10,
    modifier: 10,
    initialSlide: 3,
    slideShadows: true,
  },
  pagination: {
    el: ".swiper-pagination-clickable",
    type: "bullets",
    clickable: true,
    renderBullet: function (index, className) {
      return '<div class="' + className + '">' + menu[index] + "</div>";
    },
  },
  breakpoints: {
    992: {
      effect: "slide",
      grabCursor: false,
      allowTouchMove: false,
      slidesPerView: 3,
      spaceBetween: 16,
    },
  },
});

jQuery(document).on("mouseenter", ".swiper-slide", function () {
  jQuery(".swiper-slide").removeClass("swiper-slide-active");
  jQuery(this).addClass("swiper-slide-active");
});
