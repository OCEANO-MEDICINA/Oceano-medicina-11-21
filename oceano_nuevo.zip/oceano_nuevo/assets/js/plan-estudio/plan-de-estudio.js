function noMostrar() {
  $ = jQuery;
  $("#plan-title-1, #plan-title-2, #plan-title-3, #plan-title-4")
    .removeClass("invisible")
    .addClass("invisible");
  $("#paso-1, #paso-2, #paso-3, #paso-4")
    .removeClass("invisible")
    .addClass("invisible");
  $("#progress-1, #progress-2, #progress-3, #progress-4").removeClass("active");
  $("#progress").css("width", "0%");
}

function irAPaso(paso) {
  $ = jQuery;
  $("#plan-title-" + paso).removeClass("invisible");
  $("#paso-" + paso).removeClass("invisible");
  for (let a = 0; a < paso + 1; a++) {
    $("#progress-" + a).addClass("active");
  }

  switch (paso) {
    case 1:
      $("#progress").css("width", "0%");
      break;
    case 2:
      $("#progress").css("width", "30%");
      break;
    case 3:
      $("#progress").css("width", "60%");
      break;
    case 4:
      $("#progress").css("width", "100%");
      break;

    default:
      break;
  }
}

// Funcion de desplazamiento hasta arriba de forma animada
jQuery(document).ready(function ($) {
  $(
    ".btn-elegir_planEstudio , .btn-prev_planEstudio , .btn-next_planEstudio"
  ).on("click", function (e) {
    // 1
    e.preventDefault();
    // 2
    const href = $(this).attr("href");
    // 3
    $("html, body").animate(
      {
        scrollTop: $(href).offset().top(),
      },
      400
    );
  });
});

jQuery(document).ready(function ($) {
  var current_step = 1;

  //almacen de datos de planes
  var appData = {
    plan: 0,
    principal: {},
    secundarios: [],
  };

  //Accion de avanzar y retroceder en los pasos
  $(document).on("click", ".btn-prev_planEstudio", retrocederStep);
  $(document).on("click", ".btn-next_planEstudio", avanzarStep);

  //Accion de seleccionar el plan que quiere el cliente
  $(document).on("click", ".btn-elegir_planEstudio", seleccionarPlanEstudio);

  //Accion de seleccionar el curso principal que quiere el cliente
  $(document).on(
    "click",
    ".btn-elegir_CursoPrincipal",
    seleccionarCursoPrincipal
  );

  //Accion de seleccionar el curso secundario que quiere el cliente
  $(document).on(
    "click",
    ".btn-elegir_CursoSecundario",
    seleccionarCursoSecundario
  );

  //Accion de remover curso secundario por id
  $(document).on("click", ".borrar", function (e) {
    let id = $(this).parent(".cursoSecundario").attr("data-id");
    removerSecundarioPorID(id);
  });

  $(document).on("click", ".borrarresponsive", function (e) {
    let id = $(this).attr("data-id");
    removerSecundarioPorID(id);
  });

  $(document).on("click", ".botoncambiarcurso", function (e) {
    current_step = 2;
    actualizarSteps();
  });

  function seleccionarPlanEstudio(e) {
    appData.plan = $(this).attr("idplan");
    avanzarStep();
  }

  function seleccionarCursoPrincipal(e) {
    let titulo = $(this)
      .parents(".course")
      .find(".tituloCursoPrincipal")
      .text();
    let desc = $(this)
      .parents(".course")
      .find(".descripcionCursoPrincipal")
      .text();
    let lectura = $(this)
      .parents(".course")
      .find(".horasCursoPrincipal")
      .text();
    let imagen = $(this).parents(".course").find(".img-curso").attr("src");
    let id = $(this)
      .parents(".course")
      .find(".btn-elegir_CursoPrincipal")
      .attr("data-id");

    $("#imagenpreviewcursoprincipal").css("background-image", imagen);
    $(".titulocursoprincipal").text(titulo);

    appData.principal = {
      id: id,
      titulo: titulo,
      desc: desc,
      imagen: imagen,
      lectura: lectura,
    };

    $(".btn-elegir_CursoPrincipal").text("SELECCIONAR");
    $(".btn-elegir_CursoPrincipal").removeClass("active");
    $(this).text("SELECCIONADO").addClass("active");

    //ACA SETEO LA VISTA DEL PRINCPAL EN LA VISTA DE LOS SECUNDARIOS
    //  $(".step_planestudio_principalEnSecundarios").html(titulo);
    // avanzarStep();
  }

  function seleccionarCursoSecundario(e) {
    let titulo = $(this)
      .parents(".course_secundario")
      .find(".tituloCursoSecundario")
      .text();
    let desc = $(this)
      .parents(".course_secundario")
      .find(".descripcionCursoSecundario")
      .text();
    let imagen = $(this)
      .parents(".course_secundario")
      .find(".img-curso")
      .attr("src");
    let id = $(this).attr("data-id");
    let lectura = $(this)
      .parents(".course_secundario")
      .find(".horasCursoSecundario")
      .text();

    let curso = {
      id: id,
      titulo: titulo,
      desc: desc,
      imagen: imagen,
      lectura: lectura,
    };

    if ($(this).hasClass("active")) {
      //entonces hay que quitarlo
      removerSecundarioPorID(id);
      return;
    }

    if (appData.secundarios.length == 3) {
      scrollingElement = document.scrollingElement || document.body;
      $(scrollingElement).animate(
        {
          scrollTop: document.body.scrollHeight - $("footer").outerHeight() * 2,
        },
        2000
      );
    }

    if (appData.secundarios.length < 4) {
      $(this).text("SELECCIONADO").addClass("active");
      appData.secundarios.push(curso);
    } else {
      jQuery(document).on("click", "#close-notif", function () {
        $("#close-notif").parent().parent().css("display", "none");
      });
      $("#notification-error").css("display", "");
    }

    actualizarListadoSecundarios();
  }

  function updateProductCount() {
    setTimeout(function () {
      var articulos = jQuery(".course_secundario");
      var visibles = 0;
      articulos.each(function (index) {
        if ($(this).css("display") != "none") {
          visibles++;
        }
      });

      if (visibles == 0) {
        $("#cursos-empty").css("display", "");
      } else {
        $("#cursos-empty").css("display", "none");
      }
    }, 500);
  }

  function actualizarListadoSecundarios() {
    $(".cursoSecundario").removeClass("completo");
    $(".cursoSecundario>p").find("p").text("Sin elegir");

    var c = null;
    // $("#cursossecundariosresponsive").html("");

    for (var i = 0; i < appData.secundarios.length; i++) {
      c = appData.secundarios[i];
      if (c.id != "") {
        $(`#cursoSecundario${i + 1}`)
          .attr("data-id", c.id)
          .addClass("completo")
          .text(c.titulo)
          .append('<i class="mdi mdi-close borrar"></i>');
      }
    }

    let t = 4 - appData.secundarios.length;
    if (t == 0) {
      $(".trigger-bajada").text("");
    } else {
      $(".trigger-bajada").text(`Elegí ${t} mas`);
    }
  }

  //ProblemaXRemplazadas

  function removerSecundarioPorID(id) {
    for (var i = appData.secundarios.length - 1; i >= 0; i--) {
      if (appData.secundarios[i].id == id) {
        $();
        appData.secundarios.splice(i, 1);
      }
    }

    $(`.btn-elegir_CursoSecundario[data-id=${id}]`)
      .removeClass("active")
      .text("Seleccionar");
    $(`.cursoSecundario[data-id=${id}]`).text("Sin Elegir");
    // $(`.step_planestudio_contenedorSecundarios .step_planestudio_itemSingle [data-id=${id}]`).removeClass('botonSeleccionado');
    actualizarListadoSecundarios();
  }

  function llenarPasoFinal() {
    $("#step4_principal").html("");
    $("#step4_secundarios").html("");
    $("#step4_principal").html("<h3 class='is-uppercase'>CURSO PRINCIPAL</h3>");
    $("#step4_secundarios").html(
      "<h3 class='is-uppercase'>CURSOS SECUNDARIOS</h3>"
    );
    let modelo = $("#elbloquemodelo").html();

    let principal = $(modelo);
    principal.find("#itemlistado_titulo").html(appData.principal.titulo);
    principal.find("#itemlistado_descripcion").html(appData.principal.desc);
    principal.find("#itemlistado_lectura").html(appData.principal.lectura);
    principal.find("#itemlistado_imagen").attr("src", appData.principal.imagen);

    $("#step4_principal").append(principal);

    for (var i = 0; i < appData.secundarios.length; i++) {
      var a = appData.secundarios[i];
      var obj = $(modelo);
      obj.find("#itemlistado_titulo").html(a.titulo);
      obj.find("#itemlistado_descripcion").html(a.desc);
      obj.find("#itemlistado_lectura").html(a.lectura);
      obj.find("#itemlistado_imagen").attr("src", a.imagen);
      $("#step4_secundarios").append(obj);
    }
  }

  function actualizarSteps() {
    console.log(appData);

    noMostrar();
    irAPaso(current_step);
  }

  function avanzarStep() {
    //LOS CONTORLES
    let ret = true;
    let mensajeError = "";

    switch (current_step) {
      case 2:
        if (!appData.principal.id) {
          ret = false;
          mensajeError = "Por favor seleccione un curso principal";
        } else {
        }
        break;
      case 3:
        if (appData.secundarios.length < 4) {
          ret = false;
          mensajeError = "Por favor seleccione 4 cursos secundarios";
        } else {
          llenarPasoFinal();
        }
    }

    if (current_step < 4 && ret) {
      current_step++;
      actualizarSteps();
    } else if (current_step == 4 && ret) {
      sendPlan();
    } else {
      //ACA EL MENSAJE DE ERROR DEPENDE EL STEP
      // alert(mensajeError);
      jQuery(document).on("click", "#close-notif", function () {
        $("#close-notif").parent().parent().css("display", "none");
      });
      $("#notification-error").css("display", "");
      $("#notification-error").find("h6").text(mensajeError);
    }
  }

  function retrocederStep() {
    if (current_step > 1) {
      current_step--;
      actualizarSteps();
    }
  }

  function sendPlan(reduceStock = false) {
    //hay que mapear los secundarios

    let data = appData;
    data.secundarios = data.secundarios.map(function (el, id) {
      return el.id;
    });

    jQuery.ajax({
      type: "POST",
      url: "/wp-admin/admin-ajax.php",
      dataType: "text",
      data: {
        action: "cargar_plan_de_estudio",
        plan: data,
      },
      success: function (d) {
        //console.log('carrito vaciado');
        // alert('al carrito');
        location.href = "/carrito";
      },
      error: function (d) {
        console.log(d);
        //console.log('mmhm, no pude vaciar carrito');
      },
    });
  }

  // Filtros

  //buscador

  $(document).on("keyup", "#quicksearch", filtrador);
  $(document).on("keyup", "#quicksearch2", filtrador);

  function filtrador() {
    jQuery(".course_secundario").each(function () {
      var t = jQuery(this).find(".tituloCursoSecundario").text().toLowerCase();

      if (
        !t.includes(jQuery("#quicksearch").val().toLowerCase()) ||
        !t.includes(jQuery("#quicksearch2").val().toLowerCase())
      ) {
        jQuery(this).css("display", "none");
        jQuery(this).attr("disabled", "true");
      } else {
        jQuery(this).css("display", "");
        jQuery(this).removeAttr("disabled", "false");
      }
    });
    updateProductCount();
  }

  //Ordenamiento

  $(".sorting").on("click", ".order_button", function () {
    var sortByValue = $(this).attr("data-sortby");
    var sortValue = null;
    var sortDescAsc = null;

    switch (sortByValue) {
      case "duracionAsc":
        sortDescAsc = false;
        sortValue = "horas";
        break;

      case "duracionDes":
        sortDescAsc = true;
        sortValue = "horas";
        break;

      case "novedadAsc":
        sortDescAsc = false;
        sortValue = "novedad";
        break;

      case "novedadDes":
        sortDescAsc = true;
        sortValue = "novedad";
        break;

      default:
        break;
    }
    ordenamiento(sortValue, sortDescAsc);
  });

  function ordenamiento($value, $asc) {
    var articulos = jQuery(".course_secundario");

    var sorting = function (a, b) {
      var aName = parseInt(jQuery(a).attr(`data-${$value}`));
      var bName = parseInt(jQuery(b).attr(`data-${$value}`));

      if ($asc) {
        return aName < bName ? -1 : aName > bName ? 1 : 0;
      }

      return aName > bName ? -1 : aName < bName ? 1 : 0;
    };

    articulos.sort(sorting);

    articulos.each(function (index) {
      $(this).css("order", index);
    });
  }
});

jQuery(document).on("click", ".dropdown-item.order_button", function () {
  jQuery(".dropdown-item.order_button")
    .not(this)
    .find("i")
    .removeClass("mdi-radiobox-marked")
    .removeClass("mdi-radiobox-blank")
    .addClass("mdi-radiobox-blank");

  jQuery(this).find("i").addClass("mdi-radiobox-marked");
});

jQuery("#quicksearch2, #quicksearch").on("click", function () {
  jQuery(this).val("").trigger("keyup");
});
