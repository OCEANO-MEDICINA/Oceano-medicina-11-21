const swiper = new Swiper(".swiper", {
  // Optional parameters
  direction: "horizontal",
  loop: false,
  centeredSlides: false,

  breakpoints: {
    0: {
      slidesPerView: "auto",
      centeredSlides: true,
      spaceBetween: 12,
    },
    576: {
      slidesPerView: 3,
      spaceBetween: 13,
    },
    992: {
      slidesPerView: 4,
      spaceBetween: 16,
    },
  },
});

const swiperReviews = new Swiper(".swiper-avales", {
  effect: "slide",
  direction: "horizontal",
  loop: true,
  centeredSlides: false,

  breakpoints: {
    0: {
      slidesPerView: "auto",
      centeredSlides: true,
      spaceBetween: 12,
    },
    576: {
      slidesPerView: 3,
      spaceBetween: 13,
    },
    992: {
      slidesPerView: 4,
      spaceBetween: 16,
    },
    1500: {
      slidesPerView: 5,
      spaceBetween: 16,
    },
  },
});

const swiperDiploma = new Swiper(".swiper-diploma", {
  effect: "fade",
  slidesPerView: 1,
  centeredSlides: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});
