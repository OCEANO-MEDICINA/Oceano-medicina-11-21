all_author_displayed = false;
var compro_reciente = localStorage.getItem("compro_reciente");

jQuery("#btn-ver-mas-autores").on("click", function () {
  if (!all_author_displayed) {
    jQuery(".autor-first").css("display", "");
    jQuery(this).text("ver menos");

    all_author_displayed = true;
  } else {
    jQuery(".autor-first").css("display", "none");
    jQuery(".first-items-author").css("display", "");
    jQuery(this).text("ver más");

    all_author_displayed = false;
  }
});

jQuery(document).ready(function ($) {
  $(document).on("click", "#close-notif", function () {
    $("#close-notif").parent().parent().css("display", "none");
  });
  if (localStorage.getItem("compro_reciente") == "true") {
    $("#notification-success-compra").css("display", "");
    localStorage.setItem("compro_reciente", false);
  }
  $(document).on("click", ".displayed-add-cart", function () {
    localStorage.setItem("compro_reciente", true);
  });
});
