icl_language = php_vars_passed.icl_language;
carriten = php_vars_passed.carriten;

jQuery(document).ready(function ($) {
  wpcf7.cached = 0;
  jQuery(".bg-boton-selector a").click(function () {
    if (jQuery(this).attr("class") == "area-alumnos") {
      jQuery("#infoalumnos")
        .removeClass("form-comercial")
        .addClass("form-alumnos");
      jQuery("#infoalumnos .select-comercial").hide();
      jQuery("#infoalumnos .select-desk").removeClass("d-none").show();
    } else {
      jQuery("#infoalumnos")
        .removeClass("form-alumnos")
        .addClass("form-comercial");
      jQuery("#infoalumnos .select-desk").hide();
      jQuery("#infoalumnos .select-comercial").show();
    }
  });

  //Nos sirve para manipular el cerrar el menú
  jQuery("#mobile-menu-toggler").click(function (event) {
    event.preventDefault();
    if ($(this).hasClass("closed")) {
      $(this).removeClass("closed");
      api.open();
    }
  });

  jQuery(".ver-contenido-curso").click(function (event) {
    event.preventDefault();
    jQuery("#destacados h1").html("Contenido del curso");
    jQuery(".contenedor-curso").css({ opacity: "1", position: "relative" });
    jQuery(".contenedor-producto").css({ opacity: "0", position: "absolute" });
    /*const el = new SimpleBar(document.getElementById('test'));
        setTimeout(function(){el.recalculate()}, 500);*/
  });

  jQuery(".ver-contenido-producto").click(function (event) {
    event.preventDefault();
    jQuery("#destacados h1").html("Contenido del libro");
    jQuery(".contenedor-producto").css({ opacity: "1", position: "relative" });
    jQuery(".contenedor-curso").css({ opacity: "0", position: "absolute" });
    /*const el = new SimpleBar(document.getElementById('test'));
        setTimeout(function(){el.recalculate()}, 500);*/
  });

  //Se usa en el template del combo y de curso para inicializar la barra que permite scrollear los módulos de los productos
  /*setTimeout(function(){
        var container = document.getElementById('contenido-curso');
        if (container != null){ new SimpleBar(container, { autoHide: false });}

        container = document.getElementById('contenido-producto');
        if (container != null){ new SimpleBar(container, { autoHide: false });}

        container = document.getElementById('cards-container');
        if (container != null){ new SimpleBar(container, { autoHide: false });}
    }, 500);*/

  jQuery(".page-template-pagoshtml #tradicional").change(function () {
    var href = "https://oceanomedicina.com.ar/ecommerce/pagos/forma-de-pago/";
    jQuery(".page-template-pagoshtml .botoncom .btn").attr(
      "href",
      href + "#tradicional"
    );
  });
  jQuery(".page-template-pagoshtml #suscripcion").change(function () {
    var href = "https://oceanomedicina.com.ar/ecommerce/pagos/forma-de-pago/";
    jQuery(".page-template-pagoshtml .botoncom .btn").attr(
      "href",
      href + "#suscripcion"
    );
  });

  var hash = window.location.hash;
  if (hash == "#tradicional") {
    jQuery("#suscripage").addClass("forma-tradicional");
    jQuery("#cupon").prop("disabled", false);

    jQuery(".page-template-suscripcionhtml #credito").change(function () {
      var href =
        "https://oceanomedicina.com.ar/ecommerce/pagos/agregar-tarjeta/";
      jQuery(".page-template-suscripcionhtml .botoncom .btn").attr(
        "href",
        href + "#tradicional"
      );
    });
    jQuery(".page-template-suscripcionhtml #debito").change(function () {
      var href =
        "https://oceanomedicina.com.ar/ecommerce/pagos/agregar-tarjeta/";
      jQuery(".page-template-suscripcionhtml .botoncom .btn").attr(
        "href",
        href + "#tradicional"
      );
    });
    jQuery(".page-template-suscripcionhtml #cupon").change(function () {
      var href = "https://oceanomedicina.com.ar/ecommerce/pagos/agregar-cupon/";
      jQuery(".page-template-suscripcionhtml .botoncom .btn").attr(
        "href",
        href + "#cupon"
      );
    });

    jQuery(".page-template-agregartarjeta .botoncom .btn").attr(
      "href",
      "https://oceanomedicina.com.ar/ecommerce/pagos/plan-cuotas"
    );
  } else {
    jQuery(".page-template-suscripcionhtml #credito").change(function () {
      var href =
        "https://oceanomedicina.com.ar/ecommerce/pagos/agregar-tarjeta/";
      jQuery(".page-template-suscripcionhtml .botoncom .btn").attr(
        "href",
        href + "#suscripcion"
      );
    });
    jQuery(".page-template-suscripcionhtml #debito").change(function () {
      var href =
        "https://oceanomedicina.com.ar/ecommerce/pagos/agregar-tarjeta/";
      jQuery(".page-template-suscripcionhtml .botoncom .btn").attr(
        "href",
        href + "#suscripcion"
      );
    });

    jQuery(".page-template-agregartarjeta .botoncom .btn").attr(
      "href",
      "https://oceanomedicina.com.ar/ecommerce/pagos/plan-suscripcion"
    );
  }

  jQuery(".modal-footer button.agregarcertificacion").click(function () {
    jQuery(".variacioninternacional").addClass("purple");
    jQuery(".modal").modal("hide");
    jQuery(".agregarcertificacion").css("display", "none");
    jQuery(".eliminarcertificacion").css("display", "inline-block");
  });
  jQuery(".modal-footer button.agregarcolegio").click(function () {
    if (
      jQuery(".form-colegio input#sin-colegio").is(":checked") ||
      jQuery(".form-colegio input#sincolegio").is(":checked")
    ) {
      //Está seleccionalada la opción "Sin Colegio"
      jQuery(".variacioncolegio").removeClass("purple");
    } else {
      jQuery(".variacioncolegio").addClass("purple");
      jQuery(".agregarcolegio").css("display", "none");
      jQuery(".eliminarcolegio").css("display", "inline-block");
    }
    jQuery(".modal").modal("hide");
  });

  /*ELIMINA LA SELECCION DE LAS CERTIFICACIONES*/
  jQuery(".btn-certificacion.eliminarcertificacion").click(function () {
    jQuery(".variacioninternacional").removeClass("purple");
    jQuery(".agregarcertificacion").css("display", "inline-block");
    jQuery(".eliminarcertificacion").css("display", "none");
  });

  jQuery(".btn-certificacion.eliminarcolegio").click(function () {
    jQuery(".variacioncolegio").removeClass("purple");
    jQuery(".agregarcolegio").css("display", "inline-block");
    jQuery(".eliminarcolegio").css("display", "none");
  });

  var prodOrder = getUrlParameter("order");

  if (prodOrder) {
    $("#ordenModal .button-group .button").each(function () {
      if ($(this).data("orderurl").indexOf(prodOrder) >= 0) {
        $(this).trigger("click");
      }
    });
  }

  jQuery(".close-order-modal").click(function () {
    $("#ordenModal").hide();
  });
  jQuery(".close").click(function () {
    $(".filter-aplicados ul").empty();

    var count = 1;
    auxActiveFilters.forEach(function (filter) {
      filtersElement
        .find('*[data-filter="' + filter + '"]')
        .removeClass("is-checked");
      if (count === auxActiveFilters.length) {
        activeFilters.forEach(function (filter) {
          addFilterToList(
            filter,
            filtersElement.find('*[data-filter="' + filter + '"]')
          );
        });
      }
      count += 1;
    });
    activeFilters.forEach(function (filter) {
      addFilterToList(
        filter,
        filtersElement.find('*[data-filter="' + filter + '"]')
      );
    });
    auxActiveFilters = [];
    //Close the modal
    filtersElement.fadeOut();
    jQuery(".modal-backdrop").hide();
  });

  jQuery("#apply-filters").click(function () {
    //Hide Modal
    activeFilters = auxActiveFilters.slice(0);
    //auxActiveFilters = [];
    $grid.isotope({ filter: get_filters_string(activeFilters) });
    filtersElement.fadeOut();
    jQuery(".modal-backdrop").hide();
    setTimeout(function () {
      jQuery("span.resultados").text(
        "(" + jQuery(".tarjeta-producto:visible").length + " RESULTADOS)"
      );
    }, 500);
  });

  jQuery(".btn-filtro").click(function () {
    var target = $(this).data("target");
    if (target === "#ordenModal") {
      $("#ordenModal").fadeIn();
    } else if (target === "#myModal") {
      activeFilters.forEach(function (filter) {
        filtersElement
          .find('*[data-filter="' + filter + '"]')
          .addClass("is-checked");
        addFilterToList(
          filter,
          filtersElement.find('*[data-filter="' + filter + '"]')
        );
      });
      auxActiveFilters = activeFilters.slice(0);
      filtersElement.fadeIn();
      jQuery("span.resultados").text(
        "(" + jQuery(".tarjeta-producto:visible").length + " RESULTADOS)"
      );
    }
  });

  //Marca la primera opción de certificaciones de colegio como chequeada (esta será "sin colegio").
  jQuery("button.btn-certificacion.agregarcolegio").click(function () {
    $("input:radio[name=certificacion]:first").attr("checked", true);
  });

  //Hook to close the installments modal
  jQuery(".cerrar-cuotas").click(function () {
    /*var installments = $("input[name='cuotas']:checked").val();
        //The variable icl_language is located in the script through PHP on the functions.php file at the moment of registering the script
        var cookieName = 'installments-cookie-' + icl_language;
        setCookie(cookieName, installments, 365);
        document.location.reload(true);*/
    jQuery("#cambiarcuotas").click();
  });

  //Update installments prices when showing installments
  jQuery(".cambio-cuotas").click(function () {
    var price = jQuery(".product-price-string:not(.d-none)").text();
    price = parseFloat(price.replace(/\./g, ""));
    let maxInstallments = jQuery(".product-price-string").data("installments");
    var fullPrice = price * maxInstallments;
    console.log(price);
    console.log(maxInstallments);
    console.log(fullPrice);
    setTimeout(function () {
      update_installments_modal_prices(fullPrice);
    }, 500);
  });

  $("#pais option:first:contains('---')").html("Seleccione País*");
  $(".menu-996 option:first-child:contains('---')").html("Seleccione País*");
  $(
    "#profesion option:contains('---'), #profesion2 option:contains('---'), #profesion-temario option:contains('---')"
  ).html("Seleccione Profesión");
  $("select.especialidad option:first:contains('---')").html(
    "Seleccione Especialidad*"
  );
  $("#contact-support select.especialidad").each(function () {
    $(this)
      .find("option:first:contains('---')")
      .html("Seleccione Especialidad*");
  });
  $(".formulario-catalogo select.especialidad").each(function () {
    $(this)
      .find("option:first:contains('---')")
      .html("Seleccione Especialidad");
  });
  $("#contact-temario select.especialidad").each(function () {
    $(this)
      .find("option:first:contains('---')")
      .html("Seleccione Especialidad*");
  });
  $("#tema-consulta option:first:contains('---')").html("Tema de consulta*");

  //Obtiene filtros a clickear desde la URL
  var categories = getUrlParameter("category");
  if (categories) {
    categories = categories.split(",");
    categories.forEach(function (category) {
      var filtro = jQuery(".filters").find("[data-filter='." + category + "']");
      filtro.click();
      var current_width = jQuery(window).width();
      if (current_width < 991) {
        $("#apply-filters").click();
      }
    });
  }

  //Example of cookie: {specialty: "cirugia", profession: "medico"}
  var specialtiesCookieName = "specialty-" + icl_language;
  var specialtiesCookie = getCookie(specialtiesCookieName);

  /*Remove disabled attribute from update_cart button*/
  $("#carritopage .woocommerce-cart-form")
    .find('button[name="update_cart"]')
    .removeProp("disabled");

  /*Product information form for disabled countries functionality*/
  $("#field-course-info").val(
    "Quiero información sobre " +
      $(".detalleproducto .title").text().toUpperCase()
  );

  $("#field-course-name").val($(".detalleproducto .title").text());

  $(".dcf-close").click(function () {
    $("#dcf-submit").trigger("click");
  });

  document.addEventListener(
    "wpcf7mailsent",
    function (event) {
      if ("4945" == event.detail.contactFormId) {
        $("#disabled-country").modal("hide");
      }
    },
    false
  );

  var professionSelect = $("#profession-select");
  var specialtyModal = jQuery("#specialty-modal");

  //IF COOKIE IS NOT SET, OPEN MODAL AND THEN SET THE COOKIE EMPTY
  //if (true){
  if (!specialtiesCookie) {
    setCookie(specialtiesCookieName, "none", 30);
    //specialtyModal.modal('show');
    professionSelect.on("change", function () {
      $("label.specialty-select").addClass("d-none");
      $("label." + this.value).removeClass("d-none");
    });
  }

  $(".specialties-close").on("click", function () {
    console.log("trying to set specialty cookie with values");
    var selectedProfession = $("#profession-select option:selected").val();
    var selectedSpecialty = $(
      "label.specialty-select." + selectedProfession + " option:selected"
    ).val();
    console.log(selectedProfession);
    console.log(selectedSpecialty);
    specialtiesCookie = {
      profession: selectedProfession,
      specialty: selectedSpecialty,
    };
    setCookie(specialtiesCookieName, JSON.stringify(specialtiesCookie), 30);
    document.location.reload(true);
  });

  /*Remove product from cart*/
  $("#masthead").on("click", ".cart .eliminar", function (e) {
    e.preventDefault();
    var productID = $(this).data("product_id");
    $.ajax({
      type: "POST",
      url: inudev_ajax_object.ajax_url,
      data: { action: "remove_item_from_cart", product_id: productID },
      success: function (res) {
        if (res !== "false") {
          $("#masthead .cart").replaceWith(res);
          $(".cart-popup").show();
        }
      },
    });
  });

  //Show coupon error on cart page
  // $("body.woocommerce-cart .woocommerce-notices-wrapper ul").parent().show();

  //Temporary adding curse parameter to menu items
  /*$("#menu-item-714 .dropdown-menu .dropdown-item").each(function(key, val){
        if (key === 0) {
            //return true;
        }
        var currentURL = $(this).attr('href');
        $(this).attr("href", currentURL + ',curso');
    });*/

  /*BOTON COMPRAR STICKY MOBILE*/
  $(window).on("resize", function (e) {
    checkScreenSize();
  });

  checkScreenSize();

  function checkScreenSize() {
    var newWindowWidth = $(window).width();

    var lastScrollTop = 0;
    $(window).on("touchmove scroll", function (e) {
      if (newWindowWidth < 481) {
        let addCartContainer = $("#displayed-add-cart-container, .descripcion");
        if (addCartContainer) {
          if (typeof addCartContainer.offset() !== "undefined") {
            var hT = addCartContainer.offset().top,
              hH = addCartContainer.outerHeight(),
              wH = $(window).height(),
              wS = $(window).scrollTop();

            var st = $(this).scrollTop();
            if (st > lastScrollTop) {
              var scrollOffset = 10;
            } else {
              var scrollOffset = 50;
            }
            lastScrollTop = st;
            if (wS > hT + hH - wH + scrollOffset) {
              $(".displayed-add-cart").css({
                position: "fixed",
                bottom: "0px",
                right: "0",
                left: "0",
                "z-index": "2",
              });
              $(".btn-catalogo").css({
                position: "fixed",
                bottom: "0px",
                right: "0",
                left: "0",
                "z-index": "2",
                display: "block",
              });
            } else {
              $(".displayed-add-cart").css({ position: "static" });
              $(".btn-catalogo").css({ display: "none" });
            }
          }
        }
      } else {
        $(".displayed-add-cart").css({ position: "static" });
        $(".btn-catalogo").css({ display: "none" });
      }
    });
  }

  var choosenProfession = getCookie("profession_selector");
  //console.log(choosenProfession);
  if (choosenProfession) {
    $("#" + choosenProfession).click();
  }

  /*ORDER FILTERS*/
  $(".sort-items .sort-dropdown a").on("click", function (e) {
    e.preventDefault();
    var filterRedirect = $(this).attr("href");
    var filters = $(".filter-aplicados").find(".button");
    filters.each(function () {
      if (filterRedirect.indexOf("category") >= 0) {
        filterRedirect =
          filterRedirect + "," + $(this).data("filter").replace(".", "");
      } else {
        filterRedirect =
          filterRedirect +
          "&category=" +
          $(this).data("filter").replace(".", "");
      }
    });
    document.location = filterRedirect;
  });

  /*LIST/CARDs views*/
  $(".tienda-headnav i.material-icons").on("click", function (e) {
    $(".tienda-headnav i.material-icons").removeClass("active");
    $(this).addClass("active");
    if ($(this).text() === "list") {
      $('.tienda-headnav i.material-icons:contains("list")').addClass("active");
      $(".filter-course").addClass("vista-lista");
      setCookie("products_view", "list", 365);
    } else {
      $('.tienda-headnav i.material-icons:contains("border_all")').addClass(
        "active"
      );
      $(".filter-course").removeClass("vista-lista");
      setCookie("products_view", "card", 365);
      //Reset Isotope grid to rearrange items
      if (typeof $grid.isotope === "function") {
        $grid.isotope({ itemSelector: ".tarjeta-producto" });
      }
    }
  });

  var productsView = getCookie("products_view");
  if (productsView === "list") {
    $('.tienda-headnav i.material-icons:contains("list")').trigger("click");
    //Reset Isotope grid to rearrange item container height
    if (typeof $grid.isotope === "function") {
      $grid.isotope({ itemSelector: ".tarjeta-producto" });
    }
  } else {
    $('.tienda-headnav i.material-icons:contains("border_all")').trigger(
      "click"
    );
  }

  var fbContactEventSent = false;
  jQuery(".chat-icon").on("click", function () {
    jQuery(".zsiq_floatmain").click();
    if (!fbContactEventSent && typeof fbq !== "undefined") {
      fbContactEventSent = true;
      //console.log('Send contact event to FB');
      console.log("fb q: 3");
      fbq("track", "Contact");
    }
  });

  /*UTM parameters*/
  var utm_source = getUrlParameter("utm_source");
  var utm_medium = getUrlParameter("utm_medium");
  var utm_campaign = getUrlParameter("utm_campaign");
  var utm_content = getUrlParameter("utm_content");
  var gclid = getUrlParameter("gclid");
  var dclid = getUrlParameter("dclid");

  //por si quieren pisar lead
  var lead_id = getUrlParameter("lead_id");

  if (lead_id) setCookie("lead_id", lead_id, 0);

  if (utm_source)
    setCookie(
      "utm_source",
      utm_source.replace(/%/g, "%25").replace(/\+/g, "%20"),
      365
    );
  if (utm_medium)
    setCookie(
      "utm_medium",
      utm_medium.replace(/%/g, "%25").replace(/\+/g, "%20"),
      365
    );
  if (utm_campaign)
    setCookie(
      "utm_campaign",
      utm_campaign.replace(/%/g, "%25").replace(/\+/g, "%20"),
      365
    );
  if (utm_content)
    setCookie(
      "utm_content",
      utm_content.replace(/%/g, "%25").replace(/\+/g, "%20"),
      365
    );

  if (gclid) setCookie("gclid", gclid, 365);
  else if (dclid) setCookie("gclid", dclid, 365);

  if (gclid) {
    //mata todo utm
    setCookie("utm_source", "Ads", 365);
    setCookie("utm_medium", "ecommerce", 365);
    setCookie("utm_campaign", "pago", 365);
    setCookie("utm_content", "search", 365);
  }

  if (dclid) {
    //mata todo utm menos campaign
    setCookie("utm_source", "Ads", 365);
    setCookie("utm_medium", "ecommerce", 365);
    //setCookie('utm_campaign', '', -1);
    setCookie("utm_content", "display", 365);
  }

  if (utm_source || utm_medium || utm_campaign || utm_content) {
    if (dclid == undefined)
      //si vino sin dclid... borra lo que haya
      setCookie("gclid", "", -1);
  }

  /*Contact support form: populate post title*/
  $('#contact-support input[name = "post-title"]').val(
    $("#contact-support").data("post-title")
  );
  $('.formulario-catalogo input[name = "post-title"]').val(
    $(".formulario-catalogo").data("post-title")
  );
  $('#contact-temario input[name = "post-title"]').val(
    $("#contact-temario").data("post-title")
  );
  /*Contact support form: populate speciality*/
  $("#contact-support .especialidad").change(function () {
    var value = $(this).val();
    $('#contact-support input[name = "especialidad"]').val(value);
  });
  $(".formulario-catalogo .especialidad").change(function () {
    var value = $(this).val();
    $('.formulario-catalogo input[name = "especialidad"]').val(value);
  });
  $("#contact-temario .especialidad").change(function () {
    var value = $(this).val();
    $('#contact-temario input[name = "especialidad"]').val(value);
  });
  $(
    '#contact-temario input[name = "utm_source"], #contact-support input[name = "utm_source"], .formulario-catalogo input[name = "utm_source"], #informacion-general input[name = "utm_source"], .selector-formulario.select-comercial input[name = "utm_source"]'
  ).val(getCookie("utm_source"));
  $(
    '#contact-temario input[name = "utm_medium"], #contact-support input[name = "utm_medium"], .formulario-catalogo input[name = "utm_medium"], #informacion-general input[name = "utm_medium"], .selector-formulario.select-comercial input[name = "utm_medium"]'
  ).val(getCookie("utm_medium"));
  $(
    '#contact-temario input[name = "utm_campaign"],#contact-support input[name = "utm_campaign"], .formulario-catalogo input[name = "utm_campaign"], #informacion-general input[name = "utm_campaign"], .selector-formulario.select-comercial input[name = "utm_campaign"]'
  ).val(getCookie("utm_campaign"));
  $(
    '#contact-temario input[name = "utm_content"], #contact-support input[name = "utm_content"], .formulario-catalogo input[name = "utm_content"], #informacion-general input[name = "utm_content"], .selector-formulario.select-comercial input[name = "utm_content"]'
  ).val(getCookie("utm_content"));
  $(
    '#contact-temario input[name = "gclid"], #contact-support input[name = "gclid"], .formulario-catalogo input[name = "gclid"], #informacion-general input[name = "gclid"], .selector-formulario.select-comercial input[name = "gclid"]'
  ).val(getCookie("gclid"));
  $(
    '#contact-temario input[name = "lead_id"], #contact-support input[name = "lead_id"], .formulario-catalogo input[name = "lead_id"], #informacion-general input[name = "lead_id"], .selector-formulario.select-comercial input[name = "lead_id"]'
  ).val(getCookie("lead_id"));
  $(
    '#contact-temario input[name = "url_origen"], #contact-support input[name = "url_origen"], .formulario-catalogo input[name = "url_origen"], #informacion-general input[name = "url_origen"], .selector-formulario.select-comercial input[name = "url_origen"]'
  ).val(window.location.href);

  //$('.formulario-catalogo input[name = "int-tel-cf7it-country-name"]').val($form_country);

  $(".formulario-catalogo .wpcf7-submit").click(function () {
    if ($(".selected-flag").attr("title") == "Unknown") {
      event.preventDefault();
      event.stopPropagation();
      alert("Seleccione código de país del teléfono");
    }
  });

  let formTemario = $(".formulario-temario");
  if (formTemario) {
    var temario = formTemario.parent().data("temario");
    // console.log(temario);
    $("<input>")
      .attr({
        type: "hidden",
        id: "foo",
        name: "temario-url",
        value: temario,
      })
      .appendTo(formTemario.find("form"));
  }

  /*Descargar temario del curso despues del formulario*/
  document.addEventListener(
    "wpcf7mailsent",
    function (event) {
      let formId = event.detail.contactFormId;
      console.log(formId);
      formId = formId.toString();
      console.log(event.detail.inputs);

      if (formId == "98696") {
        //Temario Form Nuevo Diseño
        setTimeout(function () {
          console.log("close temario modal");
          jQuery("#contact-temario").click();
        }, 4000);
        event.detail.inputs.forEach(function (arrayItem) {
          if (arrayItem.name == "opcion-descarga[]") {
            if (arrayItem.value == "Descargar ahora") {
              window.location.href = $("#contact-temario").data("temario");
              if (formId != "98696") {
                setTimeout(function () {
                  window.location.href =
                    "https://" + window.location.hostname + "/gracias";
                }, 3000);
              }
            }
          }
        });
      }

      let temariosForms = [
        "75045",
        "75046",
        "75047",
        "75048",
        "75049",
        "75050",
        "75051",
        "75053",
        "75054",
        "75052",
        "75060",
        "75055",
        "75056",
        "75057",
        "75058",
        "75059",
        "75061",
      ];
      if ($.inArray(formId, temariosForms) !== -1) {
        window.location.href = $("#contact-temario").data("temario");
        if (formId !== "98696") {
          setTimeout(function () {
            window.location.href =
              "https://" + window.location.hostname + "/gracias";
          }, 3000);
        }
      }

      //It's a downloadable Ebook form submission
      let EbooksDescargablesForms = [
        "83281",
        "84355",
        "84356",
        "84358",
        "84359",
        "84360",
        "84361",
        "84362",
        "84363",
        "84364",
        "84365",
        "84366",
        "84367",
        "84368",
        "84369",
      ];
      if ($.inArray(formId, EbooksDescargablesForms) !== -1) {
        window.location.href = $("#form-ebook").data("ebook");
        setTimeout(function () {
          window.location.href =
            "https://" +
            window.location.hostname +
            "/gracias?origin=downloadable";
        }, 3000);
      }
    },
    false
  );

  /*Carrousel de avales*/
  $(".collapse-avales").click(function () {
    $("#owl-auspiciantes.slick-slider").slick("setPosition");
    $("#collapse-auspiciantes").toggleClass("accordion-active");
    $(this).toggleClass("collapse-active");
  });
  $(".collapse-description").click(function () {
    $(this).toggleClass("collapse-active");
  });

  $(".collapse-level").click(function () {
    $("#collapse-level").toggleClass("accordion-active");
    $(this).toggleClass("collapse-active");
  });

  $("#modulos-skills .header").click(function () {
    $(this).toggleClass("open-info");
  });

  $(".show-more-modules").click(function (e) {
    e.preventDefault();
    $(this).find("img").toggleClass("show-more-active");
  });

  $("#show-more").on("show.bs.collapse", function () {
    $(".show-more-modules span").fadeOut(400, function () {
      $(this).text("ver menos").fadeIn(400);
    });
  });
  $("#show-more").on("hide.bs.collapse", function () {
    $(".show-more-modules span").fadeOut(400, function () {
      $(this).text("ver más").fadeIn(400);
    });
  });

  /*Close collapsed section on mobile*/
  var width = $(window).width();

  if (width <= 425) {
    $("#collapse-auspiciantes").removeClass("accordion-active");
    $(".auspiciantes img.collapse-avales").removeClass("collapse-active");
    $("#collapse-description").removeClass("show");
    $(".descripcion img.collapse-description").removeClass("collapse-active");
    $("#collapse-level").removeClass("accordion-active");
    $(".nivel img.collapse-level").removeClass("collapse-active");
  }

  $(window).on("resize", function () {
    var width = $(window).width();
    if (width <= 425) {
      $("#collapse-auspiciantes").removeClass("accordion-active");
      $(".auspiciantes img.collapse-avales").removeClass("collapse-active");
      $("#collapse-description").removeClass("show");
      $(".descripcion img.collapse-description").removeClass("collapse-active");
      $("#collapse-level").removeClass("accordion-active");
      $(".nivel img.collapse-level").removeClass("collapse-active");
    } else {
      $("#collapse-auspiciantes").addClass("accordion-active");
      $(".auspiciantes img.collapse-avales").addClass("collapse-active");
      $("#collapse-description").addClass("show");
      $(".descripcion img.collapse-description").addClass("collapse-active");
      $("#collapse-level").addClass("accordion-active");
      $(".nivel img.collapse-level").addClass("collapse-active");
    }
  });

  //Open and scroll to the FAQ from the URL
  if ($("body").hasClass("page-template-preguntas-frecuentes")) {
    let hash = window.location.hash;
    let collapsable = $('a[href="' + hash + '"]');
    if (collapsable.length) {
      collapsable.click();
      $([document.documentElement, document.body]).animate(
        {
          scrollTop: collapsable.offset().top - 50,
        },
        1000
      );
    }
  }

  /*Autopopulate telephone country input*/
  switch (icl_language) {
    case "arg":
      var form_country = "ar";
      break;
    case "bo":
      var form_country = "bo";
      break;
    case "cl":
      var form_country = "cl";
      break;
    case "co":
      var form_country = "co";
      break;
    case "cr":
      var form_country = "cr";
      break; //costa rica
    case "ec":
      var form_country = "ec";
      break; //ecuador
    case "es":
      var form_country = "es";
      break; //españa
    case "sal":
      var form_country = "sv";
      break; //el salvador
    case "gt":
      var form_country = "gt";
      break;
    case "hn":
      var form_country = "hn";
      break;
    case "mx":
      var form_country = "mx";
      break;
    case "ni":
      var form_country = "ni";
      break; //nicaragua
    case "pnm":
      var form_country = "pa";
      break; //panama
    case "py":
      var form_country = "py";
      break;
    case "pe":
      var form_country = "pe";
      break;
    case "uy":
      var form_country = "uy";
      break;
  }

  /*setInterval(function(){
        if($('.selected-flag').attr("title") == 'Unknown'){
            $(".selected-flag").trigger("click");
            $(".intl-tel-input .country[data-country-code='"+ form_country +"']").trigger("click");
            setTimeout(function(){
                $("body").trigger("click");
            }, 500);
        }
    }, 500);*/

  // Prevent multiple submissions with Contact Form 7
  $(document).on("click", ".wpcf7-submit", function (e) {
    if ($(this).siblings(".ajax-loader").hasClass("is-active")) {
      e.preventDefault();
      return false;
    }
  });
});

function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
}

function setCookie(cname, cvalue, exdays) {
  if (exdays != 0) {
    var d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  } else {
    document.cookie = cname + "=" + cvalue + ";";
  }
}

function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(";");
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function update_installments_modal_prices(fullPrice) {
  let installments = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  installments.forEach(function (element) {
    let price = parseFloat((fullPrice / element).toFixed(2).replace(".", ","));
    price = formatNumber(price);
    jQuery(".cuota-" + element + " .price-cuota").text("$" + price);
  });
}

document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();
    var elementToScrollSelector = this.getAttribute("href");
    if (elementToScrollSelector !== "#") {
      document
        .querySelector(elementToScrollSelector)
        .scrollIntoView({ behavior: "smooth" });
    }
  });
});

/*Cambia las cantidades de los productos a ser agregados al carrito*/
jQuery("#product-amount .resta").click(function () {
  var amount = parseInt(jQuery("#product-amount .amount").text());
  var addCartURL = new URL(jQuery("#add-cart-quantity").attr("href"));

  if (amount > 1) {
    amount = amount - 1;
    addCartURL.searchParams.set("quantity", amount);
    jQuery("#add-cart-quantity").attr("href", addCartURL.toString());
    jQuery("#product-amount .amount").text(amount);
  }
});

jQuery("#product-amount .suma").click(function () {
  var amount = parseInt(jQuery("#product-amount .amount").text());
  var addCartURL = new URL(jQuery("#add-cart-quantity").attr("href"));

  amount = amount + 1;
  addCartURL.searchParams.set("quantity", amount);
  jQuery("#add-cart-quantity").attr("href", addCartURL.toString());
  jQuery("#product-amount .amount").text(amount);
});
/* Select certificate variation */

//Se llama cada vez que se agrega o quita una certificación a un producto, sirve para actualizar el precio que se muestra al usuario
//Se agrego la misma funcionalidad para el precio sin descuento en caso de que el producto tenga uno
function update_variable_product_price() {
  "use strict";
  let selectedNac = jQuery("select#pa_certificacion-local").val();
  let nacCertEnabled = selectedNac
    ? !selectedNac.startsWith("sin-colegio")
    : false;
  let selectedInt = jQuery("select#pa_certificacion-internacional").val();
  let intCertEnabled = selectedInt
    ? !selectedInt.startsWith("sin-universidad")
    : false;
  jQuery(".variable-price").addClass("d-none");
  jQuery(".descuento-price").addClass("d-none");
  switch (true) {
    case !nacCertEnabled && !intCertEnabled:
      //Show base price
      jQuery(".variable-price.base").removeClass("d-none");
      jQuery(".descuento-price.base").removeClass("d-none");
      break;
    case nacCertEnabled && !intCertEnabled:
      //Show price for just nacional certification
      jQuery(".variable-price.nac").removeClass("d-none");
      jQuery(".descuento-price.nac").removeClass("d-none");
      break;
    case !nacCertEnabled && intCertEnabled:
      //Show price for just Internacional certification
      jQuery(".variable-price.int").removeClass("d-none");
      jQuery(".descuento-price.int").removeClass("d-none");
      break;
    case nacCertEnabled && intCertEnabled:
      //Show price for both certifications
      jQuery(".variable-price.nac-int").removeClass("d-none");
      jQuery(".descuento-price.nac-int").removeClass("d-none");
      break;
  }
}

//Add international certification
jQuery(".agregar-cert-int").on("click", function (event) {
  jQuery("#field-int-cert").val("Agregó certificado internacional");
  jQuery("#pa_certificacion-internacional option:last").prop("selected", true);
  update_variable_product_price();
});

//Remove international certification
jQuery(".eliminarcertificacion").on("click", function (event) {
  jQuery("#field-int-cert").val("No agregó certificado internacional");
  jQuery(
    '#pa_certificacion-internacional option[value*="sin-universidad"]'
  ).prop("selected", true);
  update_variable_product_price();
});

//Add local certification
jQuery("#add-colegio").on("click", function (event) {
  "use strict";
  let collegeID = jQuery(
    ".form-colegio input[name=certificacion]:checked"
  ).attr("id");
  jQuery("#field-nat-cert").val("Agregó certificado nacional");
  jQuery('#pa_certificacion-local option[value*="' + collegeID + '"]').prop(
    "selected",
    true
  );
  update_variable_product_price();
});

//Remove local certification
jQuery(".eliminarcolegio").on("click", function (event) {
  jQuery("#field-nat-cert").val("No agregó certificado nacional");
  jQuery("#sin-colegio").prop("checked", true);
  jQuery('#pa_certificacion-local option[value*="sin-colegio"]').prop(
    "selected",
    true
  );
  update_variable_product_price();
});

//Add to cart clicked
jQuery(".displayed-add-cart").on("click", function (event) {
  console.log("clicked add to cart");
  if (!jQuery(this).data("target")) {
    jQuery(".single_add_to_cart_button").trigger("click");
  }
});

//Display full description on product page
jQuery("#view-more").on("click", function (event) {
  jQuery(this).hide();
  jQuery("#view-less").show();
  jQuery(".full-description").slideDown();
});

jQuery("#view-less").on("click", function (event) {
  jQuery(this).hide();
  jQuery("#view-more").show();
  jQuery(".full-description").slideUp();
});

jQuery(
  "select#pa_certificacion-local, select#pa_certificacion-internacional"
).on("input", function (event) {
  update_variable_product_price();
});

//Add local certification COMBO
jQuery(".agregarcolegiocombo").on("click", function (event) {
  "use strict";
  let collegeID = jQuery(
    ".form-colegio input[name=certificacion]:checked"
  ).attr("id");
  let points = jQuery(".form-colegio input[name=certificacion]:checked")
    .siblings(".puntos")
    .text();
  jQuery('#pa_certificacion-local option[value="' + collegeID + '"]').prop(
    "selected",
    true
  );
  jQuery(".datos-producto .completar-puntaje").text(points);
  jQuery(".modal").modal("hide");
});

/*Mini cart show on hover*/

jQuery("#masthead").on("mouseenter", ".cart", function () {
  clearTimeout(jQuery(this).data("timeoutId"));
  jQuery(this).children(".dropdown-menu-mini-cart").removeClass("hidden");
  jQuery(".cart-popup").show();
});
jQuery("#masthead").on("mouseleave", ".cart", function () {
  var someElement = jQuery(this),
    timeoutId = setTimeout(function () {
      someElement.children(".dropdown-menu-mini-cart").addClass("hidden");
      jQuery(".cart-popup").hide();
    }, 650);
  //set the timeoutId, allowing us to clear this trigger if the mouse comes back over
  someElement.data("timeoutId", timeoutId);
});

function getUrlParameter(sParam) {
  var sPageURL = window.location.search.substring(1),
    sURLVariables = sPageURL.split("&"),
    sParameterName,
    i;

  for (i = 0; i < sURLVariables.length; i++) {
    sParameterName = sURLVariables[i].split("=");

    if (sParameterName[0] === sParam) {
      return sParameterName[1] === undefined
        ? true
        : decodeURIComponent(sParameterName[1]);
    }
  }
}

//Add international certification course on cart suggestion
jQuery("#cart-int-add-to-cart").on("click", function (e) {
  var nacCert = jQuery(this).data("nacslug");
  var intCert = jQuery(this).data("intslug");
  var productId = jQuery(this).data("product-id");
  var quantity = 1;
  jQuery.ajax({
    url: inudev_ajax_object.ajax_url,
    type: "POST",
    data:
      "action=inudev_add_cart_single&product_id=" +
      productId +
      "&quantity=" +
      quantity +
      "&attLocal=" +
      nacCert +
      "&attInter=" +
      intCert,
    success: function (results) {
      location.reload();
    },
  });
  e.preventDefault();
});

//Country switcher logic
jQuery("select.selector-pais").on("change", function () {
  var optionSelected = jQuery("option:selected", this);
  var url = optionSelected.attr("data-url"); // get selected value
  var cartcount = jQuery(".icon-carrito-count").text();
  if (cartcount !== "") {
    jQuery.ajax({
      type: "POST",
      url: carriten.carritourl,
      dataType: "json",
      data: {
        action: "hookvaciarcarrito",
      },
      success: function (d) {
        if (url) {
          // require a URL
          window.location = url; // redirect
        }
      },
      error: function (d) {},
    });
  } else {
    if (url) {
      // require a URL
      window.location = url; // redirect
    }
  }
  return false;
});

jQuery(".chat-icon").on("click", function () {
  jQuery(".zsiq_floatmain").click();
});

//Installments switcher logic
jQuery("select#installmentsSelect").on("change", function () {
  var optionSelected = jQuery("option:selected", this).val();
  var cookieName = "installments-cookie-" + icl_language;
  setCookie(cookieName, optionSelected, 365);
  document.location.reload(true);
});

jQuery(".professions-menu-wrp li").click(function (e) {
  e.preventDefault();
  e.stopPropagation();
  jQuery(".professions-menu-wrp li.active").removeClass("active");
  jQuery(this).addClass("active");

  //Add selected profession to URLs
  var profesion = jQuery(this).data("profesion");
  console.log(profesion);
  //In order for this to work the Especialidades LI should have the especialidades-menu class
  jQuery(".especialidades-menu .dropdown-menu .dropdown-item").each(function (
    key,
    val
  ) {
    var currentURL = jQuery(this).attr("href");
    currentURL = currentURL.split(",")[0];
    jQuery(this).attr("href", currentURL + ",curso," + profesion);
  });
});
