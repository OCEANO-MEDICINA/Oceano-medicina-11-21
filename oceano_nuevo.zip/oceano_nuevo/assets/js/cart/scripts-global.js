jQuery(document).ready(function ($) {
  //console.log('global scripts loaded');

  //IP Location Ajax Redirect
  jQuery.ajax({
    url: "/wp-json/oceanoAPI/get-redirect-url/",
    type: "POST",
    data: {
      url: window.location.href,
      domain: window.location.hostname,
    },
    complete: function (results) {
      let response = results.responseJSON;
      //console.log(response);
      if (response.success) {
        if (window.location.hostname !== "oceanomedicina.tech") {
          window.location.replace(response.data.url);
        }
      }
    },
  });

  //Reload ajax minicart on pageload to bypass cache
  //setTimeout(function () {

  jQuery.ajax({
    url: "/wp-json/oceanoAPI/reload-cart/",
    type: "GET",
    complete: function (results) {
      //console.log(results.responseText);
      jQuery("#masthead .cart").replaceWith(results.responseText);
    },
  });
  //}, 1000);
});
