/* <![CDATA[ */

var inudev_ajax_object = {
  ajax_url: php_vars_passed.carriten,
};
/* ]]&gt; */

jQuery(document).ready(function ($) {
  // var articulos = jQuery(".carrito-card-price");
  // // onHashchange();
  // articulos.each(function () {
  //   var text_articulo = $(this).text();
  //   var num = text_articulo.match(/[\d\.]+/g);
  //   var sum = sum + num;
  // });

  $(document).on("click", "#close-notif", function () {
    $("#close-notif").parent().parent().css("display", "none");
  });

  // if (num != null) {
  //   var number = num.toString();
  //   alert(number);
  // }

  // jQuery(document).ready(function ($) {
  //   var valor_compra_original = localStorage.getItem("valor_compra_original");
  //   if (valor_compra_original < parseInt($("#precio-total").text())) {
  //     localStorage.setItem(
  //       "valor_compra_original",
  //       parseInt($("#precio-total").text())
  //     );
  //     console.log(localStorage.getItem("valor_compra_original"));
  //   }
  // });

  //   $(".notification").css("display", "none");

  // $("#installmentsSelect").picker({
  //   containerClass: "pickercuotas",
  // });
  // $(".verplandeestudios").click(function () {
  //   $(".verplanhidden").toggle("slow", function () {
  //     // Animation complete.
  //   });
  // });

  // $("ul .woocommerce-error").picker({
  //   containerClass: "pickercuotas",
  // });
  // jQuery(".pc-list li").removeClass("selected");
  // let a = jQuery("#installmentsSelect option[selected]").attr("value");
  // jQuery(`li[data-id=${a}]`).addClass("selected");
  // jQuery("#installmentsSelect").on("sp-change", function () {
  //   $("#installmentsSelect").trigger("change");
  // });
  $(document).on("click", ".botonduplicado", function () {
    eliminar_duplicados();
  });
});

jQuery(document).on("click", "#vaciar_cupones", function (e) {
  event.preventDefault();
  vaciar_cupones();
  return false;
});
jQuery(document).on("click", "#eliminar-plan", function () {
  emptyCart();
});

function eliminar_duplicados(reduceStock = false) {
  jQuery.ajax({
    type: "POST",
    url: "/wp-admin/admin-ajax.php",
    dataType: "text",
    data: {
      action: "eliminar_duplicados",
    },
    success: function (d) {
      //console.log('carrito vaciado');
      location.reload();
    },
    error: function (d) {
      console.log(d);
      //console.log('mmhm, no pude vaciar carrito');
    },
  });
}

function emptyCart(reduceStock = false) {
  jQuery.ajax({
    type: "POST",
    url: php_vars_passed.carriten,
    dataType: "text",
    data: {
      action: "hookvaciarcarrito",
      reduce_stock: reduceStock,
    },
    success: function (d) {
      console.log("carrito vaciado");
      location.reload();
    },
    error: function (d) {
      console.log("mmhm, no pude vaciar carrito");
      location.reload();
    },
  });
}

function vaciar_cupones(reduceStock = false) {
  jQuery.ajax({
    type: "POST",
    url: php_vars_passed.carriten,
    dataType: "text",
    data: {
      action: "eliminarcupones",
      reduce_stock: reduceStock,
    },
    success: function (d) {
      console.log("cupones vaciado");
      // location.reload();
    },
    error: function (d) {
      console.log("mmhm, no pude vaciar cupones ");
      // location.reload();
    },
  });
}
