/*ADD TO CART AJAX*/
jQuery(
  ".single_add_to_cart_button, #recommended-to-cart, #add-cart-quantity"
).click(function (e) {
  e.preventDefault();

  if (jQuery(e.target).is("#recommended-to-cart")) {
    var IDs = [];
    jQuery('input[name="recommended"]:checked').each(function () {
      var recoID = jQuery(this).attr("data-postid");
      if (jQuery.inArray(recoID, IDs) === -1) {
        IDs.push(jQuery(this).attr("data-postid"));
      }
    });
    var parameters = "";
    var total = IDs.length;

    jQuery.each(IDs, function (index, id) {
      parameters =
        index === total - 1 ? parameters + id : parameters + id + ",";
    });
  }

  jQuery(this).addClass("adding-cart");
  var product_id = jQuery('input[name="product_id"]').val();
  //product_id = (product_id === undefined) ? jQuery('#requisitos').data('postid') : product_id;
  product_id =
    product_id === undefined
      ? jQuery("#add-cart-quantity").data("postid")
      : product_id;
  product_id =
    product_id === undefined
      ? jQuery('button[name ="add-to-cart"]').val()
      : product_id;
  var variation_id = jQuery('input[name="variation_id"]').val();
  var quantity = jQuery('input[name="quantity"]').val();
  quantity = quantity === undefined ? jQuery("#amount").text() : quantity;
  var attLocal = jQuery("#pa_certificacion-local").val();
  var attInter = jQuery("#pa_certificacion-internacional").val();

  //if mandatory int cert enabled then find the int cert.
  if (jQuery(".variacioninternacional.mandatory").length) {
    //console.log('is mandatory int cert');
    attInter = jQuery(
      "#pa_certificacion-internacional option:last-child"
    ).val();
    //console.log(attInter);
  } else {
    //console.log("Not mandatory");
  }

  jQuery(".cart-dropdown-inner").empty();

  if (variation_id !== "" && variation_id !== undefined) {
    var test =
      "action=inudev_add_cart_single&product_id=" +
      product_id +
      "&quantity=" +
      quantity +
      "&attLocal=" +
      attLocal +
      "&attInter=" +
      attInter +
      "&relatedProducts=" +
      parameters;
    console.log(test);
    jQuery.ajax({
      url: inudev_ajax_object.ajax_url,
      type: "POST",
      data:
        "action=inudev_add_cart_single&product_id=" +
        product_id +
        "&quantity=" +
        quantity +
        "&attLocal=" +
        attLocal +
        "&attInter=" +
        attInter +
        "&relatedProducts=" +
        parameters,
      success: function (results) {
        location.reload();
        jQuery("#masthead .cart").replaceWith(results);
        jQuery("html, body").animate({ scrollTop: 0 }, "slow");
        jQuery(".cart-popup").show();
      },
    });
  } else {
    //Is a sinmple product
    var itemData =
      "action=inudev_add_cart_single&product_id=" +
      product_id +
      "&quantity=" +
      quantity +
      "&relatedProducts=" +
      parameters;
    console.log(itemData);
    jQuery.ajax({
      url: inudev_ajax_object.ajax_url,
      type: "POST",
      data: itemData,
      success: function (results) {
        /*Update minicart*/
        jQuery("#masthead .cart").replaceWith(results);
        jQuery("html, body").animate({ scrollTop: 0 }, "slow");
        jQuery(".cart-popup").show();
        location.reload();
      },
    });
  }
});
