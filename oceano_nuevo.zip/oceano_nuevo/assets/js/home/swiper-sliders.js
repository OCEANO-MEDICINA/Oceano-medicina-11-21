const swiper = new Swiper(".swiper", {
  // Optional parameters
  direction: "horizontal",
  loop: true,
  centeredSlides: false,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  breakpoints: {
    0: {
      slidesPerView: "auto",
      centeredSlides: true,
      spaceBetween: 12,
    },
    576: {
      slidesPerView: 3,
      spaceBetween: 13,
    },
    992: {
      slidesPerView: 4,
      spaceBetween: 16,
    },
    1500: {
      slidesPerView: 5,
      spaceBetween: 16,
    },
  },
});

const swiperBanner = new Swiper(".swiper-banner", {
  // Optional parameters
  effect: "fade",
  loop: true,
  slidesPerView: 1,
  centeredSlides: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },

  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
});

const swiperReviews = new Swiper(".swiper-reviews", {
  // Optional parameters
  loop: true,
  slidesPerView: 1,
  spaceBetween: 13,
  centeredSlides: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },

  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
});

const swiperWebinarsDesktop = new Swiper(".swiper-webinars", {
  // Optional parameters
  loop: true,
  slidesPerView: "auto",
  spaceBetween: 13,
  centeredSlides: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },

  breakpoints: {
    992: {
      effect: "coverflow",
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: "auto",
      centeredSlides: true,
      initialSlide: 2,
      coverflowEffect: {
        rotate: 0,
        stretch: 0,
        depth: 100,
        modifier: 10,
        initialSlide: 3,
        slideShadows: true,
      },
    },
  },

  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
});

const swiperWebinars = new Swiper(".swiper-webinars-desktop", {
  // Optional parameters

  effect: "coverflow",
  grabCursor: true,
  centeredSlides: true,
  slidesPerView: "auto",
  centeredSlides: true,
  initialSlide: 1,
  coverflowEffect: {
    rotate: 0,
    stretch: 0,
    depth: 50,
    modifier: 14.25,
    initialSlide: 3,
    slideShadows: true,
  },

  breakpoints: {
    768: {
      coverflowEffect: {
        rotate: 0,
        stretch: 0,
        depth: 50,
        modifier: 14.25,
        initialSlide: 3,
        slideShadows: true,
      },
    },
    1445: {
      coverflowEffect: {
        depth: 17,
      },
    },
  },
});
