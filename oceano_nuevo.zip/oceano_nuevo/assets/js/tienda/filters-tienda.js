jQuery(document).ready(function ($) {
  var buttonFilter;
  var filters = {};
  var $outputFiltros = $("#output-filtros");

  //Inicializa el sistema de grid Isotope

  var $productCount = $(".filter-count");

  //Detecta y aplica funciones de filtros
  var laburando = false;
  $(document).on("click", " .filter_button", function (event) {
    var $button = $(event.currentTarget);
    // get group key
    var $buttonGroup = $button.parents(".button-group");

    var filterGroup = $buttonGroup.attr("data-filter-group");
    // set filter for group
    filters[filterGroup] = $button.attr("data-filter");
    // combine filters
    filterValue = concatValues(filters);

    // $outputFiltros.text(filterValue);
    location.hash = "filter=" + encodeURIComponent(filterValue);

    // mandar atributos a filtros aplicados
    mandarFiltroActivo(
      $button.attr("data-filter"),
      $button.text(),
      filterGroup
    );

    // Isotope arrange
    filtrador();

    if (filterGroup == "tipos") {
      updateProductCount($button.attr("data-filter"));
    } else {
      updateProductCount();
    }

    var articulos = jQuery(".product-card:not([disabled]):not(.big-card)");
    articulos.each(function (index) {
      $(this).css("order", index);
    });
  });

  $(document).on("click", " .navbar-item", function (event) {
    console.log($(this).attr("href"));
    // setTimeout(onHashchange, 500);
    document.location.href = $(this).attr("href");
    location.reload();
    // return false;
  });

  function ordenamiento($value, $asc) {
    var articulos = jQuery(".product-card:not(.big-card)");

    var sorting = function (a, b) {
      var aName = parseInt(jQuery(a).attr(`data-${$value}`));
      var bName = parseInt(jQuery(b).attr(`data-${$value}`));

      if ($asc) {
        return aName < bName ? -1 : aName > bName ? 1 : 0;
      }

      return aName > bName ? -1 : aName < bName ? 1 : 0;
    };

    articulos.sort(sorting);

    articulos.each(function (index) {
      $(this).css("order", index);
    });
  }

  $(".sorting").on("click", ".order_button", function () {
    var sortByValue = $(this).attr("data-sortby");
    var sortValue = null;
    var sortDescAsc = null;

    switch (sortByValue) {
      case "duracionAsc":
        sortDescAsc = false;
        sortValue = "horas";
        break;

      case "duracionDes":
        sortDescAsc = true;
        sortValue = "horas";
        break;

      case "novedadAsc":
        sortDescAsc = false;
        sortValue = "novedad";
        break;

      case "novedadDes":
        sortDescAsc = true;
        sortValue = "novedad";
        break;

      case "costoAsc":
        sortDescAsc = false;
        sortValue = "costo";
        break;

      case "costoDes":
        sortDescAsc = true;
        sortValue = "costo";
        break;

      default:
        break;
    }
    ordenamiento(sortValue, sortDescAsc);
  });

  jQuery(document).on("keyup", "#quicksearch", filtrador);
  jQuery(document).on("keyup", "#quicksearch2", filtrador);

  function filtrador() {
    let filtors = Object.entries(filters);
    let filtros = [];

    for (let f = 0; f < filtors.length; f++) {
      const faux = filtors[f];
      filtros.push(faux[1]);
    }

    jQuery(".product-card").each(function () {
      var t = jQuery(this).find(".card-info-title").text().toLowerCase();
      var clases = jQuery(this).attr("class").split(" ");
      var enFiltros = true;

      if (filtros.length > 0) {
        enFiltros = false;
        var pasoFiltros = null;

        for (let j = 0; j < filtros.length; j++) {
          const filtro = filtros[j];
          var existo = clases.indexOf(filtro.replace(".", ""));
          if (pasoFiltros == null) {
            pasoFiltros = existo > -1 ? true : false;
          } else {
            pasoFiltros = pasoFiltros * (existo > -1 ? true : false);
          }
        }
        if (pasoFiltros) enFiltros = true;
      }

      if (
        jQuery(this).hasClass("big-card") &&
        filtros.includes(".enfermeros-auxiliares")
      ) {
        jQuery(this).css("display", "flex");
        jQuery(this).removeAttr("disabled", "false");
      } else {
        jQuery(this).css("display", "none");
        jQuery(this).attr("disabled", "true");
      }

      if (
        !t.includes(jQuery("#quicksearch").val().toLowerCase()) ||
        !enFiltros ||
        !t.includes(jQuery("#quicksearch2").val().toLowerCase())
      ) {
        jQuery(this).not(".big-card").css("display", "none");
        jQuery(this).not(".big-card").attr("disabled", "true");
      } else {
        jQuery(this).not(".big-card").css("display", "flex");
        jQuery(this).not(".big-card").removeAttr("disabled", "false");
      }
    });
    ordenamiento();
    updateProductCount();
  }

  // change is-checked class on buttons
  var $buttonGroup = $(".button-group");
  $buttonGroup.each(function (i, buttonGroup) {
    var $buttonGroup = $(buttonGroup);

    $buttonGroup.on("click", ".filter_button", function (event) {
      $btnGroupFilter = $buttonGroup.parents(".button-group");
      $btnGroupFilter = $buttonGroup.attr("data-filter-group");

      $("a[data-group-quit='" + $btnGroupFilter + "']")
        .parent()
        .remove();

      $buttonGroup
        .find(".is-checked")
        .removeClass("is-checked")
        .removeAttr("disabled");
      var $button = $(event.currentTarget);
      $button.attr("disabled", "disabled").addClass("is-checked");
    });
  });

  //Agregar boton a filtros aplicados
  function mandarFiltroActivo($filtro, $texto, $filterGroup) {
    $colortag = "";
    switch ($filtro) {
      case ".medicos":
        $colortag = "background-medicina";
        break;

      case ".enfermeros-auxiliares":
        $colortag = "background-enfermeria";
        break;

      case ".bibliography":
        $colortag = "background-bibliografia";
        break;

      case ".downloadable":
        $colortag = "background-bibliografia";
        break;

      default:
        $colortag = "background-filtro-tienda";
        break;
    }

    $outputFiltros.append(
      "<li><a class='btn btn_tag_filtros " +
        $colortag +
        " ' data-quit='" +
        $filtro +
        "'data-group-quit='" +
        $filterGroup +
        "' >" +
        $texto +
        "<i class='mdi mdi-close'></a></li>"
    );
  }

  $("#output-filtros").on("click", ".btn_tag_filtros", function () {
    var $this = $(this);
    var hashFilter = getHashFilter();
    // set filter for group
    $buttonFilter = $this.attr("data-quit");
    $groupFilter = $this.attr("data-group-quit");

    filters[$groupFilter] = filters[$groupFilter].replace($buttonFilter, "");

    var hashmodificado = hashFilter.replace($buttonFilter, "");
    hashmodificado = hashmodificado == "" ? "*" : hashmodificado;

    location.hash = "filter=" + encodeURIComponent(hashmodificado);

    $this.parent().remove();

    $(".grid-w-side-cont-filtros")
      .find(".is-checked")
      .removeClass("is-checked")
      .removeAttr("disabled");
    filtrador();
    var articulos = jQuery(".product-card:not([disabled]):not(.big-card)");
    // onHashchange();
    articulos.each(function (index) {
      $(this).css("order", index);
    });
  });

  // flatten object by concatting values
  function concatValues(obj) {
    var value = "";
    for (var prop in obj) {
      value += obj[prop];
    }
    return value;
  }

  function updateProductCount($item) {
    setTimeout(function () {
      var articulos = jQuery(".product-card:not(.big-card)");
      var visibles = 0;
      articulos.each(function (index) {
        if ($(this).css("display") != "none") {
          visibles++;
        }
      });

      if ($item == ".downloadable") {
        $productCount.text(visibles + " EBOOKS " + "DISPONIBLES");
      } else if ($item == ".bibliography") {
        $productCount.text(visibles + " BIBILIOGRAFIAS " + "DISPONIBLES");
      } else if ($item == ".course") {
        $productCount.text(visibles + " CURSOS " + "DISPONIBLES");
      } else {
        $productCount.text(visibles + " ITEMS " + " DISPONIBLES");
      }

      if (visibles == 0) {
        $("#cursos-empty").css("display", "");
      } else {
        $("#cursos-empty").css("display", "none");
      }
    }, 500);
  }

  updateProductCount();

  // var isIsotopeInit = false;

  function getHashFilter() {
    var matches = location.hash.match(/filter=([^&]+)/i);
    var hashFilter = matches && matches[1];

    return hashFilter && decodeURIComponent(hashFilter);
  }

  function onHashchange() {
    console.log("onHashchange");
    var hashFilter = getHashFilter();
    if (hashFilter) {
      var hasharray = hashFilter.split(".");
      hasharray = hasharray.map((i) => "." + i);
      console.log(hasharray);

      hasharray.forEach((element) => {
        $("a[data-filter='" + element + "']:not(.screen_btn)").click();
      });
      updateProductCount();
    }
  }
  $(window).on("load", onHashchange);
  // onHashchange();
  $("#quicksearch").trigger("keyup");
});

jQuery(document).on("click", ".dropdown-item.order_button", function () {
  jQuery(".dropdown-item.order_button")
    .not(this)
    .find("i")
    .removeClass("mdi-radiobox-marked")
    .removeClass("mdi-radiobox-blank")
    .addClass("mdi-radiobox-blank");

  jQuery(this).find("i").addClass("mdi-radiobox-marked");
});

jQuery("#quicksearch2, #quicksearch").on("click", function () {
  jQuery(this).val("").trigger("keyup");
});
