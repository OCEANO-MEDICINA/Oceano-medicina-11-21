const swiperBanner = new Swiper(".swiper-hero", {
  // Optional parameters
  effect: "fade",
  loop: true,
  slidesPerView: 1,
  centeredSlides: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },

  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
});
