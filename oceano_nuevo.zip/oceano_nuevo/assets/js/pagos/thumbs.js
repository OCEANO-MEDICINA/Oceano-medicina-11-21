
var Thumbs = function()
{
	
	this.execute = function(pais)
	{
		FetchCardsThumbs(pais);
	};
	
	// usa la api de mercadopago para obtener las tarjetas
	function FetchCardsThumbs(pais)
	{
		var thumbs;
		
		var thumbs_interval = setInterval(function()
		{
			if (Mercadopago.initialized)
			{
				thumbs = Mercadopago.getPaymentMethods();
				
				if (thumbs.length > 0)
				{
					clearInterval(thumbs_interval);
					PutCardsThumbs(thumbs, pais);
				}
			}

		}, 2000);
	}

	function PutCardsThumbs(thumbs, pais)
	{
		var credit_thumbs = [];
		var debit_thumbs = [];
		
		var askCredit = true;
		var askDebit = true;
		
		if(pais == 'ch')
			askDebit = false;

		//prepara los thumbs
		
		for(var t in thumbs)
		{
						
			if(askCredit && thumbs[t]['payment_type_id'] == 'credit_card')
			{
				var el = {};
				el['name'] = thumbs[t]['name'];
				el['image'] = thumbs[t]['secure_thumbnail'];
				
				credit_thumbs.push(el);  
			}
							
			if(askDebit && thumbs[t]['payment_type_id'] == 'debit_card')
			{
				var el = {};
				el['name'] = thumbs[t]['name'];
				el['image'] = thumbs[t]['secure_thumbnail'];
				
				debit_thumbs.push(el);  
			}
					
		}
		
		// los coloca inline
		
		//tweek fix 'No se ven las tarjetas de master.'

		function fixTweek(e){
			return e.replace('MPmaster','MP3').replace('MPdebmaster','MP3').replace('MPmaestro','MP3');
		}

		for(i in credit_thumbs)
		{
			var now = jQuery('#id_thumbs_cre').html();
			now += '<img class="img_thumb" src="'+fixTweek(credit_thumbs[i]['image'])+'" alt="'+credit_thumbs[i]['name']+'" for="credito">';
			jQuery('#id_thumbs_cre').html(now);
		}
		
		for(i in debit_thumbs)
		{
			var now = jQuery('#id_thumbs_de').html();
			now += '<img class="img_thumb" src="'+fixTweek(debit_thumbs[i]['image'])+'" alt="'+debit_thumbs[i]['name']+'" for="debito">'; 
			jQuery('#id_thumbs_de').html(now);
		}
				
		
	}
	
};

;