var TokenMessages = function()
{
	
	var token_alert = [];

	token_alert['205'] = 'Ingresa el número de tu tarjeta.';
	token_alert['208'] = 'Elige un mes.';
	token_alert['209'] = 'Elige un año.';
	token_alert['212'] = 'Ingresa tu documento.';
	token_alert['213'] = 'Ingresa tu documento.';
	token_alert['214'] = 'Ingresa tu documento.';
	token_alert['220'] = 'Ingresa tu banco emisor.';
	token_alert['221'] = 'Ingresa el nombre y apellido.';
	token_alert['224'] = 'Ingresa el código de seguridad.';
	token_alert['E301'] = 'Hay algo mal en el número de tarjeta. Vuelve a ingresarlo.';
	token_alert['E302'] = 'Revisa el código de seguridad.';
	token_alert['316'] = 'Ingresa un nombre de emisor de tarjeta válido.';
	token_alert['322'] = 'Revisa tu documento.';
	token_alert['323'] = 'Revisa tu documento.';
	token_alert['324'] = 'Revisa tu documento.';
	token_alert['325'] = 'Revisa la fecha.';
	token_alert['326'] = 'Revisa la fecha.';
	
	this.get = function(response)
	{
		var answer = "Error: Recargue la página y vuelva a llenar el formulario";
		
		//existe algo?
		if(token_alert[response.cause[0]['code']])
		{
			return('Error:' + token_alert[response.cause[0]['code']])
		}
			
		return(answer);
	};
	
};

TM = new TokenMessages();;