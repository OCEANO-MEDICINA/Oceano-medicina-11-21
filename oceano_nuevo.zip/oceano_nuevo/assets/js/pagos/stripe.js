var enviando = false;
carriten = php_vars_passed.carriten;
jQuery(document).ready(function ($) {
  $("#cardholderName").on("change", function () {
    $("#card-name-errors").html("");
  });
  $("#lostyccl").on("change", function () {
    $("#card-terminos-errors").html("");
  });
  // $('.InputElement')addClass('inputmalo');
  $("#telefonocodigo").picker({ containerClass: "pickerPais" });
  $(".pickerPais .pc-element").addClass("has-flag flag-ar");
  $("#telefonocodigo option").each(function (i, e) {
    $(`.pickerPais li[data-id='${$(e).attr("value")}']`).addClass(
      `flag-${$(e).attr("flag")}`
    );
  });
  $(".pickerPais li").on("click", function () {
    let a = $(".pc-element.pc-trigger.has-flag");
    //console.log(a);
    a.removeClass();
    a.addClass("pc-element pc-trigger has-flag " + $(this).attr("class"));
  });
  $("#id_add_provincia").on("change", function () {
    $("#id_del_provincia").val($(this).val());
  });

  $("#id_zip").on("change", function () {
    $("#del_codigopostal").val($(this).val());
  });

  $("#direccion").on("change", function () {
    $("#del_calle").val($(this).val());
    $("#del_numero").val("0");
  });

  $(document).on("change", "cardExpirationMonth2", function () {
    $("#cardExpirationMonth").val($(this).val().split("/")[0]);
    $("#cardExpirationYear").val($(this).val().split("/")[1]);
  });

  Vsteps.build(["Pago", "Confirmación"]);
  Utility.urlTrack("datos-personales");

  //Update installments prices
  let installments = jQuery("#id_cookie_inst").val();
  installments = installments ? installments : 12;
  populator.updatePrices(installments);

  populator.addListenerToScp();

  let stripeObject = mount_stripe_card();
  let stripe = stripeObject.stripe;
  let elements = stripeObject.elements;

  async function validarB() {
    if (enviando) return;

    enviando = true;
    console.log("Continuar clicked");
    let r = true;
    // let currentStep = progressButton.data('current-step');

    let steps = [
      "part_datosadicionales",
      "part_datostarjeta",
      "part_meses",
      // "part_confirmar",
      // 'compra-rechazada',
      // 'compra-confirmada',
    ];

    for (var i = 0; i < steps.length; i++) {
      let validationResult = await validateCurrentStep(steps[i]);
      console.log(validationResult);
      if (!validationResult) {
        r = false;
        enviando = false;
        break;
      }
    }

    if ($("#cardholderName").val() == "") {
      $("#card-name-errors").html(
        "El nombre que figura en la tarjeta esta incompleto."
      );
      $("#cardholderName").focus();
      r = false;
    }

    if (!$("#cbox1").prop("checked")) {
      $("#card-terminos-errors").html(
        "Debe aceptar los términos y condiciones para continuar."
      );
      $("#cbox1").focus();
      r = false;
    }

    if (r) processTransaction();
  }
  jQuery("#id_proceed").on("click", function () {
    validarB();
  });
  // jQuery('#id_proceed').on("click", function () {
  //     console.log('Continuar clicked');
  //     let progressButton = $(this);
  //     let currentStep = progressButton.data('current-step');
  //     let validationResult = validateCurrentStep(currentStep);
  //     console.log(validationResult);
  //     if (validationResult) {
  //         goToNextStep();
  //     }
  // });

  function goToNextStep() {
    let progressButton = jQuery("#id_proceed");
    let currentStep = progressButton.data("current-step");
    let nextStep = progressButton.data("next-step");
    let nextStepForm = $("#" + nextStep);

    let progressButtonText =
      nextStep === "part_confirmar" ? "CONFIRMAR" : "CONTINUAR";
    progressButton.text(progressButtonText);

    $(".cl_part_form").hide();
    nextStepForm.show();
    progressButton.data("current-step", nextStep);
    progressButton.data("next-step", nextStepForm.data("next-step"));
    urlTrackStep(nextStep);
    if (nextStep === "part_resultado") {
      //We need to process the payment and transaction
      processTransaction();
    }
  }

  function urlTrackStep(step) {
    if (step === "part_resultado") {
      return;
    }
    let steps = {
      part_datosadicionales: "datos-personales",
      part_datostarjeta: "datos-tarjeta",
      part_meses: "plan-suscripcion",
      part_confirmar: "confirmacion-compra",
      // 'compra-rechazada': 'compra-rechazada',
      // 'compra-confirmada': 'compra-confirmada',
    };

    $("#id_proceed")
      .removeClass()
      .addClass("btn btn-pink " + steps[step]);
    Utility.urlTrack(steps[step]);
  }

  //Back anchor functionality
  $(".class_back").on("click", function () {
    let currentStepFormId = $(this).parent().parent().attr("id");
    let targetStepFormId = $("div")
      .find("[data-next-step='" + currentStepFormId + "']")
      .attr("id");

    urlTrackStep(targetStepFormId);

    //Go to previous step
    $(".cl_part_form").hide();
    let nextStepForm = $("#" + targetStepFormId);
    nextStepForm.show();

    //Update button steps
    let progressButton = jQuery("#id_proceed");
    progressButton.data("current-step", targetStepFormId);
    progressButton.data("next-step", currentStepFormId);
  });

  async function validateCurrentStep(currentStep) {
    console.log("Validating: " + currentStep);

    let skip = []; //This is for debugging
    //let skip = ['part_datosadicionales']; //This is for debugging
    if (skip.includes(currentStep)) {
      return true;
    }

    let formId = "form" + currentStep.slice(4);

    let returnValue = jQuery("#" + formId)
      .parsley()
      .validate();

    if (currentStep === "part_datostarjeta" && returnValue) {
      // returnValue = false;
      returnValue = await getStripePaymentId();
    }

    return returnValue;
  }

  function getStripePaymentId() {
    return new Promise(function (resolve) {
      let cardNumberElement = elements.getElement("cardNumber");

      stripe
        .createPaymentMethod({
          type: "card",
          card: cardNumberElement,
          billing_details: {
            name: $("#cardholderName").val(),
          },
        })
        .then(function (result) {
          // console.log(result);
          if (result.error) {
            console.log("Error happened");
            validate_stripe_field(result, "number");
            resolve(false);
          } else {
            // goToNextStep();
            // validarB();

            resolve(result.paymentMethod.id);
          }
        });
    });
  }

  function processTransaction() {
    console.log("processing transaction");

    jQuery("#id_proceed").html("Procesando...");
    //var options = {address_zip: document.getElementById('postal-code').value,};
    var cardNumberElement = elements.getElement("cardNumber");
    stripe
      .createPaymentMethod({
        type: "card",
        card: cardNumberElement,
        billing_details: {
          name: $("#cardholderName").val(),
        },
      })
      .then(function (result) {
        if (result.paymentMethod) {
          console.log("went WELL");

          var allForms = {};
          allForms.datosadicionales = packValues("#form_datosadicionales");
          allForms.meses = packValues("#form_meses");
          allForms.formadepago = {
            procesadorpago: "stripe",
            stripePaymentMethodId: result.paymentMethod.id,
            formadepago: "credito",
          };
          pais = jQuery("#id_country").val();
          _processor = jQuery("#id_processor").val();
          console.log(pais);
          allForms.ult = {
            procesadorpago: "stripe",
            processor: "stripe",
            stripePaymentMethodId: result.paymentMethod.id,
            pais: pais,
          };

          allForms.first = {
            estilodepago: "suscripcion",
          };

          allForms.delivery = {
            del_calle: "",
            del_piso: "",
            del_entre: "",
            del_barrio: "",
            del_ref: "",
          };

          //Marketing data
          allForms.ult.utm_source = getCookie("utm_source");
          allForms.ult.utm_medium = getCookie("utm_medium");
          allForms.ult.utm_campaign = getCookie("utm_campaign");
          allForms.ult.utm_content = getCookie("utm_content");
          allForms.ult.gclid = getCookie("gclid");

          allForms.ult.origin = "medicina";
          allForms.ult.testEnvironment = is_test_environment();
          console.log(allForms);

          let transactionMessage = jQuery("#id_msg_result");

          //mandarla
          jQuery.ajax({
            type: "POST",
            url: carriten,
            dataType: "json",
            data: {
              action: "hookcarrito",
              allForms,
            },
            success: function (response) {
              console.log("transaction processed");
              console.log(response);
              enviando = false;
              let result = false;
              if (response) {
                try {
                  if (response.transaction) {
                    if (response.transaction !== "error") {
                      //All good
                      result = true;
                    }
                  }
                } catch (e) {
                  result = false;
                }
              }
              if (result) {
                // alert('<p>Compra realizada con éxito</p>');
                showVisualTransaction("good");
              } else {
                alert("No se pudo realizar la transacción");
                showVisualTransaction("bad");
              }
              window.scrollTo({
                top: 0,
                behavior: "smooth",
              });
            },
            error: function (d) {
              enviando = false;
              console.log(d);
              console.log("Error procesando transaccion");
              alert("No se pudo realizar la transacción");
              showVisualTransaction("bad");
              window.scrollTo({
                top: 0,
                behavior: "smooth",
              });
            },
          });
        }
        if (result.error) {
          console.log(
            "Error al crear el método de pago a partir de la tarjeta"
          );
          alert("Error al procesar la tarjeta. Intente nuevamente");
          showVisualTransaction("bad");
          window.scrollTo({
            top: 0,
            behavior: "smooth",
          });
        }
        console.log(result);
      });
  }

  function packValues(selector) {
    var answer = {};

    //para los input
    jQuery(selector + " input").each(function () {
      var atr = jQuery(this).attr("name");

      //tiene este atributo?
      if (typeof atr !== typeof undefined && atr !== false) {
        //vemos que tipo de input es, esto hace que varie la metodologia
        if (
          jQuery(this).attr("type") == "text" ||
          jQuery(this).attr("type") == "email"
        )
          answer[atr] = jQuery(this).val();
        else if (jQuery(this).attr("type") == "hidden")
          answer[atr] = jQuery(this).val();
        else if (jQuery(this).attr("type") == "radio") {
          if (jQuery(this).prop("checked")) answer[atr] = jQuery(this).val();
        }
      }
    });

    //para los select
    jQuery(selector + " select").each(function () {
      var atr = jQuery(this).attr("name");

      //tiene este atributo?
      if (typeof atr !== typeof undefined && atr !== false) {
        answer[atr] = jQuery(this).val();
      }
    });

    return answer;
  }

  function is_test_environment() {
    console.log(
      "is test environment: " + window.location.origin.includes("tech")
    );
    return window.location.origin.includes("tech");
  }

  function showVisualTransaction(status) {
    jQuery("#id_proceed").hide();

    if (status == "good") {
      //url
      urlTrackStep("compra-confirmada");

      //send event to google
      /*ga('send', {
                hitType: 'event',
                eventCategory: 'carrito',
                eventAction: 'compra',
                eventLabel: 'aprobada',
                eventValue: 1
            });*/

      //pinta de verde
      jQuery(".rightside.container").addClass("green");

      //los pasos visuales todo bien
      Vsteps.finish("good");

      //FB
      Utility.facebookTrack(1);

      //dado que está todo bien... vacio el carrito!
      redirigirSuccess();
      // emptyCart(true);
    } else if (status == "bad") {
      //url
      // urlTrackStep('compra-rechazada');

      //send event to google
      /*ga('send', {
                hitType: 'event',
                eventCategory: 'carrito',
                eventAction: 'compra',
                eventLabel: 'rechazada',
                eventValue: 1
            });*/
      jQuery("#id_proceed").html("Reintentar...");
      //FB
      Utility.facebookTrack(0);
      alert("Algo salio mal");
      //todo mal
      // jQuery('.rightside.container').addClass('red');

      //los pasos visuales todo mal
      // Vsteps.finish('bad');

      // jQuery('#id_msg_result').append('<a style="cursor:pointer; color: #007bff; text-decoration: underline;" onClick="window.location.reload();">Volver a intentar</a>');
    }
  }

  //hace un ajax para vaciar el carrito
  function redirigirSuccess() {
    location.href = "/gracias_compra";
  }

  function emptyCart(reduceStock = false) {
    jQuery.ajax({
      type: "POST",
      url: carriten.carritourl,
      dataType: "json",
      data: {
        action: "hookvaciarcarrito",
        reduce_stock: reduceStock,
      },
      success: function (d) {
        //console.log('carrito vaciado');
      },
      error: function (d) {
        //console.log('mmhm, no pude vaciar carrito');
      },
    });
  }

  function mount_stripe_card() {
    //  var stripe = Stripe('pk_test_Fe6BvuF7X9LrFex0gAVwoZZg00P1ArIHzK'); //OCEANO TEST
    //var stripe = Stripe('pk_live_FEiANH8dDZZa7mRMMohUZaTF00hiFaly04'); //OCEANO

    let stripeApiKey = is_test_environment()
      ? "pk_test_Fe6BvuF7X9LrFex0gAVwoZZg00P1ArIHzK"
      : "pk_live_FEiANH8dDZZa7mRMMohUZaTF00hiFaly04";
    let stripe = Stripe(stripeApiKey);
    var elements = stripe.elements({
      fonts: [
        {
          cssSrc:
            "https://fonts.googleapis.com/css2?family=Roboto&display=swap",
        },
      ],
    });

    var style = {
      base: {
        backgroundColor: "#EFEFEF",
        iconColor: "#666EE8",
        color: "#404040",
        lineHeight: "30px",
        fontWeight: 400,
        fontFamily: "Roboto",
        fontSize: "16px",

        "::placeholder": {
          color: "#757575",
        },
      },
    };

    style = {
      base: {},
    };

    var cardNumberElement = elements.create("cardNumber", {
      style: style,
      placeholder: "XXXX XXXX XXXX XXXX",
      classes: {
        base: "inputmalo",
      },
    });
    cardNumberElement.mount("#card-number-element");

    var cardExpiryElement = elements.create("cardExpiry", {
      style: style,
      placeholder: "MM/AA",
      classes: {
        base: "inputmalo",
      },
    });
    cardExpiryElement.mount("#card-expiry-element");

    var cardCvcElement = elements.create("cardCvc", {
      style: style,
      placeholder: "XXX",
      classes: {
        base: "inputmalo",
      },
    });
    cardCvcElement.mount("#card-cvc-element");

    cardNumberElement.addEventListener("change", function (event) {
      validate_stripe_field(event, "number");
    });
    cardExpiryElement.addEventListener("change", function (event) {
      validate_stripe_field(event, "expiry");
    });
    cardCvcElement.addEventListener("change", function (event) {
      validate_stripe_field(event, "cvc");
    });

    return {
      stripe: stripe,
      elements: elements,
    };
  }

  function validate_stripe_field(event, field) {
    let displayError = document.getElementById("card-" + field + "-errors");
    let errorsTranslation = {
      invalid_number: "El número ingresado no es válido",
      invalid_expiry_month: "El mes ingesado no es válido",
      invalid_expiry_year: "El año ingresado no es válido",
      invalid_cvc: "El número de seguridad no es válido",
      incorrect_number: "El número de la tarjeta es incorrecto",
      incomplete_number: "El número de la tarjeta está incompleto",
      incomplete_cvc: "El código de seguridad esta incompleto",
      incomplete_expiry: "La fecha de vencimiento está incompleta",
      expired_card: "La tarjeta esta vencida",
      incorrect_cvc: "El código de seguridad es incorrecto",
      incorrect_zip: "El código postal falló la verificación",
      invalid_expiry_year_past: "El año de expiración está en el pasado",
      card_declined: "La tarjeta fué rechazada",
      missing: "No hay tarjeta asociada al cliente que se quiere cobrar",
      processing_error: "Ocurrió un error mientras procesabamos la orden",
    };
    if (event.error) {
      displayError.textContent = errorsTranslation[event.error.code];
    } else {
      displayError.textContent = "";
    }
  }
});
