//esto es para ajax
//cuando voy apretó el botón de continuar... se desactiva momentaneamente ese boton
//el tema es que, cuando es ajax... necesito tener un tiempo más largo desactivado
//pero al ser asincronico.. bueno, necesito alguna variable global para avisar que aun estoy laburanod
ignoreCallButton = false;
_pais = ""; //constante de pais, global
_processor = "";
_currency = "";
_cookie_installments = ""; //constante de cuotas almacenada en cookie de php
_domain = ""; //dominio!
_url = ""; //url /pagos
carriten = php_vars_passed.carriten;
var Main = function () {
  // $('.selectpicker').selectpicker();
  //setea el boton para avanzar
  jQuery("#id_proceed").click(function () {
    if (jQuery(this).data("status") == "on") proceed(false);
  });
  jQuery(document).ready(function ($) {
    Inputmask({ mask: "99/9999" }).mask("#cardExpirationMonth2");
    $("#telefonocodigo").picker({ containerClass: "pickerPais" });
    $(".pickerPais .pc-element").addClass("has-flag flag-ar");

    $("#telefonocodigo option").each(function (i, e) {
      $(`.pickerPais li[data-id='${$(e).attr("value")}']`).addClass(
        `flag-${$(e).attr("flag")}`
      );
      $(`.pickerPais li[data-id='${$(e).attr("value")}']`).attr(
        "pais",
        `${$(e).attr("pais")}`
      );
    });

    $(".pickerPais li").on("click", function () {
      let a = $(".pc-element.pc-trigger.has-flag");
      //console.log(a);
      a.removeClass();
      a.addClass("pc-element pc-trigger has-flag " + $(this).attr("class"));

      $("#paisalumno").val($(this).attr("pais"));
    });

    $("#id_add_provincia").on("change", function () {
      $("#id_del_provincia").val($(this).val());
    });

    $("#id_zip").on("change", function () {
      $("#del_codigopostal").val($(this).val());
    });

    $("#direccion").on("change", function () {
      $("#del_calle").val($(this).val());
      $("#del_numero").val("0");
    });

    $(document).on("change", "#cardExpirationMonth2", function () {
      $("#cardExpirationMonth").val($(this).val().split("/")[0]);
      $("#cardExpirationYear").val($(this).val().split("/")[1]);
    });
  });

  //boton para retroceder
  jQuery(".class_back").click(back);

  jQuery("input[name=estilodepago]").change(function () {
    var estilodepago = this.value;
    console.log(this.value);
  });

  var partIndex = 0; //para controlar en qué paso está
  var estilodepago = "tradicional"; //qué estilo de pago quiere el usuario?
  var formadepago = "credito"; //forma de pago
  var tipodecompra = 0; //3 mezcla, 2 fisico o 1 curso...

  _pais = jQuery("#id_country").val();
  _cookie_installments = jQuery("#id_cookie_inst").val();
  _domain = jQuery("#id_domain").data("domain");
  _url = window.location.href;

  setProcessor();

  readOptions();

  //setea el procesador correspondiente
  function setProcessor() {
    _processor = jQuery("#id_processor").val();
    _currency = jQuery("#id_currency").val();

    if (_processor == "mercadopago") {
      formadepago = "credito";
      setMP();
    } else if (_processor == "paypal") {
      formadepago = "window";
      setPaypal();
    }
  }

  function setPaypal() {
    //escondo métodos que no estén disponibles
    Utility.hideUnavailableMethods(_pais);

    //setear los precios en 1 cuota porque paypal no vi que ofrezca cuotas
    populator.updatePrices(1);
  }

  //en realidad, además de setear mercadopago (libreria)...
  //setea detalles de la pasarela de pagos
  function setMP() {
    Mercadopago.setPublishableKey(Utility.givePublicKey(_pais));
    Mercadopago.getIdentificationTypes();

    //escondo métodos que no estén disponibles
    Utility.hideUnavailableMethods(_pais);

    //set iconitos de crédito débito
    thumbs = new Thumbs();
    thumbs.execute(_pais);

    //vacía número de tarjeta, por las dudas (necesitas tocar el campo para cargar cuotas y eso)
    jQuery("#cardNumber").val("");

    //obtener data del resto de pagos
    //con esto también armo los otros iconitos
    // populator.wholeMethods();

    //setear los precios en cuotas de (cookies)
    populator.updatePrices(_cookie_installments);

    //setea detalles adicionales (por ej, si es chile, más datos)
    Utility.details();

    //agregar a los radio de meses de suscripcion,
    //un listener para que actualice las cuotas de la derecha
    populator.addListenerToScp();

    //un listener para terminos y condiciones
    validador.addListenerToTyc();

    Utility.urlTrack("datos-personales");
  }

  //lee las opciones de si hay curso y producto fisico
  function readOptions() {
    var shipment = false;

    var fillingwhat = ""; //pongo letras en base a los tipos de producto...

    //no hay curso? desactivamos suscripcion
    if (jQuery("#id_data_1").data("course") == 0) {
      jQuery(".formasucri").hide();
      jQuery("#tradicional").prop("checked", true);
    } else {
      //hay curso =)
      fillingwhat += "c";
    }

    //no hay producto fisico? desactivamos envios y otras cositas
    if (jQuery("#id_data_1").data("physical") == 0) {
      jQuery("#form_delivery").trigger("reset"); //reinicia form delivery
      //jQuery('#part_first .return').hide(); //esconde botón volver de paso 1

      //nueva regla... tiene curso solo? no hay forma tradicional!
      //jQuery('.formatrad').hide();
      jQuery("#suscripcion").prop("checked", true);

      //proceed(true); //va hacia adelante
    } else {
      //hay producto físico, joya, activamos shipment para los pasos visuales
      shipment = true;
      fillingwhat += "p";

      //dado que hay libro, voy a esconder la provincia de datos adicionales
      // jQuery('#id_add_provincia').parent().hide();
    }

    //adicionalmente, setea los pasos visuales
    if (shipment) {
      Vsteps.build(["Envío", "Pago", "Confirmación"]);
    } else {
      Vsteps.build(["Pago", "Confirmación"]);
    }

    if (fillingwhat == "p") tipodecompra = 2;
    else if (fillingwhat == "c") tipodecompra = 1;
    else if (fillingwhat == "cp") tipodecompra = 3;
  }

  function proceed(omitValidations) {
    // console.log('CLICK');
    buttonOff();

    var shouldProceed = false;
    // var partIndexNueva = 0;

    for (var partIndexNueva = 0; partIndexNueva <= 8; partIndexNueva++) {
      console.log(partIndexNueva);
      updateProperties(partIndexNueva);

      if (omitValidations) {
        shouldProceed = true;
      } else {
        shouldProceed = validador.run(
          partIndexNueva,
          estilodepago,
          formadepago
        );

        //esto va a dar true si pusiste tarjetas y dió todo OK
        if (validador.mustCreateToken) {
          createCardToken();
        }

        //si validas installments, tenés que actualizar labels
        if (validador.updateQuotes) {
          populator.updatePrices(jQuery("[name=cuotas_cre]:checked").val());
        }
      }
      // console.log(shouldProceed);
      if (shouldProceed) {
        // partIndex++;
        changePart(1);

        if (partIndexNueva == 8) {
          if (!jQuery("#cbox1").prop("checked")) {
            jQuery("#id_msg_error_2").append(
              "<p>Debe aceptar los terminos y condiciones</p>"
            );
            return;
          } else {
            sendForm();
          }
        }
      } else {
        break;
      }
    }

    buttonOn();
  }
  //si omit es true, omite las validaciones
  function proceed2(omitValidations) {
    // return;
    buttonOff();

    updateProperties(partIndex);
    //primero validar!
    var shouldProceed = false;

    if (omitValidations) {
      shouldProceed = true;
    } else {
      shouldProceed = validador.run(partIndex, estilodepago, formadepago);

      //esto va a dar true si pusiste tarjetas y dió todo OK
      if (validador.mustCreateToken) {
        createCardToken();
      }

      //si validas installments, tenés que actualizar labels
      if (validador.updateQuotes) {
        populator.updatePrices(jQuery("[name=cuotas_cre]:checked").val());
      }
    }

    if (shouldProceed) {
      partIndex++;
      changePart(1);
    }

    buttonOn();
  }

  function back() {
    //limpio los mensajes
    jQuery("#id_msg_error").html("");

    partIndex--;
    changePart(-1);
  }

  //desactiva boton
  function buttonOff() {
    jQuery("#id_proceed").data("status", "off");
    jQuery("#id_proceed").html("Procesando...");

    //tambien el volver
    jQuery(".class_back").hide();
  }

  //activa boton
  function buttonOn() {
    if (ignoreCallButton) {
    } else {
      jQuery("#id_proceed").data("status", "on");
      jQuery("#id_proceed").html("Pagar");

      //tambien el volver
      jQuery(".class_back").show();
    }
  }

  //actualiza propiedades internas del form, le pasas la parte de form
  //por ejemplo, si está en el paso 1, la propiedad sería si quiere pago trad o suscri
  function updateProperties(part) {
    if (part == 2) {
      estilodepago = jQuery("[name=estilodepago]:checked").val();
    } else if (part == 3) {
      formadepago = jQuery("[name=formadepago]:checked").val();
    }
  }

  //cambia el formulario en base al número que tenga
  //en que dirección se estaba moviendo? dir 1 adelante...
  //dir -1 atrás
  //esto es porque si tengo que omitir algo... se de dónde viene y a
  //dónde llevarlo
  function changePart(dir) {
    //por si tengo que saltear esta aparte y continuar atrás o adelante
    var omitPart = false;

    //primero "apago" todas las partes de form, así luego saco
    //al aire la que corresponde
    jQuery(".cl_part_form").hide();

    if (_processor == "mercadopago") omitPart = roadMercadopago(dir);
    else if (_processor == "paypal") omitPart = roadPaypal(dir);

    if (omitPart) {
      if (dir == 1) proceed(true);
      else if (dir == -1) back();
    }

    //actualiza los pasos, simplemente
    //sé que si es 0, es una cosa, si es 1 a 6 es otra, si es 7 es otra, listo!

    // if(!omitPart){
    // 	if(partIndex == 0 || partIndex == 1)
    // 		Vsteps.set('Envío');
    // 	else if(partIndex >= 2 && partIndex <= 6){
    // 		Vsteps.set('Pago');
    // 	}
    // 	else if(partIndex == 7){
    // 		Vsteps.set('Confirmación');
    // 	}
    // }
  }

  //este es el camino de mercadopago...
  //va cambiando el form
  //devuelve si tiene que omitir la parte o no
  function roadMercadopago(dir) {
    var omitPart = false;

    if (partIndex == 1) {
      if (jQuery("#id_data_1").data("physical") == 0) {
        omitPart = true;
      } else {
        jQuery("#part_delivery").show();
        Utility.urlTrack("datos-envio", "datos-adicionales");
      }
    } else if (partIndex == 2) {
      //dado que algunos paises no tienen suscri... me fijo si lo tengo escondido
      //(o sea que me queda solo la opcion tradicional)
      //si está escondido pues, me salteo este paso

      //ojo! primero lo muestro, ya que pregunto si está hidden... me va a dar siempre que sí! EN CAMBIO...
      //si muestro TODO... voy a poder preguntar por el formasucri de forma aislada... y entonces ahí me va a decir
      //si está hidden or not!
      jQuery("#part_first").show();
      Utility.urlTrack("modalidad-pago");

      /*if(jQuery('.formasucri').is(":hidden") && dir == 1){
				omitPart = true;
				jQuery('#part_first').hide();
			}*/
    } else if (partIndex == 3) {
      jQuery("#part_formadepago").show();
      Utility.urlTrack("tipo-pago");
    } else if (partIndex == 4) {
      Utility.urlTrack("datos-tarjeta");

      if (formadepago == "credito" || formadepago == "debito")
        jQuery("#part_datostarjeta").show();
      else if (formadepago == "cupon") jQuery("#part_datoscupon").show();
      else if (formadepago == "deposito") jQuery("#part_datosdeposito").show();
      else if (formadepago == "transferencia")
        jQuery("#part_datostransferencia").show();

      //debito+tradicional defaultea en 1 cuota
      if (formadepago == "debito" && estilodepago == "tradicional")
        populator.updatePrices(1);
    } else if (partIndex == 0) {
      jQuery("#part_datosadicionales").show();
      Utility.urlTrack("datos-personales");

      //transferencia no hay... así que...
      /*
			if((_pais == 'ch' || _pais == 'co') && formadepago == 'transferencia')
				jQuery('#id_more_data').show();
			else
				jQuery('#id_more_data').hide();
			*/
    } else if (partIndex == 5) {
      if (formadepago == "credito") {
        if (estilodepago == "suscripcion") {
          //si usa suscrip, no me interesna las cuotas
          omitPart = true;
        } else {
          if (dir == 1) {
            populator.doInstallments();
            adjust("libro_cuotas");
          }

          jQuery("#part_cuotas").show();
          Utility.urlTrack("plan-cuotas");
        }
      } else {
        omitPart = true;
      }
    } else if (partIndex == 6) {
      if (estilodepago == "suscripcion") {
        jQuery("#part_meses").show();
        Utility.urlTrack("plan-suscripcion");

        var installments = jQuery("#id_cookie_inst").val();
        if (installments) {
          populator.updatePrices(installments);
        }
      } else omitPart = true;
    } else if (partIndex == 7) {
      jQuery("#part_confirmar").show();
      Utility.urlTrack("confirmacion-compra");
    } else if (partIndex == 8) {
      jQuery("#part_resultado").show();
      sendForm();
    } else if (partIndex == 9) {
      location.assign(Utility.urlClean());
      //location.reload(true);
    }
    return omitPart;
  }

  //ajustes por condición
  //le pasas el ajuste que querés que haga...
  function adjust(a) {
    //si solo hay libros en el carro de compras... limito cuotas a 1,3,6
    if (a == "libro_cuotas") {
      if (tipodecompra == 2) {
        jQuery(".radio-cuota").each(function () {
          var value = jQuery(this).val();
          if (value > 6) jQuery(this).parent().remove();
        });
      }
    }
    //else
  }

  function redirigirSuccess() {
    location.href = "/gracias_compra";
  }

  //hace un ajax para vaciar el carrito

  function emptyCart(reduceStock = false) {
    jQuery.ajax({
      type: "POST",
      url: carriten,
      dataType: "json",
      data: {
        action: "hookvaciarcarrito",
        reduce_stock: reduceStock,
      },
      success: function (d) {
        //console.log('carrito vaciado');
      },
      error: function (d) {
        //console.log('mmhm, no pude vaciar carrito');
      },
    });
  }

  //envia form por ajax
  function sendForm() {
    console.log("Enviamos el form");
    var allForms = {};

    allForms.delivery = packValues("#form_delivery");
    allForms.first = packValues("#form_first");
    allForms.formadepago = packValues("#form_formadepago");

    if (formadepago == "deposito")
      allForms.datosformadepago = packValues("#form_datosdeposito");
    else if (formadepago == "cupon")
      allForms.datosformadepago = packValues("#form_datoscupon");
    else if (formadepago == "transferencia")
      allForms.datosformadepago = packValues("#form_datostransferencia");
    else if (formadepago == "credito") {
      allForms.datosformadepago = packValues("#form_datostarjeta");
      allForms.cuotas = packValues("#form_cuotas");
      allForms.datosformadepago.installments = _cookie_installments;
    } else if (formadepago == "debito")
      allForms.datosformadepago = packValues("#form_datostarjeta");

    allForms.datosadicionales = packValues("#form_datosadicionales");

    if (estilodepago == "suscripcion")
      allForms.meses = packValues("#form_meses");

    //data final
    allForms.ult = {};
    allForms.ult.pais = _pais;
    allForms.ult.processor = _processor;

    //Marketing data
    allForms.ult.utm_source = getCookie("utm_source");
    allForms.ult.utm_medium = getCookie("utm_medium");
    allForms.ult.utm_campaign = getCookie("utm_campaign");
    allForms.ult.utm_content = getCookie("utm_content");
    allForms.ult.gclid = getCookie("gclid");

    //origen
    allForms.ult.origin = "medicina";

    ignoreCallButton = true;

    //mandarla
    jQuery.ajax({
      type: "POST",
      url: carriten,
      //url:'../../petest.php',
      dataType: "json",
      data: {
        action: "hookcarrito",
        allForms,
      },
      success: function (d) {
        //jQuery('.leftside').html(JSON.stringify(d));
        console.log("transaction processed");
        if (_processor == "mercadopago") {
          handleTransactionResult(d);
        } else handlePaypalLink(d);

        ignoreCallButton = false;
        buttonOn();
        retextButton();
      },
      error: function (d) {
        //jQuery('#id_msg_error').html(JSON.stringify(d));
        //jQuery('.leftside').html(JSON.stringify(d));

        console.log("procesando error de transaccion");
        console.log(_processor);

        //estamos segurísimos que reventó todo?? a ver...
        if (typeof d["transaction"] !== "undefined") {
          //parece que no reventó tanto
          if (_processor == "mercadopago") handleTransactionResult(d);
          else handlePaypalLink(d);
        } else {
          //se, boom, todo al joraca
          alert(
            "Hubo un problema grave y no se pudo procesar bien la transacción."
          );

          showVisualTransaction("bad");

          jQuery("#id_msg_result").html("Vuelva a intentar la transacción.");
        }

        ignoreCallButton = false;
        buttonOn();
        retextButton();
      },
    });
  }

  //arma el link de paypal
  function handlePaypalLink(result) {
    var link = result["transaction"];

    if (link == "error" || link == 0) {
      jQuery("#id_msg_result").html("");
      showVisualTransaction("bad");
    } else
      jQuery("#id_msg_result").html(
        "<a href='" + link + "'> Proceder a Paypal </a>"
      );
  }

  //te muestra el mensaje de si salió todo bien o no con la transacc
  function handleTransactionResult(result) {
    var mp = 0;
    var sub = 0;

    jQuery("#id_msg_result").html("");

    if (result["transaction"] !== null) {
      //está definido MP?
      if (typeof result["transaction"]["mp"] !== "undefined") {
        // jQuery('#id_msg_result').append('<p>'+result['transaction']['mp']['message']+'</p>');
        // alert(result['transaction']['mp']['message']);

        if (
          result["transaction"]["mp"]["status"] == 1 ||
          result["transaction"]["mp"]["status"] == 2
        ) {
          mp = 1;
        } else mp = -1;
      } else {
        // jQuery('#id_msg_result').append('<p>No se pudo realizar la transacción</p>');
        alert("No se pudo realizar la transacción");
        mp = -1;
      }

      //está definido suscri?
      if (typeof result["transaction"]["sub"] !== "undefined") {
        // alert(result['transaction']['sub']['message']);

        if (result["transaction"]["sub"]["status"] == 1) {
          sub = 1;
        } else sub = -1;
      }
    } else {
      alert("Error de transacción");
    }

    //muestra lo que haya en reglas, si salió mal...
    if (result["rules"]["result"] === false) {
      alert("" + result["rules"]["reason"] + "");
    }

    if (mp == 1 && (sub == 1 || sub == 0)) {
      showVisualTransaction("good");
    } else {
      showVisualTransaction("bad");
    }
  }

  //si le pasas good, muestra todo lindo, salio todo piola
  //si le pasas bad, muestra todo rojo, salio todo mal
  function showVisualTransaction(status) {
    if (status == "good") {
      //url
      Utility.urlTrack("compra-confirmada");

      //send event to google
      /*ga('send', {
				hitType: 'event',
				eventCategory: 'carrito',
				eventAction: 'compra',
				eventLabel: 'aprobada',
				eventValue: 1
			});*/

      //pinta de verde
      jQuery(".rightside.container").addClass("green");

      //los pasos visuales todo bien
      Vsteps.finish("good");

      //FB
      Utility.facebookTrack(1);

      //dado que está todo bien... vacio el carrito!
      //todo: We should reduce the stock of the products in the cart x their quantities before emptying it
      redirigirSuccess();
      // emptyCart(true);
    } else if (status == "bad") {
      //url
      Utility.urlTrack("compra-rechazada");

      //send event to google
      /*ga('send', {
				hitType: 'event',
				eventCategory: 'carrito',
				eventAction: 'compra',
				eventLabel: 'rechazada',
				eventValue: 1
			});*/

      //FB
      Utility.facebookTrack(0);

      //todo mal
      jQuery(".rightside.container").addClass("red");

      //los pasos visuales todo mal
      Vsteps.finish("bad");

      //
      jQuery("#id_msg_result").append(
        "<p>[No se pudo ejecutar la transacción]</p>"
      );
    }
  }

  //gestiona el tema de token tarjeta
  function createCardToken() {
    console.log("creando token");
    ignoreCallButton = true;
    var $form = document.querySelector("#form_datostarjeta");
    Mercadopago.createToken($form, handleCardToken);
  }

  //maneja la respuesta del token
  function handleCardToken(status, response) {
    ignoreCallButton = false;
    buttonOn();

    if (status != 200 && status != 201) {
      validador.publicMsg(TM.get(response));
    } else {
      var form = document.querySelector("#form_datostarjeta");

      var card = document.createElement("input");
      card.setAttribute("name", "token");
      card.setAttribute("id", "token");
      card.setAttribute("type", "hidden");
      card.setAttribute("value", response.id);
      form.appendChild(card);

      proceed(true);
    }
  }

  //interpreta Vsteps, y cambia el texto del botón en base a eso
  function retextButton() {
    //si salió todo bien el pago, cambia el texto al boton
    if (Vsteps.giveEnd() == "good")
      jQuery("#id_proceed").html("Seguir comprando");
    else if (Vsteps.giveEnd() == "bad")
      jQuery("#id_proceed").html("Reintentar el pago");
  }

  //le das un selector de form
  //toma los inputs, si tienen name, va armando name -> value
  //te devuelve todo
  function packValues(selector) {
    var answer = {};

    //para los input
    jQuery(selector + " input").each(function () {
      var atr = jQuery(this).attr("name");

      //tiene este atributo?
      if (typeof atr !== typeof undefined && atr !== false) {
        //vemos que tipo de input es, esto hace que varie la metodologia

        if (jQuery(this).attr("type") == "text")
          answer[atr] = jQuery(this).val();
        else if (jQuery(this).attr("type") == "hidden")
          answer[atr] = jQuery(this).val();
        else if (jQuery(this).attr("type") == "radio") {
          if (jQuery(this).prop("checked")) answer[atr] = jQuery(this).val();
        }
      }
    });

    //para los select
    jQuery(selector + " select").each(function () {
      var atr = jQuery(this).attr("name");

      //tiene este atributo?
      if (typeof atr !== typeof undefined && atr !== false) {
        answer[atr] = jQuery(this).val();
      }
    });

    return answer;
  }
};

main = new Main();
