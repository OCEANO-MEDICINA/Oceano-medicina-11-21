// Completa el primer formulario y selecciona un método de pago (suscripción/tradicional)
function fillPersonalDataForm(method = "suscripcion") {

	document.getElementsByClassName("form-check-input")[23].value = "nombre";
	document.getElementsByClassName("form-check-input")[24].value = "apellido";
	document.getElementsByClassName("form-check-input")[25].value = "12345678";
	document.getElementsByClassName("form-check-input")[26].value = "test@gmail.com";
	document.getElementsByClassName("form-check-input")[28].value = "direccion";
	document.getElementsByClassName("form-check-input")[29].value = "12345678";
	document.getElementsByClassName("form-check-input")[30].value = "1234";

	document.getElementById("id_proceed").click();

	if (method == "suscripcion") {
		document.getElementsByClassName("form-check-label")[8].click();
	} else {
		document.getElementsByClassName("form-check-label")[9].click();
	}

	document.getElementById("id_proceed").click();
}

function selectPaymentMethod(cardType = "credit") {

	if (cardType == "credit") {
		document.getElementsByClassName("form-check-label")[11].click();
	} else {
		document.getElementsByClassName("form-check-label")[12].click();
	}

	document.getElementById("id_proceed").click();

}

function fillDataCardForm(cardNumber = "5031 7557 3453 0604", cardHolderName = "APRO", cardExpirationMonth = 11, cardExpirationYear = 2023, docNumber = "12345678", securityCode = "123", issuer = 310) {

	document.getElementById("cardNumber").value          = cardNumber;
	document.getElementById("cardholderName").value      = cardHolderName;
	document.getElementById("cardExpirationMonth").value = cardExpirationMonth;
	document.getElementById("cardExpirationYear").value  = cardExpirationYear;
	document.getElementById("docNumber").value 		     = docNumber;
	document.getElementById("securityCode").value        = securityCode;

	return;

	// El issuer no funciona porque se debe simular un keypress para que aparezcan los bancos. 
	document.getElementById("issuer").value 		     = issuer;

	// Click en continuar
	document.getElementById("id_proceed").click();

}

function selectInstallments() {

	document.getElementsByClassName("form-check-input")[32].click();
	document.getElementById("id_proceed").click();

}

function confirm() {

	document.getElementById("id_proceed").click();

}

function sleep(ms) {

	return new Promise(resolve => setTimeout(resolve, ms));

}
  
async function main() {

	fillPersonalDataForm();
	await sleep(3500);
	selectPaymentMethod();
	await sleep(3500);
	fillDataCardForm();
	return "end";
	
}


console.log(main());;