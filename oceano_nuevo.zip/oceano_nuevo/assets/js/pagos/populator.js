
var Populator = function()
{
	
	this.wholeMethods = function()
	{
		fetchRestMethods();
	};
	
	this.doInstallments = function()
	{
		buildInstallments();
	};
	
	//publica
	this.updatePrices = function(n)
	{
		updatePrices(n);
		
	};
	
	//agrega listeners a radio de suscri
	//estas opciones son estáticas, se ponen por html
	//son 2 nomás!
	this.addListenerToScp = function(){
		//agregamos listener
		jQuery('.installments-checkbox').change(function(){
			updatePrices(this.value);
		});
	}
	
	//actualiza los montos y cuotas en base al N que le des
	//privada
	function updatePrices(n){
		if(n == 0)
			n++;
		
		//escribir numero de cuotas
		if(n > 1)
		{
			jQuery('.label_quotes').html(' ' + n + ' cuotas');
		}
		else
		{
			jQuery('.label_quotes').html(' 1 cuota');
		}
		
		
		jQuery('.label_small_price').each(function()
		{
			var amnt = jQuery(this).data('amount');
			var symbol = jQuery(this).data('symbol');

			amnt = (amnt/n).toFixed(2);
			
			jQuery(this).html(symbol + formatPrice(amnt));
		}
		);
		
		var tot = jQuery('#id_label_total_price').data('amount');
		var sym = jQuery('#id_label_total_price').data('symbol');


        tot = (tot/n).toFixed(2);
		
		jQuery('#id_label_total_price').html(sym + formatPrice(tot));
		
	}
	
	//formatea como hace wordpress
	function formatPrice(price)
	{
		var answer = price;
		var dec = ''; //decimales en caso de que sea necesario

		//tiene .?
		if(price.indexOf('.') != -1)
		{
			//tiene .00?
			if(price.indexOf('.00') != -1)
			{
				price = price.replace('.00','');
			}
			else //debe tener decimales onda .33
			{
				var ind = price.search(/\..*/gm);
				dec = price.slice(ind);
				dec = dec.replace('.',',');
				
				//bueno ahora sí, le saco de price
				//estos decimales y se los recompongo
				//al final
				price = price.replace(/\..*/gm,'');
			}
		}

		if(price.length >= 4){
			var sub = price.slice(-3);
			price = price.replace(sub,'');
			price = price + '.' + sub;
			
		}

		//recompongo de ser necesario
		price = price.toString() + dec;
		return price;
	}

	//arma las cuotas en base al installments disponible
	function buildInstallments()
	{
		
		jQuery('#form_cuotas').html('');
		
		if(jQuery('#installments option').length == 0){
			jQuery('#form_cuotas').html('No pudimos cargar las opciones de cuotas, <br> vuelve a los datos de tarjeta y asegurate de colocar bien los valores <br> en tus datos de tarjeta (sin espacios adicionales)');
		}
		
		jQuery('#installments option').each(function(){
			var val = jQuery(this).val();
			var txt = jQuery(this).html();
			
			//de txt tomamos solo lo importante
			var n = txt.search(/\$.*/i);
			
			txt = txt.substring(n, txt.length);
					
			if(val != '-1' && parseInt(val) <= 12)
			{
				var textCuotas = 'cuotas';
				
				if(val == 1)
					textCuotas = 'cuota';
				
				var newDiv = '<div class="col-12 cupones-de-pago plancuotas">\
				<input class="form-check-input input-texto radio-cuota" type="radio" name="cuotas_cre" value="'+val+'" id="label_cuotas_'+val+'">\
				<label class="form-check-label" for="label_cuotas_'+val+'"><strong>'+val+' '+textCuotas+'</strong> sin interés</label>\
				<h6>' + txt + '</h6>\
			</div>';
				
				jQuery('#form_cuotas').append(newDiv);
				
				//agregamos listener
				jQuery('input[type=radio][name=cuotas_cre]').change(function(){
					updatePrices(this.value);
				});
				
				//preseleccionamos si es igual al de la cookie
				if(val == _cookie_installments)
					jQuery('#label_cuotas_'+val).attr('checked',true);
					
			}
		});
	}
	
	//obtener data del resto de pagos
	function fetchRestMethods()
	{
		jQuery.ajax(
		{
			type: 'POST',
			url:'https://oceanomedicina.com.ar/'+_domain+'/middle/GiveAllMethodsData',
			dataType:'json',
			data:{pais:_pais},
			success:function(d)
			{
				populateRestMethods(d)
			},
			error:function()
			{
				//eeeh... ?s
			}

		});
	}
	
	//popula resto de los pagos
	//iconitos y botoncitos
	//iconos de cuando elegis modalidad de pago
	//botoncitos de cuando querés deposito, transf, ticket
	function populateRestMethods(data)
	{
		var now = '';
		
		var possibilities = ['ticket','atm','bank_transfer'];
		
		//iconitos (esto es lo que aparece que vas a elegir metodo de pago (transf, depo, efectivo?))
		for(p in possibilities)
		{
			for(d in data)
			{			
				if(possibilities[p] == 'ticket' && data[d]['payment_type_id'] == 'ticket')
				{				
					now += '<img class="img_thumb" src="'+data[d]['secure_thumbnail']+'" alt="'+data[d]['name']+'" for="cupon">'; 	
				}
				
				if(possibilities[p] == 'atm' && data[d]['payment_type_id'] == 'atm')
				{				
					now += '<img class="img_thumb" src="'+data[d]['secure_thumbnail']+'" alt="'+data[d]['name']+'" for="deposito">'; 					
				}
	
				if(possibilities[p] == 'bank_transfer' && data[d]['payment_type_id'] == 'bank_transfer')
				{				
					now += '<img class="img_thumb" src="'+data[d]['secure_thumbnail']+'" alt="'+data[d]['name']+'" for="transferencia">'; 					
				}
				
			}
		
			if(possibilities[p] == 'ticket')
				jQuery('#id_thumbs_cup').html(now);
			
			if(possibilities[p] == 'atm')
				jQuery('#id_thumbs_dpst').html(now);
			
			if(possibilities[p] == 'bank_transfer')
				jQuery('#id_thumbs_traf').html(now);
			
			
			now = '';
		}
		
		//botoncitos (esto se muestra cuando elegiste el metodo de pago y tenes que elegir alguna de las posibilidades)
		//por ejemplo -> elegiste efectivo, bueno ahora elegi qué cupón querés! rapipago? pagofacil??
		for(d in data)
		{			
			if(data[d]['payment_type_id'] == 'ticket')
			{		
				var newDiv = '';
				
				var dataID = data[d]['id'];
				var imageThu = data[d]['secure_thumbnail'];
				var name = data[d]['name'];
				
				newDiv = '<div>\
					<input class="form-check-input input-texto" id="sep_'+dataID+'" type="radio" value="'+dataID+'" data-id="'+dataID+'" name="select_ticket" >\
					<label class="form-check-label" for="sep_'+dataID+'"><img src="'+imageThu+'" alt="'+name+'"></label>\
				</div>'
		
				jQuery('#id_div_container_cupon').append(newDiv);
			}				
		}
		
		for(d in data)
		{			
			if(data[d]['payment_type_id'] == 'atm')
			{		
				var newDiv = '';
				
				var dataID = data[d]['id'];
				var imageThu = data[d]['secure_thumbnail'];
				var name = data[d]['name'];
				
				newDiv = '<div>\
					<input class="form-check-input input-texto" id="sep_'+dataID+'" type="radio" value="'+dataID+'" data-id="'+dataID+'" name="select_atm" >\
					<label class="form-check-label" for="sep_'+dataID+'"><img src="'+imageThu+'" alt="'+name+'"></label>\
				</div>'
		
				jQuery('#id_div_container_deposito').append(newDiv);
			}				
		}
		
		for(d in data)
		{			
			if(data[d]['payment_type_id'] == 'bank_transfer')
			{		
				var newDiv = '';
				
				var dataID = data[d]['id'];
				var imageThu = data[d]['secure_thumbnail'];
				var name = data[d]['name'];
				
				newDiv = '<div>\
					<input class="form-check-input input-texto" id="sep_'+dataID+'" type="radio" value="'+dataID+'" data-id="'+dataID+'" name="select_traf" >\
					<label class="form-check-label" for="sep_'+dataID+'"><img src="'+imageThu+'" alt="'+name+'"></label>\
				</div>'
		
				jQuery('#id_div_container_transferencia').append(newDiv);
			}				
		}
		
	}
	
};

populator = new Populator();;