var VisualSteps = function()
{
	
	var steps = {}; //cada uno de los pasos, indice (key) y texto
	var actual = 0; //en que paso estamos?
	var size = 0; //cantidad de pasos que tiene en total
	var end = '?'; //almacena el final, good or bad... o "?" si todavia no termino
	
	//te dice la conclusión
	this.giveEnd = function()
	{
		return end;
	}
	
	//arma los pasos en base al array que le pasas
	this.build = function(pasos)
	{
		var ind = 1;
		
		for(p in pasos)
		{
			steps[ind] = pasos[p];
			ind++;
		}
		
		actual = 1;
		
		size = pasos.length;
		
		draw();
	}
	
	//le dice cuál es el paso que ahora estará activo, a modo texto!
	this.set = function(label)
	{
		ind = 0;
		
		for(s in steps)
		{
			if(steps[s] == label)
				ind = s;
		}
		
		actual = ind;
		draw();
	}
	
	//setea los pasos como si hubiese finalizado
	//good es verde
	//bad es rojo
	this.finish = function(state)
	{
		//  
		
		emptyDraw();
		
		end = state;
		
		if(state == 'good')
		{
			//al último le pongo el listo
			jQuery('#id_step_'+size).append('<div class="steptext active">¡Listo!</div>');
			
			//le saco el greyed
			jQuery('#id_step_'+size+' div.circle').removeClass('greyed');
			
			//le pongo el tick
			jQuery('#id_step_'+size+' div.circle').html('✓');
			
			//le pongo activo el circulito y verde
			jQuery('#id_step_'+size+' div.circle').addClass('active green');
	
		}
		else if(state == 'bad')
		{
			//al último le pongo el texto
			jQuery('#id_step_'+size).append('<div class="steptext active">¡Epa!</div>');
			
			//le saco el greyed
			jQuery('#id_step_'+size+' div.circle').removeClass('greyed');
			
			//le pongo la cruz
			jQuery('#id_step_'+size+' div.circle').html('✗');
			
			//le pongo activo el circulito y rojo
			jQuery('#id_step_'+size+' div.circle').addClass('active red');	
		}
		
		
	}
	
	//dibuja todos los pasos pero vacios
	function emptyDraw()
	{
		//primero dibujo todos los circulos
		canvas='';
		
		for(s in steps)
		{
			canvas+='<div id="id_step_'+s+'" class="col-4 col-md-2 step before after">\
                        <div class="circle greyed"></div>\
                    </div>';
		}
		
		jQuery('#id_all_steps').html(canvas);
		
		//al primero le saco la linea izquierda
		jQuery('#id_step_1').removeClass('before');
		
		//al último le saco la línea derecha
		jQuery('#id_step_'+size).removeClass('after');
	}
	
	//dibuja en html lo que tenga guardado en steps y actual
	function draw()
	{
		/*
		 <div class="col-4 col-md-2 step before after">
                        <div class="circle active">2</div>
                        <div class="steptext">Confirmación</div>
                    </div>
		*/
		
		//primero dibujo todos los circulos
		canvas='';
		
		for(s in steps)
		{
			canvas+='<div id="id_step_'+s+'" class="col-4 col-md-2 step before after">\
                        <div class="circle">'+s+'</div>\
                        <div class="steptext">'+steps[s]+'</div>\
                    </div>';
		}
		
		jQuery('#id_all_steps').html(canvas);
		
		//al primero le saco la linea izquierda
		jQuery('#id_step_1').removeClass('before');
		
		//al último le saco la línea derecha
		jQuery('#id_step_'+size).removeClass('after');
		
		//finalmente, el que esté activo, lo marco!
		jQuery('#id_step_'+actual+' .circle').addClass('active');
		jQuery('#id_step_'+actual+' .steptext').addClass('active');
	}
	
};

Vsteps = new VisualSteps();;