var Validador = function () {
  this.mustCreateToken = false;

  this.run = function (part, estilo, forma) {
    answer = true;

    this.mustCreateToken = false; //para cuando valida las tarjetas y debe crear token
    this.updateQuotes = false; //para cuando valida las cuotas y tiene que actualizar los labels

    //limpio los mensajes
    jQuery("#id_msg_error").html("");

    _processor = jQuery("#id_processor").val();

    //hay que validar, pero primero tengo que ver QUÉ valido

    //PARA VALIDAR USAR NOT y OR.... if !A || !B || !C
    //es decir, si falla A, o B, o C... todo mal!
    if (part == 4) {
      if (forma == "cupon") {
        if (!cupon()) answer = false;
      } else if (forma == "deposito") {
        if (!deposito()) answer = false;
      } else if (forma == "transferencia") {
        if (!transferencia()) answer = false;
      } else if (forma == "credito" || forma == "debito") {
        if (!tarjetas()) {
          answer = false;
        }

        if (
          jQuery("#token").val() == "" ||
          jQuery("#token").val() == undefined
        ) {
          //igual le devuelvo falso porque tengo que recrear el token
          addMsg("<Recreando Token>");
          this.mustCreateToken = true; //le dice al main tenés que crear el token
          answer = false;
        }
      }
    } else if (part == 0) {
      if (!adicionales()) answer = false;
    } else if (part == 5) {
      // 	if(!cuotas())
      // 		answer = false;
      // 	else
      // 	{
      this.updateQuotes = true;
      // 	}
      // }
      // else if(part == 6)
      // {
      // 	if(!meses())
      // 		answer = false;
    } else if (part == 7) {
      jQuery("#id_msg_error_2").html("");

      if (!termscond()) answer = false;
    } else if (part == 1) {
      if (!envio()) answer = false;
    }

    return answer;
  };

  //revisar datos de la tarjeta
  function tarjetas() {
    answer = true;

    var cardNumber = jQuery("#cardNumber").val();
    cardNumber = cardNumber.replace(" ", ""); //quita espacios vacios
    cardNumber = cardNumber.replace(/\D/g, ""); //quita lo que no son numeros

    //jQuery('#cardNumber').val(cardNumber);

    if (!cardNumber.length) {
      answer = false;
      addMsg("Está mal el número de tarjeta");
    }

    var secCode = jQuery("#securityCode").val();
    secCode = secCode.replace(" ", ""); //quita espacios vacios
    secCode = secCode.replace(/\D/g, ""); //quita lo que no son numeros

    if (!secCode.length) {
      answer = false;
      addMsg("Está mal el código de seguridad");
    }

    var month = jQuery("#cardExpirationMonth").val();
    month = month.replace(" ", ""); //quita espacios vacios
    month = month.replace(/\D/g, ""); //quita lo que no son numeros

    // if(month.length != 2)
    // {
    // 	answer = false;
    // 	addMsg('Está mal el mes de expiración');
    // }

    var year = jQuery("#cardExpirationYear").val();
    year = year.replace(" ", ""); //quita espacios vacios
    year = year.replace(/\D/g, ""); //quita lo que no son numeros

    if (year.length != 4 || month.length != 2) {
      answer = false;
      addMsg("Está mal el vencimiento de la tarjeta");
    }

    if (!jQuery("#cardholderName").val().length) {
      answer = false;
      addMsg("Está mal el nombre del titular de la tarjeta");
    }

    var valDni = jQuery("#docNumber").val();
    valDni = valDni.replace(" ", ""); //quita espacios vacios
    valDni = valDni.replace(/\D/g, ""); //quita lo que no son numeros

    jQuery("#docNumber").val(valDni);

    if (jQuery("#id_country").val() != "mx") {
      //en mexico ignoramos DNI
      if (!jQuery("#docNumber").val().length) {
        answer = false;
        addMsg("Está mal el DNI");
      }
    }

    return answer;
  }

  //seleccionó alguna cuota de tarjeta de crédito?? debe hacerlo!
  function cuotas() {
    answer = true;

    //si no eligió nada, dará undefined
    if (typeof jQuery("[name=cuotas_cre]:checked").val() === "undefined") {
      answer = false;
      addMsg("Debe seleccionar una opción");
    }

    return answer;
  }

  //términos y condiciones tiene que estar checkeado
  function termscond() {
    answer = true;
    //no checkeado?
    if (!jQuery("#cbox1").prop("checked")) {
      answer = false;
      addMsg2("Debe aceptar los términos y condiciones para continuar");
    }

    return answer;
  }

  //seleccionó algun mes de suscri?? debe hacerlo!
  function meses() {
    answer = true;

    //si no eligió nada, dará undefined
    if (typeof jQuery("[name=meses_cre]:checked").val() === "undefined") {
      answer = false;
      addMsg("Debe seleccionar una opción");
    }

    return answer;
  }

  //seleccionó algo dentro de cupon??? debe hacerlo!
  function cupon() {
    answer = true;

    //si no eligió nada, dará undefined
    if (typeof jQuery("[name=select_ticket]:checked").val() === "undefined") {
      answer = false;
      addMsg("Debe seleccionar una opción");
    }

    return answer;
  }

  //seleccionó algo dentro de deposito??? debe hacerlo!
  function deposito() {
    answer = true;

    //si no eligió nada, dará undefined
    if (typeof jQuery("[name=select_atm]:checked").val() === "undefined") {
      answer = false;
      addMsg("Debe seleccionar una opción");
    }

    return answer;
  }

  //seleccionó algo dentro de transferencia??? debe hacerlo!
  function transferencia() {
    answer = true;

    //si no eligió nada, dará undefined
    if (typeof jQuery("[name=select_traf]:checked").val() === "undefined") {
      answer = false;
      addMsg("Debe seleccionar una opción");
    }

    return answer;
  }

  //datos de envio...
  function envio() {
    answer = true;

    if (!jQuery("#del_codigopostal").val().length) {
      answer = false;
      addMsg("Escriba un código postal");
    }

    if (!jQuery("#del_calle").val().length) {
      answer = false;
      addMsg("Escriba una calle");
    }

    if (!jQuery("#del_numero").val().length) {
      answer = false;
      addMsg("Escriba un número");
    }

    if (!jQuery("#del_entre").val().length) {
      answer = false;
      addMsg("Escriba entre qué calles está");
    }

    if (!jQuery("#del_barrio").val().length) {
      answer = false;
      addMsg("Escriba el barrio");
    }

    return answer;
  }

  //validamos datos adicionales
  function adicionales() {
    answer = true;
    if (!jQuery("#nombre").val().length) {
      answer = false;
      addMsg("El campo nombre de la facturacion esta vacio .");
    }
    if (!jQuery("#apellido").val().length) {
      answer = false;
      addMsg("El campo apellido de la facturacion esta vacio.");
    }

    if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/gi.test(jQuery("#email").val())
    ) {
      answer = false;
      addMsg("El campo mail esta vacio o es incorecto.");
    }
    if (!jQuery("#telefono").val().length) {
      answer = false;
      addMsg("El campo telefono esta vacio.");
    }
    if (!jQuery("#direccion").val().length) {
      answer = false;
      addMsg("La dirección está vacio.");
    }
    if (!jQuery("#id_zip").val().length) {
      answer = false;
      addMsg("El código postal está vacio.");
    }

    if (jQuery("#id_add_provincia").length > 0)
      if (!jQuery("#id_add_provincia option:selected").attr("value")) {
        answer = false;
        addMsg("La provincia está vacia.");
      }

    var valDni = jQuery("#dni").val();
    valDni = valDni.replace(" ", ""); //quita espacios vacios
    valDni = valDni.replace(/\D/g, ""); //quita lo que no son numeros

    jQuery("#dni").val(valDni);
    var country = jQuery("#id_country").val();

    if (country != "mx") {
      // if(!jQuery('#dni').val().length){
      // 	answer = false;
      // 	addMsg('El dni está mal');
      // }
    } else {
      //el rfc está vacío o es no válido
      if (
        jQuery("#rfc").val().length < 1 ||
        validateRfc(jQuery("#rfc").val())
      ) {
        //rfc válido
      } else {
        answer = false;
        addMsg("El RFC está mal");
      }
    }

    return answer;
  }

  this.publicMsg = function (txt) {
    addMsg(txt);
  };

  function addMsg(txt) {
    jQuery("#id_msg_error").append("<p> " + txt + " </p>");
  }

  function addMsg2(txt) {
    jQuery("#id_msg_error_2").append("<p> " + txt + " </p>");
  }

  this.addListenerToTyc = function () {
    //agregamos listener
    jQuery("#id_tyc").change(function () {
      if (this.checked) jQuery("#id_msg_error_2").html("");
    });
  };

  //función para validar un RFC
  function validateRfc(rfc) {
    const re =
      /^([A-ZÑ&]{3,4}) ?(?:- ?)?(\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])) ?(?:- ?)?([A-Z\d]{2})([A\d])$/;

    if (rfc.match(re)) {
      //Coincide con el formato general del regex?
      return true;
    } else {
      return false;
    }
  }
};

validador = new Validador();
