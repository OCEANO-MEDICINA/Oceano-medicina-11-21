var Utility = function()
{	

	var tagHelper = '';

	//facebook tracking
	this.facebookTrack = function(status){
		var tot = jQuery('#id_label_total_price').data('amount');
		if((status == 1) && (typeof fbq !== 'undefined')){
			console.log('fb q: 1');
			fbq('track', 'Purchase', {currency: "ARS", value: tot});
		}
	};
	
	//trackea url con # y tambien le pone en el botón
	//o sea reemplaza URL y le agrega lo que pidas
	//un adicional opcional es el texto de boton
	//si ponés algo lo llena, sino pone el text
	this.urlTrack = function(text, button)
	{
		
		//PARTE DE URL
		var url = window.location.href;
		
		//sacar # si existiera
		if(url.includes('#'))
		{
			var aux = url.split('#');
			url = aux[0];
		}
		
		location.assign(url+'#'+text);
		
		//PARTE DE BOTON
		
		//al boton le saca la clase de seguimiento
		jQuery('#id_proceed').removeClass(tagHelper);
		
		//y le pone la nueva
		
		if(button === undefined)
			button = text;
		
		jQuery('#id_proceed').addClass(button);
		tagHelper = button;	
	}
	
	//a la URL le saca lo que haya con # que es el tracker
	// www.url.com/a#algo -> www.url.com/a
	//y te la devuelve
	this.urlClean = function()
	{
		//PARTE DE URL
		var url = window.location.href;
		
		//sacar # si existiera
		if(url.includes('#'))
		{
			var aux = url.split('#');
			url = aux[0];
		}
		
		return(url);
	}
	

	//devuelve public key
	this.givePublicKey = function(country)
	{
		var answer = '';

		answer = jQuery('#id_mp_key').data('key');

		return(answer);
	}

	//en base al pais, esconde las opciones que no interesen (no esten disponibles)
	this.hideUnavailableMethods = function(country){
		if(country == 'ar'){
            jQuery('.divdeposito, .divtransferencia, .divcupon').hide();
            jQuery('.formatrad').show();
		}
		else if(country == 'ch') jQuery('.divdeposito, .divtransferencia, .divcupon').hide();
		else if(country == 'co') jQuery('.divdeposito, .divtransferencia, .divcupon').hide();
		else if(country == 'mx'){
			jQuery('.divdeposito, .divtransferencia, .divcupon').hide();
			jQuery('.formatrad').show();
			
			//no tienen dni así que...
			jQuery('.fortipodni, .fornumdni').parent().hide();
		}

		/*else if(country == 'pe') jQuery('.divdeposito, .divtransferencia, .divcupon').hide();

		else if(country == 'cr') jQuery('.formasucri').hide();
		else if(country == 'ec') jQuery('.formasucri').hide();
		else if(country == 'sal') jQuery('.formasucri').hide();
		else if(country == 'es') jQuery('.formasucri').hide();
		else if(country == 'ni') jQuery('.formasucri').hide();
		else if(country == 'pnm') jQuery('.formasucri').hide();
		else if(country == 'py') jQuery('.formasucri').hide();*/



	}

	//setea detalles específicos por pais
	this.details = function()
	{
		if(_pais == 'ch')
		{
			//datos adicionales de transferencia... tipo de dni... y bancos!
			
			jQuery('#form_datosadicionales').append('<div id="id_more_data" style="display:none"> </div>');
			
			jQuery('#id_more_data').append('<h3> Datos adicionales de transferencia </h3>');
			
			jQuery('#id_more_data').append(buildInput('doctype_chile'));
			
			pasteBanks('#id_more_data');
		}
		else if(_pais == 'co')
		{
			//datos adicionales de transferencia... tipo de dni... y bancos!
			
			jQuery('#form_datosadicionales').append('<div id="id_more_data" style="display:none"> </div>');
			
			jQuery('#id_more_data').append('<h3> Datos adicionales de transferencia </h3>');
			
			jQuery('#id_more_data').append(buildInput('doctype_colombia'));
			
			pasteBanks('#id_more_data');
		}
		else if(_pais == 'mx')
		{
			//1. agrega un input opcional para el RFC
			var rfcInput = '\
				<div class="col-6">\
					<label class="form-check-label" for="rfc">RFC (opcional)</label>\
					<input class="form-check-input input-texto" type="text" name="rfc" id="rfc" value=""></input>\
				</div>';
			
			jQuery("#dni").parent().after(rfcInput);
			//2. achica las columnas del input dirección a 6
			jQuery("#direccion").parent().removeClass()
			jQuery("#direccion").parent().addClass("col-6")
		}
	}
	
	//arma el input que le pidas (a modo hardcodeado por ahora)
	//por ejemplo, para chile hay determinados tipos de dni, para colombia otros
	function buildInput(what)
	{
		var answer = '';
		
		if(what == 'doctype_chile')
		{
			answer = '<label for="docType">* Tipo de documento:</label>\
					<select name="docType" id="docType" data-checkout="docType"><option value="RUT">RUT</option>\
					<option value="Otro">Otro</option></select>';
		}
		else if(what == 'doctype_colombia')
		{
			answer = '<label for="docType">* Tipo de documento:</label>\
					<select name="docType" id="docType" data-checkout="docType"><option value="CC">C.C.</option><option value="CE">C.E.</option><option value="NIT">NIT</option><option value="Otro">Otro</option></select></select>';
		}

		return(answer);
	}
	
	//va a buscar los financial institutions, arma un select, y lo pega donde vos le digas
	function pasteBanks(where)
	{
		jQuery.ajax(
				{
					type: 'POST',
					url:'https://oceanomedicina.com.ar/'+_domain+'/middle/GiveBanks',
					dataType:'json',
					data:{pais:_pais},
					success:function(d)
					{
						callback_pasteBanks(d,where);
					},
					error:function()
					{
						//console.log('no pude traer los bancos');
					}

				});
	}
	
	function callback_pasteBanks(data, where)
	{
		var output = '<label for="slBank">* Banco:</label>\
					<select name="slBank" id="slBank" data-checkout="slBank">';

	
		jQuery.each(data,function(key, value) 
		{
			output+='<option value ="'+data[key]['id']+'">';
			output+=data[key]['description']+'</option>';
		});
		
		output+='</select>';
		
		jQuery(where).append(output);
	}

	
};

Utility = new Utility();;