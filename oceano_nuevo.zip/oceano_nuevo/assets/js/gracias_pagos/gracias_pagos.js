jQuery(document).ready(function ($) {
  function emptyCart(reduceStock = false) {
    jQuery.ajax({
      type: "POST",
      url: php_vars_passed.carriten,
      dataType: "json",
      data: {
        action: "hookvaciarcarrito",
        reduce_stock: reduceStock,
      },
      success: function (d) {
        //console.log('carrito vaciado');
      },
      error: function (d) {
        //console.log('mmhm, no pude vaciar carrito');
      },
    });
  }
  emptyCart();
});
